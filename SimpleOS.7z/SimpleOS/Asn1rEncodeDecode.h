/*****************************************************************************************************
* FileName:                    Asn1rEncodeDecode.h
*
* Description:                 6747�Ĵ�������
*
* Author:                      YanDengxue, Fiberhome-Fuhua
*
* Rev History:
*       <Author>        <Data>        <Hardware>     <Version>        <Description>
*     YanDengxue   2011-03-29 15:30       --           1.00             Create
*****************************************************************************************************/
#ifndef _Asn1r_Encode_Decode_H_
#define _Asn1r_Encode_Decode_H_

#ifdef __cplusplus
extern "C" {
#endif

//====================================================================================================
// �ⲿ��������
//====================================================================================================
int32 Length2Asn1r(Uint8 **pp_buffer, Uint8 tag, Uint16 length);
int32 Bool2Asn1r(Uint8 **pp_buffer, Uint8 tag, Uint8 src);
int32 Dbpos2Asn1r(Uint8 **pp_buffer, Uint8 tag, Uint8 src);
int32 Quality2Asn1r(Uint8 **pp_buffer, Uint8 tag, Uint8 src);
int32 String2Asn1r(Uint8 **pp_buffer, Uint8 tag, char const *src);
int32 Uint162Asn1r(Uint8 **pp_buffer, Uint8 tag, Uint16 src);
int32 Uint322Asn1r(Uint8 **pp_buffer, Uint8 tag, Uint32 src);
int32 Int322Asn1r(Uint8 **pp_buffer, Uint8 tag, int32 src);
int32 UTCTime2Asn1r(Uint8 **pp_buffer, Uint8 tag, Uint64 usecond, Uint32 time_zone, Uint8 time_flag);

#ifdef __cplusplus
}
#endif

#endif // End _DEVICE_H_

