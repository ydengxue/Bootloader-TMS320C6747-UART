/*****************************************************************************************************
* FileName:                    Asn1rEncodeDecode.c
*
* Description:                 asn.1�����
*
* Author:                      YanDengxue, Fiberhome-Fuhua
*
* Rev History:
*       <Author>        <Data>        <Hardware>     <Version>        <Description>
*     YanDengxue   2011-03-29 15:30       --           1.00             Create
*****************************************************************************************************/
//====================================================================================================
// ���ļ�ʹ�õ�ͷ�ļ�
//====================================================================================================
// ��ͷ�ļ�
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

// �Զ���ͷ�ļ�
#include "UserTypesDef.h"
#include "Asn1rEncodeDecode.h"

//====================================================================================================
// ���ر�������,�˴������ı��������ⲿ�ӿ�
//====================================================================================================
static Uint32 const utc_fraction_bit[] =
{
    0x800000u, 0x400000u, 0x200000u, 0x100000u,
    0x080000u, 0x040000u, 0x020000u, 0x010000u,
    0x008000u, 0x004000u, 0x002000u, 0x001000u,
    0x000800u, 0x000400u, 0x000200u, 0x000100u,
    0x000080u, 0x000040u, 0x000020u, 0x000010u,
};

static Uint32 const utc_fraction_value[] =
{
    500000u, 250000u, 125000u, 62500u,
    31250u,  15625u,  7812u,   3906u,
    1953u,   977u,    488u,    244u,
    122u,    61u,     31u,     15u,
    8u,      4u,      2u,      1u
};

//====================================================================================================
// ����ʵ��
//====================================================================================================
//----------------------------------------------------------------------------------------------------
// �ӿں���
//----------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------
//   Function: Length2Asn1r
//      Input: Uint8 **pp_buffer: ���buffer��β��ַָ��
//             Uint8 tag
//             Uint16 length
//     Output: Uint8 **pp_buffer: ���buffer���׵�ַָ��
//     Return: int32: ����ִ�����
//Description: ����asn.1����
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
int32 Length2Asn1r(Uint8 **pp_buffer, Uint8 tag, Uint16 length)
{
    Uint8 *lv_p_buffer;

    lv_p_buffer = *pp_buffer;

    if (length > 255u)
    {
        *(--lv_p_buffer) = length;
        *(--lv_p_buffer) = length >> 8;
        *(--lv_p_buffer) = 0x82u;
    }
    else if (length > 127u)
    {
        *(--lv_p_buffer) = length;
        *(--lv_p_buffer) = 0x81u;
    }
    else
    {
        *(--lv_p_buffer) = length;
    }

    *(--lv_p_buffer) = tag;

    *pp_buffer = lv_p_buffer;

    return NORMAL_SUCCESS;
}

//----------------------------------------------------------------------------------------------------
//   Function: Bool2Asn1r
//      Input: Uint8 **pp_buffer: ���buffer��β��ַָ��
//             Uint8 tag
//             Uint8 src
//     Output: Uint8 **pp_buffer: ���buffer���׵�ַָ��
//     Return: int32: ����ִ�����
//Description: Bool��asn.1����
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
int32 Bool2Asn1r(Uint8 **pp_buffer, Uint8 tag, Uint8 src)
{
    Uint8 *lv_p_buffer;

    lv_p_buffer = *pp_buffer;

    *(--lv_p_buffer) = (0 == (src & 0x01)) ? 0x00 : 0xff;
    *(--lv_p_buffer) = 0x01;
    *(--lv_p_buffer) = tag;

    *pp_buffer = lv_p_buffer;

    return NORMAL_SUCCESS;
}

//----------------------------------------------------------------------------------------------------
//   Function: Dbpos2Asn1r
//      Input: Uint8 **pp_buffer: ���buffer��β��ַָ��
//             Uint8 tag
//             Uint8 src
//     Output: Uint8 **pp_buffer: ���buffer���׵�ַָ��
//     Return: int32: ����ִ�����
//Description: Dbpos��asn.1����
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
int32 Dbpos2Asn1r(Uint8 **pp_buffer, Uint8 tag, Uint8 src)
{
    Uint8 *lv_p_buffer;

    lv_p_buffer = *pp_buffer;

    *(--lv_p_buffer) = src;
    *(--lv_p_buffer) = 0x06;
    *(--lv_p_buffer) = 0x02;
    *(--lv_p_buffer) = tag;

    *pp_buffer = lv_p_buffer;

    return NORMAL_SUCCESS;
}

//----------------------------------------------------------------------------------------------------
//   Function: Quality2Asn1r
//      Input: Uint8 **pp_buffer: ���buffer��β��ַָ��
//             Uint8 tag
//             Uint8 src
//     Output: Uint8 **pp_buffer: ���buffer���׵�ַָ��
//     Return: int32: ����ִ�����
//Description: Quality��asn.1����
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
int32 Quality2Asn1r(Uint8 **pp_buffer, Uint8 tag, Uint8 src)
{
    Uint8 *lv_p_buffer;

    lv_p_buffer = *pp_buffer;

    *(--lv_p_buffer) = src;
    *(--lv_p_buffer) = src >> 8;
    *(--lv_p_buffer) = 0x01;
    *(--lv_p_buffer) = 0x03;
    *(--lv_p_buffer) = tag;

    *pp_buffer = lv_p_buffer;

    return NORMAL_SUCCESS;
}

//----------------------------------------------------------------------------------------------------
//   Function: String2Asn1r
//      Input: Uint8 **pp_buffer: ���buffer��β��ַָ��
//             Uint8 tag
//             char const *src: �ַ����׵�ַ
//     Output: Uint8 **pp_buffer: ���buffer���׵�ַָ��
//     Return: int32: ����ִ�����
//Description: �ַ�����asn.1����
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
int32 String2Asn1r(Uint8 **pp_buffer, Uint8 tag, char const *src)
{
    int32 lv_length;
    Uint8 *lv_p_buffer;

    lv_p_buffer = *pp_buffer;

    lv_length = strlen(src);
    lv_p_buffer -= lv_length;
    memcpy(lv_p_buffer, src, lv_length);
    if (lv_length > 255)
    {
        *(--lv_p_buffer) = lv_length;
        *(--lv_p_buffer) = lv_length >> 8;
        *(--lv_p_buffer) = 0x82;
        lv_length += 4;

    }
    else if (lv_length > 127)
    {
        *(--lv_p_buffer) = LLSB(lv_length);
        *(--lv_p_buffer) = 0x81;
        lv_length += 3;
    }
    else
    {
        *(--lv_p_buffer) = LLSB(lv_length);
        lv_length += 2;
    }
    *(--lv_p_buffer) = tag;

    *pp_buffer = lv_p_buffer;

    return NORMAL_SUCCESS;
}

//----------------------------------------------------------------------------------------------------
//   Function: Uint162Asn1r
//      Input: Uint8 **pp_buffer: ���buffer��β��ַָ��
//             Uint8 tag
//             Uint16 src
//     Output: Uint8 **pp_buffer: ���buffer���׵�ַָ��
//     Return: int32: ����ִ�����
//Description: Uint16��asn.1����
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
int32 Uint162Asn1r(Uint8 **pp_buffer, Uint8 tag, Uint16 src)
{
    Uint8 lv_length;
    Uint8 *lv_p_buffer;

    lv_p_buffer = *pp_buffer;
    if (src > 0x7fffu)
    {
        lv_length = 3;
        *(--lv_p_buffer) = src;
        *(--lv_p_buffer) = src >> 8;
        *(--lv_p_buffer) = 0;
    }
    else if (src > 0x7fu)
    {
        lv_length = 2;
        *(--lv_p_buffer) = src;
        *(--lv_p_buffer) = src >> 8;
    }
    else
    {
        lv_length = 1;
        *(--lv_p_buffer) = src;
    }

    *(--lv_p_buffer) = lv_length;
    *(--lv_p_buffer) = tag;

    *pp_buffer = lv_p_buffer;

    return NORMAL_SUCCESS;
}

//----------------------------------------------------------------------------------------------------
//   Function: Uint322Asn1r
//      Input: Uint8 **pp_buffer: ���buffer��β��ַָ��
//             Uint8 tag
//             Uint32 src
//     Output: Uint8 **pp_buffer: ���buffer���׵�ַָ��
//     Return: int32: ����ִ�����
//Description: Uint32��asn.1����
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
int32 Uint322Asn1r(Uint8 **pp_buffer, Uint8 tag, Uint32 src)
{
    Uint8 lv_length;
    Uint8 *lv_p_buffer;

    lv_p_buffer = *pp_buffer;
    if (src > 0x7fffffffu)
    {
        lv_length = 5;
        *(--lv_p_buffer) = src;
        *(--lv_p_buffer) = src >> 8;
        *(--lv_p_buffer) = src >> 16;
        *(--lv_p_buffer) = src >> 24;
        *(--lv_p_buffer) = 0;
    }
    else if (src > 0x7fffffu)
    {
        lv_length = 4;
        *(--lv_p_buffer) = src;
        *(--lv_p_buffer) = src >> 8;
        *(--lv_p_buffer) = src >> 16;
        *(--lv_p_buffer) = src >> 24;
    }
    else if (src > 0x7fffu)
    {
        lv_length = 3;
        *(--lv_p_buffer) = src;
        *(--lv_p_buffer) = src >> 8;
        *(--lv_p_buffer) = src >> 16;
    }
    else if (src > 0x7f)
    {
        lv_length = 2;
        *(--lv_p_buffer) = src;
        *(--lv_p_buffer) = src >> 8;
    }
    else
    {
        lv_length = 1;
        *(--lv_p_buffer) = src;
    }

    *(--lv_p_buffer) = lv_length;
    *(--lv_p_buffer) = tag;

    *pp_buffer = lv_p_buffer;

    return NORMAL_SUCCESS;
}

//----------------------------------------------------------------------------------------------------
//   Function: Int322Asn1r
//      Input: Uint8 **pp_buffer: ���buffer��β��ַָ��
//             Uint8 tag
//             int32 src
//     Output: Uint8 **pp_buffer: ���buffer���׵�ַָ��
//     Return: int32: ����ִ�����
//Description: int32��asn.1����
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
int32 Int322Asn1r(Uint8 **pp_buffer, Uint8 tag, int32 src)
{
    Uint8 lv_length;
    Uint8 *lv_p_buffer;

    lv_p_buffer = *pp_buffer;
    if ((src > 8388607) || (src < -8388608))
    {
        lv_length = 4;
        *(--lv_p_buffer) = src;
        *(--lv_p_buffer) = src >> 8;
        *(--lv_p_buffer) = src >> 16;
        *(--lv_p_buffer) = src >> 24;
    }
    else if ((src > 32767) || (src < -32768))
    {
        lv_length = 3;
        *(--lv_p_buffer) = src;
        *(--lv_p_buffer) = src >> 8;
        *(--lv_p_buffer) = src >> 16;
    }
    else if ((src > 127) || (src < -128))
    {
        lv_length = 2;
        *(--lv_p_buffer) = src;
        *(--lv_p_buffer) = src >> 8;
    }
    else
    {
        lv_length = 1;
        *(--lv_p_buffer) = src;
    }

    *(--lv_p_buffer) = lv_length;
    *(--lv_p_buffer) = tag;

    *pp_buffer = lv_p_buffer;

    return NORMAL_SUCCESS;
}


//----------------------------------------------------------------------------------------------------
//   Function: UTCTime2Asn1r
//      Input: Uint8 **pp_buffer: ���buffer��β��ַָ��
//             Uint8 tag
//             Uint64 usecond
//             Uint32 time_zone
//             Uint8 time_flag
//     Output: Uint8 **pp_buffer: ���buffer���׵�ַָ��
//     Return: int32: ����ִ�����
//Description: UTCTime��asn.1����
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
int32 UTCTime2Asn1r(Uint8 **pp_buffer, Uint8 tag, Uint64 usecond, Uint32 time_zone, Uint8 time_flag)
{
    Uint32 i;
    Uint8 *lv_p_buffer;
    Uint32 lv_ulong_temp;
    Uint32 lv_fraction_bit;

    lv_p_buffer = *pp_buffer;

    *(--lv_p_buffer) = time_flag | (sizeof(utc_fraction_value) / sizeof(utc_fraction_value[0]));

    lv_fraction_bit = 0;
    lv_ulong_temp = usecond % 1000000;
    for (i = 0; i < sizeof(utc_fraction_value) / sizeof(utc_fraction_value[0]); i++)
    {
        if (lv_ulong_temp >= utc_fraction_value[i])
        {
            lv_fraction_bit |= utc_fraction_bit[i];
            lv_ulong_temp -= utc_fraction_value[i];
        }
    }

    *(--lv_p_buffer) = lv_fraction_bit;
    *(--lv_p_buffer) = lv_fraction_bit >> 8;
    *(--lv_p_buffer) = lv_fraction_bit >> 16;

    lv_ulong_temp = usecond / 1000000u + 946684800u - time_zone;
    *(--lv_p_buffer) = lv_ulong_temp;
    *(--lv_p_buffer) = lv_ulong_temp >> 8;
    *(--lv_p_buffer) = lv_ulong_temp >> 16;
    *(--lv_p_buffer) = lv_ulong_temp >> 24;

    *(--lv_p_buffer) = 8u;
    *(--lv_p_buffer) = tag;

    *pp_buffer = lv_p_buffer;

    return NORMAL_SUCCESS;
}


