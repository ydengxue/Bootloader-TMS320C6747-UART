/*****************************************************************************************************
* FileName:                    SettingManage.c
*
* Description:                 ��ֵ�����ļ�
*
* Author:                      YanDengxue, Fiberhome-Fuhua
*
* Rev History:
*       <Author>        <Data>        <Hardware>     <Version>        <Description>
*     YanDengxue   2011-03-29 15:30       --           1.00             Create
*****************************************************************************************************/
//====================================================================================================
// ���ļ�ʹ�õ�ͷ�ļ�
//====================================================================================================
// ��ͷ�ļ�
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

// �Զ���ͷ�ļ�
#include "UserTypesDef.h"
#include "BaseData.h"
#include "SystemBase.h"
#include "ParseConfig.h"
#include "SettingManage.h"
#include "SpiFlash.h"
#include "Debug.h"

//====================================================================================================
// ���ļ���������ⲿ�Ľӿڱ���
//====================================================================================================
SETTING_GROUP setting_system;

//====================================================================================================
// ����ʵ��
//====================================================================================================
//----------------------------------------------------------------------------------------------------
// �ӿں���
//----------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------
//   Function: SettingReadFromFlash
//      Input: SETTING_GROUP const *p_setting_group: ��ֵ��
//     Output: void
//     Return: int32: ����ִ�����
//Description: ��flash�ж�����ֵ
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
int32 SettingReadFromFlash(SETTING_GROUP const *p_setting_group)
{
    if (NULL == p_setting_group)
    {
        TRACE("Function entry error!");
        return NORMAL_ERROR;
    }

    WinbondW25FastRead(p_setting_group->flash_addr, p_setting_group->flash_length, p_setting_group->run_buffer);
    if (0 != DefaultCrcCal(p_setting_group->run_buffer, p_setting_group->flash_length))
    {
        TRACE("parameter read crc error!");
        return NORMAL_ERROR;
    }

    if (NORMAL_SUCCESS != RunSettingAndWriteBufferUpdateFromRunBuffer(p_setting_group))
    {
        TRACE("Run setting update error!");
        return NORMAL_ERROR;
    }

    return NORMAL_SUCCESS;
}

//----------------------------------------------------------------------------------------------------
//   Function: SettingWriteToFlash
//      Input: SETTING_GROUP const *p_setting_group: ��ֵ��
//     Output: void
//     Return: int32: ����ִ�����
//Description: ����ֵд��flash
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
int32 SettingWriteToFlash(SETTING_GROUP const *p_setting_group)
{
    int32  i;
    Uint16 lv_crc;
    int32 lv_erase_length;

    if (NULL == p_setting_group)
    {
        TRACE("Function entry error!");
        return NORMAL_ERROR;
    }

    WinbondW25FastRead(p_setting_group->flash_addr, p_setting_group->flash_length, p_setting_group->history_buffer);

    lv_crc = DefaultCrcCal(p_setting_group->write_buffer, p_setting_group->flash_length - 2);
    p_setting_group->write_buffer[p_setting_group->flash_length - 2] = LLSB(lv_crc);
    p_setting_group->write_buffer[p_setting_group->flash_length - 1] = LHSB(lv_crc);

    lv_erase_length = p_setting_group->flash_length + (WINBOND_W25_SECTOR_SIZE - 1);
    lv_erase_length = lv_erase_length - (lv_erase_length % WINBOND_W25_SECTOR_SIZE);
    WinbondW25SectorErase(p_setting_group->flash_addr, lv_erase_length);
    WinbondW25PageWrite(p_setting_group->flash_addr, p_setting_group->flash_length, p_setting_group->write_buffer);
    WinbondW25FastRead(p_setting_group->flash_addr, p_setting_group->flash_length, p_setting_group->run_buffer);
    for (i = 0; i < p_setting_group->flash_length; i++)
    {
        if (p_setting_group->run_buffer[i] != p_setting_group->write_buffer[i])
        {
            TRACE("parameter write error!");
            return NORMAL_ERROR;
        }
    }

    return RunSettingUpdateFromRunBuffer(p_setting_group);
}

//----------------------------------------------------------------------------------------------------
//   Function: RunSettingUpdateFromRunBuffer
//      Input: SETTING_GROUP const *p_setting_group: ��ֵ��
//     Output: void
//     Return: int32: ����ִ�����
//Description: ���ж�ֵ����
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
int32 RunSettingUpdateFromRunBuffer(SETTING_GROUP const *p_setting_group)
{
    int32  i;
    Uint8 const *lv_p_stream;
    int32 lv_position;
    SETTING const *lv_p_setting;
    SIGNAL_DATA lv_signal_data;

    if (NULL == p_setting_group)
    {
        TRACE("Function entry error!");
        return NORMAL_ERROR;
    }

    lv_p_stream = p_setting_group->run_buffer;
    for (i = 0; i < p_setting_group->num; i++)
    {
        lv_p_setting = &p_setting_group->setting[i];
        lv_position = lv_p_setting->position;
        switch (lv_p_setting->define->type)
        {
            //�ַ�������SET_VAL_LEN_MAX�ֽ�
            case SIGNAL_DATA_TYPE_b:
            case SIGNAL_DATA_TYPE_c:
            {
                lv_signal_data.c =   lv_p_stream[lv_position];
                if ((0 == lv_p_setting->visible) && (lv_signal_data.c != lv_p_setting->default_value.c))
                {
                    TRACE("hide setting value=%d is not the default vlaue=%d", lv_signal_data.c, lv_p_setting->default_value.c);
                    return NORMAL_ERROR;
                }
                if ((lv_signal_data.c > lv_p_setting->max_value.c) || (lv_signal_data.c < lv_p_setting->min_value.c))
                {
                    TRACE("setting value=%d, exceed scope [%d,%d]", lv_signal_data.c, lv_p_setting->min_value.c, lv_p_setting->max_value.c);
                    return NORMAL_ERROR;
                }
                *((char *)lv_p_setting->define->addr) = lv_signal_data.c;
                break;
            }
            case SIGNAL_DATA_TYPE_uc:
            {
                lv_signal_data.uc =   lv_p_stream[lv_position];
                if ((0 == lv_p_setting->visible) && (lv_signal_data.uc != lv_p_setting->default_value.uc))
                {
                    TRACE("hide setting value=%d is not the default vlaue=%u", lv_signal_data.uc, lv_p_setting->default_value.uc);
                    return NORMAL_ERROR;
                }
                if ((lv_signal_data.uc > lv_p_setting->max_value.uc) || (lv_signal_data.uc < lv_p_setting->min_value.uc))
                {
                    TRACE("setting value=%u, exceed scope [%u,%u]", lv_signal_data.uc, lv_p_setting->min_value.uc, lv_p_setting->max_value.uc);
                    return NORMAL_ERROR;
                }
                *((Uint8 *)lv_p_setting->define->addr) = lv_signal_data.uc;
                break;
            }
            case SIGNAL_DATA_TYPE_i:
            {
                lv_signal_data.i =   lv_p_stream[lv_position]
                                    | (lv_p_stream[lv_position + 1] << 8);
                if ((0 == lv_p_setting->visible) && (lv_signal_data.i != lv_p_setting->default_value.i))
                {
                    TRACE("hide setting value=%d is not the default vlaue=%d", lv_signal_data.i, lv_p_setting->default_value.i);
                    return NORMAL_ERROR;
                }
                if ((lv_signal_data.i > lv_p_setting->max_value.i) || (lv_signal_data.i < lv_p_setting->min_value.i))
                {
                    TRACE("setting value=%d, exceed scope [%d,%d]", lv_signal_data.i, lv_p_setting->min_value.i, lv_p_setting->max_value.i);
                    return NORMAL_ERROR;
                }
                *((int16 *)lv_p_setting->define->addr) = lv_signal_data.i;
                break;
            }
            case SIGNAL_DATA_TYPE_ui:
            {
                lv_signal_data.ui =   lv_p_stream[lv_position]
                                     | (lv_p_stream[lv_position + 1] << 8);
                if ((0 == lv_p_setting->visible) && (lv_signal_data.ui != lv_p_setting->default_value.ui))
                {
                    TRACE("hide setting value=%d is not the default vlaue=%u", lv_signal_data.ui, lv_p_setting->default_value.ui);
                    return NORMAL_ERROR;
                }
                if ((lv_signal_data.ui > lv_p_setting->max_value.ui) || (lv_signal_data.ui < lv_p_setting->min_value.ui))
                {
                    TRACE("setting value=%u, exceed scope [%u,%u]", lv_signal_data.ui, lv_p_setting->min_value.ui, lv_p_setting->max_value.ui);
                    return NORMAL_ERROR;
                }
                *((Uint16 *)lv_p_setting->define->addr) = lv_signal_data.ui;
                break;
            }
            case SIGNAL_DATA_TYPE_l:
            {
                lv_signal_data.l =   lv_p_stream[lv_position]
                                    | (lv_p_stream[lv_position + 1] << 8)
                                    | (lv_p_stream[lv_position + 2] << 16)
                                    | (lv_p_stream[lv_position + 3] << 24);
                if ((0 == lv_p_setting->visible) && (lv_signal_data.l != lv_p_setting->default_value.l))
                {
                    TRACE("hide setting value=%d is not the default vlaue=%d", lv_signal_data.l, lv_p_setting->default_value.l);
                    return NORMAL_ERROR;
                }
                if ((lv_signal_data.l > lv_p_setting->max_value.l) || (lv_signal_data.l < lv_p_setting->min_value.l))
                {
                    TRACE("setting value=%d, exceed scope [%d,%d]", lv_signal_data.l, lv_p_setting->min_value.l, lv_p_setting->max_value.l);
                    return NORMAL_ERROR;
                }
                *((int32 *)lv_p_setting->define->addr) = lv_signal_data.l;
                break;
            }
            case SIGNAL_DATA_TYPE_ul:
            {
                lv_signal_data.ul =   lv_p_stream[lv_position]
                                     | (lv_p_stream[lv_position + 1] << 8)
                                     | (lv_p_stream[lv_position + 2] << 16)
                                     | (lv_p_stream[lv_position + 3] << 24);
                if ((0 == lv_p_setting->visible) && (lv_signal_data.ul != lv_p_setting->default_value.ul))
                {
                    TRACE("hide setting value=%u is not the default vlaue=%u", lv_signal_data.ul, lv_p_setting->default_value.ul);
                    return NORMAL_ERROR;
                }
                if ((lv_signal_data.ul > lv_p_setting->max_value.ul) || (lv_signal_data.ul < lv_p_setting->min_value.ul))
                {
                    TRACE("setting value=%u, exceed scope [%u,%u]", lv_signal_data.ul, lv_p_setting->min_value.ul, lv_p_setting->max_value.ul);
                    return NORMAL_ERROR;
                }
                *((Uint32 *)lv_p_setting->define->addr) = lv_signal_data.ul;
                break;
            }
            case SIGNAL_DATA_TYPE_f:
            {
                lv_signal_data.ul =   lv_p_stream[lv_position]
                                     | (lv_p_stream[lv_position + 1] << 8)
                                     | (lv_p_stream[lv_position + 2] << 16)
                                     | (lv_p_stream[lv_position + 3] << 24);
                if ((0 == lv_p_setting->visible) && (lv_signal_data.f != lv_p_setting->default_value.f))
                {
                    TRACE("hide setting value=%f is not the default vlaue=%f", lv_signal_data.f, lv_p_setting->default_value.f);
                    return NORMAL_ERROR;
                }
                if ((lv_signal_data.f > lv_p_setting->max_value.f) || (lv_signal_data.f < lv_p_setting->min_value.f))
                {
                    TRACE("setting value=%f, exceed scope [%f,%f]", lv_signal_data.f, lv_p_setting->min_value.f, lv_p_setting->max_value.f);
                    return NORMAL_ERROR;
                }
                *((float *)lv_p_setting->define->addr) = lv_signal_data.f;
                break;
            }
            //���ֽڳ��ȶ�ֵ
            default:
            {
                TRACE("unknow type=%d", lv_p_setting->define->type);
                return NORMAL_ERROR;
            }
        }
    }

    return NORMAL_SUCCESS;
}

//----------------------------------------------------------------------------------------------------
//   Function: RunSettingUpdateFromWriteBuffer
//      Input: SETTING_GROUP const *p_setting_group: ��ֵ��
//     Output: void
//     Return: int32: ����ִ�����
//Description: ���ж�ֵ����
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
int32 RunSettingUpdateFromWriteBuffer(SETTING_GROUP const *p_setting_group)
{
    int32  i;
    Uint8 const *lv_p_stream;
    int32 lv_position;
    SETTING const *lv_p_setting;
    SIGNAL_DATA lv_signal_data;

    if (NULL == p_setting_group)
    {
        TRACE("Function entry error!");
        return NORMAL_ERROR;
    }

    lv_p_stream = p_setting_group->write_buffer;
    for (i = 0; i < p_setting_group->num; i++)
    {
        lv_p_setting = &p_setting_group->setting[i];
        lv_position = lv_p_setting->position;
        switch (lv_p_setting->define->type)
        {
            //�ַ�������SET_VAL_LEN_MAX�ֽ�
            case SIGNAL_DATA_TYPE_b:
            case SIGNAL_DATA_TYPE_c:
            {
                lv_signal_data.c =   lv_p_stream[lv_position];
                if ((0 == lv_p_setting->visible) && (lv_signal_data.c != lv_p_setting->default_value.c))
                {
                    TRACE("hide setting value=%d is not the default vlaue=%d", lv_signal_data.c, lv_p_setting->default_value.c);
                    return NORMAL_ERROR;
                }
                if ((lv_signal_data.c > lv_p_setting->max_value.c) || (lv_signal_data.c < lv_p_setting->min_value.c))
                {
                    TRACE("setting value=%d, exceed scope [%d,%d]", lv_signal_data.c, lv_p_setting->min_value.c, lv_p_setting->max_value.c);
                    return NORMAL_ERROR;
                }
                *((char *)lv_p_setting->define->addr) = lv_signal_data.c;
                break;
            }
            case SIGNAL_DATA_TYPE_uc:
            {
                lv_signal_data.uc =   lv_p_stream[lv_position];
                if ((0 == lv_p_setting->visible) && (lv_signal_data.uc != lv_p_setting->default_value.uc))
                {
                    TRACE("hide setting value=%d is not the default vlaue=%u", lv_signal_data.uc, lv_p_setting->default_value.uc);
                    return NORMAL_ERROR;
                }
                if ((lv_signal_data.uc > lv_p_setting->max_value.uc) || (lv_signal_data.uc < lv_p_setting->min_value.uc))
                {
                    TRACE("setting value=%u, exceed scope [%u,%u]", lv_signal_data.uc, lv_p_setting->min_value.uc, lv_p_setting->max_value.uc);
                    return NORMAL_ERROR;
                }
                *((Uint8 *)lv_p_setting->define->addr) = lv_signal_data.uc;
                break;
            }
            case SIGNAL_DATA_TYPE_i:
            {
                lv_signal_data.i =   lv_p_stream[lv_position]
                                    | (lv_p_stream[lv_position + 1] << 8);
                if ((0 == lv_p_setting->visible) && (lv_signal_data.i != lv_p_setting->default_value.i))
                {
                    TRACE("hide setting value=%d is not the default vlaue=%d", lv_signal_data.i, lv_p_setting->default_value.i);
                    return NORMAL_ERROR;
                }
                if ((lv_signal_data.i > lv_p_setting->max_value.i) || (lv_signal_data.i < lv_p_setting->min_value.i))
                {
                    TRACE("setting value=%d, exceed scope [%d,%d]", lv_signal_data.i, lv_p_setting->min_value.i, lv_p_setting->max_value.i);
                    return NORMAL_ERROR;
                }
                *((int16 *)lv_p_setting->define->addr) = lv_signal_data.i;
                break;
            }
            case SIGNAL_DATA_TYPE_ui:
            {
                lv_signal_data.ui =   lv_p_stream[lv_position]
                                     | (lv_p_stream[lv_position + 1] << 8);
                if ((0 == lv_p_setting->visible) && (lv_signal_data.ui != lv_p_setting->default_value.ui))
                {
                    TRACE("hide setting value=%d is not the default vlaue=%u", lv_signal_data.ui, lv_p_setting->default_value.ui);
                    return NORMAL_ERROR;
                }
                if ((lv_signal_data.ui > lv_p_setting->max_value.ui) || (lv_signal_data.ui < lv_p_setting->min_value.ui))
                {
                    TRACE("setting value=%u, exceed scope [%u,%u]", lv_signal_data.ui, lv_p_setting->min_value.ui, lv_p_setting->max_value.ui);
                    return NORMAL_ERROR;
                }
                *((Uint16 *)lv_p_setting->define->addr) = lv_signal_data.ui;
                break;
            }
            case SIGNAL_DATA_TYPE_l:
            {
                lv_signal_data.l =   lv_p_stream[lv_position]
                                    | (lv_p_stream[lv_position + 1] << 8)
                                    | (lv_p_stream[lv_position + 2] << 16)
                                    | (lv_p_stream[lv_position + 3] << 24);
                if ((0 == lv_p_setting->visible) && (lv_signal_data.l != lv_p_setting->default_value.l))
                {
                    TRACE("hide setting value=%d is not the default vlaue=%d", lv_signal_data.l, lv_p_setting->default_value.l);
                    return NORMAL_ERROR;
                }
                if ((lv_signal_data.l > lv_p_setting->max_value.l) || (lv_signal_data.l < lv_p_setting->min_value.l))
                {
                    TRACE("setting value=%d, exceed scope [%d,%d]", lv_signal_data.l, lv_p_setting->min_value.l, lv_p_setting->max_value.l);
                    return NORMAL_ERROR;
                }
                *((int32 *)lv_p_setting->define->addr) = lv_signal_data.l;
                break;
            }
            case SIGNAL_DATA_TYPE_ul:
            {
                lv_signal_data.ul =   lv_p_stream[lv_position]
                                     | (lv_p_stream[lv_position + 1] << 8)
                                     | (lv_p_stream[lv_position + 2] << 16)
                                     | (lv_p_stream[lv_position + 3] << 24);
                if ((0 == lv_p_setting->visible) && (lv_signal_data.ul != lv_p_setting->default_value.ul))
                {
                    TRACE("hide setting value=%u is not the default vlaue=%u", lv_signal_data.ul, lv_p_setting->default_value.ul);
                    return NORMAL_ERROR;
                }
                if ((lv_signal_data.ul > lv_p_setting->max_value.ul) || (lv_signal_data.ul < lv_p_setting->min_value.ul))
                {
                    TRACE("setting value=%u, exceed scope [%u,%u]", lv_signal_data.ul, lv_p_setting->min_value.ul, lv_p_setting->max_value.ul);
                    return NORMAL_ERROR;
                }
                *((Uint32 *)lv_p_setting->define->addr) = lv_signal_data.ul;
                break;
            }
            case SIGNAL_DATA_TYPE_f:
            {
                lv_signal_data.ul =   lv_p_stream[lv_position]
                                     | (lv_p_stream[lv_position + 1] << 8)
                                     | (lv_p_stream[lv_position + 2] << 16)
                                     | (lv_p_stream[lv_position + 3] << 24);
                if ((0 == lv_p_setting->visible) && (lv_signal_data.f != lv_p_setting->default_value.f))
                {
                    TRACE("hide setting value=%f is not the default vlaue=%f", lv_signal_data.f, lv_p_setting->default_value.f);
                    return NORMAL_ERROR;
                }
                if ((lv_signal_data.f > lv_p_setting->max_value.f) || (lv_signal_data.f < lv_p_setting->min_value.f))
                {
                    TRACE("setting value=%f, exceed scope [%f,%f]", lv_signal_data.f, lv_p_setting->min_value.f, lv_p_setting->max_value.f);
                    return NORMAL_ERROR;
                }
                *((float *)lv_p_setting->define->addr) = lv_signal_data.f;
                break;
            }
            //���ֽڳ��ȶ�ֵ
            default:
            {
                TRACE("unknow type=%d", lv_p_setting->define->type);
                return NORMAL_ERROR;
            }
        }
    }

    return NORMAL_SUCCESS;
}

//----------------------------------------------------------------------------------------------------
//   Function: SettingWriteBufferUpdateFromRunBuffer
//      Input: SETTING_GROUP const *p_setting_group: ��ֵ��
//     Output: void
//     Return: int32: ����ִ�����
//Description: ����ֵд��flash
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
int32 SettingWriteBufferUpdateFromRunBuffer(SETTING_GROUP const *p_setting_group)
{
    if (NULL == p_setting_group)
    {
        TRACE("Function entry error!");
        return NORMAL_ERROR;
    }

    memcpy(p_setting_group->write_buffer, p_setting_group->run_buffer, p_setting_group->flash_length);

    return NORMAL_SUCCESS;
}

//----------------------------------------------------------------------------------------------------
//   Function: SettingRunBufferUpdateFromWriteBuffer
//      Input: SETTING_GROUP const *p_setting_group: ��ֵ��
//     Output: void
//     Return: int32: ����ִ�����
//Description: ����ֵд��flash
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
int32 SettingRunBufferUpdateFromWriteBuffer(SETTING_GROUP const *p_setting_group)
{
    if (NULL == p_setting_group)
    {
        TRACE("Function entry error!");
        return NORMAL_ERROR;
    }

    memcpy(p_setting_group->run_buffer, p_setting_group->write_buffer, p_setting_group->flash_length);

    return NORMAL_SUCCESS;
}

//----------------------------------------------------------------------------------------------------
//   Function: RunSettingAndWriteBufferUpdateFromRunBuffer
//      Input: SETTING_GROUP const *p_setting_group: ��ֵ��
//     Output: void
//     Return: int32: ����ִ�����
//Description: ���ж�ֵ����
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
int32 RunSettingAndWriteBufferUpdateFromRunBuffer(SETTING_GROUP const *p_setting_group)
{
    if (NULL == p_setting_group)
    {
        TRACE("Function entry error!");
        return NORMAL_ERROR;
    }

    if (    (NORMAL_SUCCESS != RunSettingUpdateFromRunBuffer(p_setting_group))
         || (NORMAL_SUCCESS != SettingWriteBufferUpdateFromRunBuffer(p_setting_group)))
    {
        TRACE("Run setting update from run buffer failed!");
        return NORMAL_ERROR;
    }

    return NORMAL_SUCCESS;
}

//----------------------------------------------------------------------------------------------------
//   Function: RunSettingAndRunBufferUpdateFromWriteBuffer
//      Input: SETTING_GROUP const *p_setting_group: ��ֵ��
//     Output: void
//     Return: int32: ����ִ�����
//Description: ����ֵд��flash
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
int32 RunSettingAndRunBufferUpdateFromWriteBuffer(SETTING_GROUP const *p_setting_group)
{

    if (NULL == p_setting_group)
    {
        TRACE("Function entry error!");
        return NORMAL_ERROR;
    }

    if (    (NORMAL_SUCCESS != RunSettingUpdateFromWriteBuffer(p_setting_group)
         || SettingRunBufferUpdateFromWriteBuffer(p_setting_group)))
    {
        TRACE("Run setting update from wirte buffer failed!");
        return NORMAL_ERROR;
    }

    return NORMAL_SUCCESS;
}


//----------------------------------------------------------------------------------------------------
//   Function: SettingToDefault
//      Input: SETTING_GROUP const *p_setting_group: ��ֵ��
//     Output: void
//     Return: int32: ����ִ�����
//Description: ���ж�ֵ����
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
int32 SettingToDefault(SETTING_GROUP const *p_setting_group)
{
    int32  i;
    Uint8 *lv_p_stream;
    int32  lv_position;
    SETTING const *lv_p_setting;

    if (NULL == p_setting_group)
    {
        TRACE("Function entry error!");
        return NORMAL_ERROR;
    }

    lv_p_stream = p_setting_group->run_buffer;
    for (i = 0; i < p_setting_group->num; i++)
    {
        lv_p_setting = &p_setting_group->setting[i];
        lv_position = lv_p_setting->position;
        switch (lv_p_setting->define->type)
        {
            //�ַ�������SET_VAL_LEN_MAX�ֽ�
            case SIGNAL_DATA_TYPE_b:
            case SIGNAL_DATA_TYPE_c:
            {
                if ((lv_p_setting->default_value.c > lv_p_setting->max_value.c) || (lv_p_setting->default_value.c < lv_p_setting->min_value.c))
                {
                    TRACE("default value=%d, exceed scope [%d,%d]", lv_p_setting->default_value.c, lv_p_setting->min_value.c, lv_p_setting->max_value.c);
                    return NORMAL_ERROR;
                }
                lv_p_stream[lv_position] = lv_p_setting->default_value.c;
                break;
            }
            case SIGNAL_DATA_TYPE_uc:
            {
                if ((lv_p_setting->default_value.uc > lv_p_setting->max_value.uc) || (lv_p_setting->default_value.uc < lv_p_setting->min_value.uc))
                {
                    TRACE("default  value=%u, exceed scope [%u,%u]", lv_p_setting->default_value.uc, lv_p_setting->min_value.uc, lv_p_setting->max_value.uc);
                    return NORMAL_ERROR;
                }
                lv_p_stream[lv_position] = lv_p_setting->default_value.uc;
                break;
            }
            case SIGNAL_DATA_TYPE_i:
            {
                if ((lv_p_setting->default_value.i > lv_p_setting->max_value.i) || (lv_p_setting->default_value.i < lv_p_setting->min_value.i))
                {
                    TRACE("default  value=%d, exceed scope [%d,%d]", lv_p_setting->default_value.i, lv_p_setting->min_value.i, lv_p_setting->max_value.i);
                    return NORMAL_ERROR;
                }
                lv_p_stream[lv_position] = LLSB(lv_p_setting->default_value.i);
                lv_p_stream[lv_position + 1] = LHSB(lv_p_setting->default_value.i);
                break;
            }
            case SIGNAL_DATA_TYPE_ui:
            {
                if ((lv_p_setting->default_value.ui > lv_p_setting->max_value.ui) || (lv_p_setting->default_value.ui < lv_p_setting->min_value.ui))
                {
                    TRACE("default  value=%u, exceed scope [%u,%u]", lv_p_setting->default_value.ui, lv_p_setting->min_value.ui, lv_p_setting->max_value.ui);
                    return NORMAL_ERROR;
                }
                lv_p_stream[lv_position] = LLSB(lv_p_setting->default_value.ui);
                lv_p_stream[lv_position + 1] = LHSB(lv_p_setting->default_value.ui);
                break;
            }
            case SIGNAL_DATA_TYPE_l:
            {
                if ((lv_p_setting->default_value.l > lv_p_setting->max_value.l) || (lv_p_setting->default_value.l < lv_p_setting->min_value.l))
                {
                    TRACE("default  value=%d, exceed scope [%d,%d]", lv_p_setting->default_value.l, lv_p_setting->min_value.l, lv_p_setting->max_value.l);
                    return NORMAL_ERROR;
                }
                lv_p_stream[lv_position] = LLSB(lv_p_setting->default_value.l);
                lv_p_stream[lv_position + 1] = LHSB(lv_p_setting->default_value.l);
                lv_p_stream[lv_position + 2] = HLSB(lv_p_setting->default_value.l);
                lv_p_stream[lv_position + 3] = HHSB(lv_p_setting->default_value.l);
                break;
            }
            case SIGNAL_DATA_TYPE_ul:
            {
                if ((lv_p_setting->default_value.ul > lv_p_setting->max_value.ul) || (lv_p_setting->default_value.ul < lv_p_setting->min_value.ul))
                {
                    TRACE("default  value=%d, exceed scope [%d,%d]", lv_p_setting->default_value.ul, lv_p_setting->min_value.ul, lv_p_setting->max_value.ul);
                    return NORMAL_ERROR;
                }
                lv_p_stream[lv_position] = LLSB(lv_p_setting->default_value.ul);
                lv_p_stream[lv_position + 1] = LHSB(lv_p_setting->default_value.ul);
                lv_p_stream[lv_position + 2] = HLSB(lv_p_setting->default_value.ul);
                lv_p_stream[lv_position + 3] = HHSB(lv_p_setting->default_value.ul);
                break;
            }
            case SIGNAL_DATA_TYPE_f:
            {
                if ((lv_p_setting->default_value.f > lv_p_setting->max_value.f) || (lv_p_setting->default_value.f < lv_p_setting->min_value.f))
                {
                    TRACE("default  value=%f, exceed scope [%f,%f]", lv_p_setting->default_value.f, lv_p_setting->min_value.f, lv_p_setting->max_value.f);
                    return NORMAL_ERROR;
                }
                lv_p_stream[lv_position] = LLSB(lv_p_setting->default_value.l);
                lv_p_stream[lv_position + 1] = LHSB(lv_p_setting->default_value.l);
                lv_p_stream[lv_position + 2] = HLSB(lv_p_setting->default_value.l);
                lv_p_stream[lv_position + 3] = HHSB(lv_p_setting->default_value.l);
                break;
            }
            //���ֽڳ��ȶ�ֵ
            default:
            {
                TRACE("unknow type=%d", lv_p_setting->define->type);
                return NORMAL_ERROR;
            }
        }
    }

    if (NORMAL_SUCCESS != RunSettingAndWriteBufferUpdateFromRunBuffer(p_setting_group))
    {
        TRACE("Run setting update to default error!");
        return NORMAL_ERROR;
    }

    return NORMAL_SUCCESS;
}

//----------------------------------------------------------------------------------------------------
//   Function: GetValueOfKeyWord
//      Input: char const *keyword: �ؼ���
//             char const *src: ��ת���ַ���
//             int32 type: ת������
//             SIGNAL_DATA: �������
//     Output: void
//     Return: int32: ����ִ�����
//Description: ���ж�ֵ����
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
int32 GetValueOfKeyWord(char const *keyword, char const *src, int32 type, SIGNAL_DATA *p_data)
{
    int32  lv_long_temp;
    char  lv_buffer[64];

    if ((NULL == keyword) || (NULL == src) || (NULL == p_data))
    {
        TRACE("function entry error");
        return NORMAL_ERROR;
    }

    if (NORMAL_SUCCESS != GetContentOfKeyword(keyword, src, lv_buffer, 64))
    {
        return NORMAL_ERROR;
    }

    switch (type)
    {
        case SIGNAL_DATA_TYPE_b :
        {
            lv_long_temp = strtol(lv_buffer, NULL, 0);
            if ((lv_long_temp < 0) || (lv_long_temp > 1))
            {
                TRACE("type=b scope is [0,1], but here is %d", lv_long_temp);
                return NORMAL_ERROR;
            }
            p_data->c = lv_long_temp;
            break;
        }
        case SIGNAL_DATA_TYPE_c :
        {
            lv_long_temp = strtol(lv_buffer, NULL, 0);
            if ((lv_long_temp < -128) || (lv_long_temp > 127))
            {
                TRACE("type=c scope is [-128,127], but here is %d", lv_long_temp);
                return NORMAL_ERROR;
            }
            p_data->c = lv_long_temp;
            break;
        }
        case SIGNAL_DATA_TYPE_uc :
        {
            lv_long_temp = strtol(lv_buffer, NULL, 0);
            if ((lv_long_temp < 0) || (lv_long_temp > 255))
            {
                TRACE("type=uc scope is [0,255], but here is %u", lv_long_temp);
                return NORMAL_ERROR;
            }
            p_data->uc = lv_long_temp;
            break;
        }
        case SIGNAL_DATA_TYPE_i :
        {
            lv_long_temp = strtol(lv_buffer, NULL,0);
            if ((lv_long_temp < -32768) || (lv_long_temp > 32767))
            {
                TRACE("type=i scope is [-32768,32767], but here is %d", lv_long_temp);
                return NORMAL_ERROR;
            }
            p_data->i = lv_long_temp;
            break;
        }
        case SIGNAL_DATA_TYPE_ui :
        {
            lv_long_temp = strtol(lv_buffer, NULL, 0);
            if ((lv_long_temp < 0) || (lv_long_temp > 65535))
            {
                TRACE("type=ui scope is [0,65535], but here is %u", lv_long_temp);
                return NORMAL_ERROR;
            }
            p_data->ui = lv_long_temp;
            break;
        }
        case SIGNAL_DATA_TYPE_l :
        {
            p_data->l = strtol(lv_buffer, NULL, 0);
            break;
        }
        case SIGNAL_DATA_TYPE_ul :
        {
            p_data->ul = strtoul(lv_buffer, NULL, 0);
            break;
        }
        case SIGNAL_DATA_TYPE_f :
        {
            p_data->f = strtod(lv_buffer, NULL);
            break;
        }
        default :
        {
            TRACE("unknow type=%d", type);
            return NORMAL_ERROR;
        }
    }
    return NORMAL_SUCCESS;
}

//----------------------------------------------------------------------------------------------------
//   Function: SettingManageInitial
//      Input: SETTING_GROUP *setting_group
//     Output: SETTING_GROUP *setting_group
//     Return: int32: ����ִ�����
//Description: ��ֵ�洢λ�ó�ʼ��
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2010-01-07 10:30           Create
//----------------------------------------------------------------------------------------------------
int32 SettingManageInitial(SETTING_GROUP *p_setting_group)
{
    int32  i;
    int32  lv_current_position;
    SETTING *lv_p_setting;

    if (NULL == p_setting_group)
    {
        TRACE("Function entry error!");
        return NORMAL_ERROR;
    }

    // ��λ��ֵ��EEPROM�е���λ�ú�λƫ��λ��
    lv_current_position = 0;
    for (i = 0; i < p_setting_group->num; i++)
    {
        lv_p_setting = &p_setting_group->setting[i];
        lv_p_setting->position = lv_current_position;
        switch (lv_p_setting->define->type)
        {
            //�ַ�������SET_VAL_LEN_MAX�ֽ�
            case SIGNAL_DATA_TYPE_b:
            case SIGNAL_DATA_TYPE_c:
            case SIGNAL_DATA_TYPE_uc:
            {
                lv_current_position += 1;
                break;
            }
            case SIGNAL_DATA_TYPE_i:
            case SIGNAL_DATA_TYPE_ui:
            {
                lv_current_position += 2;
                break;
            }
            case SIGNAL_DATA_TYPE_l:
            case SIGNAL_DATA_TYPE_ul:
            {
                lv_current_position += 4;
                break;
            }
            case SIGNAL_DATA_TYPE_f:
            {
                lv_current_position += 4;
                break;
            }
            //���ֽڳ��ȶ�ֵ
            default:
            {
                TRACE("unknow type=%d", lv_p_setting->define->type);
                return NORMAL_ERROR;
            }
        }
    }

    lv_current_position += 2;
    p_setting_group->flash_length = lv_current_position;
    p_setting_group->run_buffer = calloc(1, lv_current_position);
    if (NULL == p_setting_group->run_buffer)
    {
        TRACE("setting run buffer calloc failed");
        return NORMAL_ERROR;
    }

    p_setting_group->write_buffer = calloc(1, lv_current_position);
    if (NULL == p_setting_group->write_buffer)
    {
        TRACE("setting write buffer calloc failed");
        return NORMAL_ERROR;
    }

    p_setting_group->history_buffer = calloc(1, lv_current_position);
    if (NULL == p_setting_group->history_buffer)
    {
        TRACE("setting history buffer calloc failed");
        return NORMAL_ERROR;
    }

    if (NORMAL_SUCCESS != SettingToDefault(p_setting_group))
    {
        TRACE("setting to default value failed");
        return NORMAL_ERROR;
    }

    WinbondW25FastRead(p_setting_group->flash_addr, p_setting_group->flash_length, p_setting_group->history_buffer);

    return NORMAL_SUCCESS;
}

//----------------------------------------------------------------------------------------------------
//   Function: SetOneWriteSettingStringValue
//      Input: SETTING_GROUP const *p_setting_group: ��ֵ��
//     Output: void
//     Return: int32: ����ִ�����
//Description: ���ж�ֵ����
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
int32 SetOneWriteSettingStringValue(SETTING_GROUP const *p_setting_group, char const *p_str, int32 index)
{
    int32  lv_long_temp;
    Uint8 *lv_p_stream;
    int32  lv_position;
    int8   lv_default_flag;
    SIGNAL_DATA lv_signal_data;
    SETTING const *lv_p_setting;

    if ((NULL == p_setting_group) || (NULL == p_str))
    {
        TRACE("Function entry error!");
        return NORMAL_ERROR;
    }

    if (index >= p_setting_group->num)
    {
        TRACE("setting index=%d exceed max setting num %d", index, p_setting_group->num);
        return NORMAL_ERROR;
    }

    if (0 == strcmp(p_str, "default"))
    {
        lv_default_flag = 1;
    }
    else
    {
        lv_default_flag = 0;
    }

    lv_p_stream = p_setting_group->write_buffer;
    lv_p_setting = &p_setting_group->setting[index];
    lv_position = lv_p_setting->position;
    switch (lv_p_setting->define->type)
    {
        //�ַ�������SET_VAL_LEN_MAX�ֽ�
        case SIGNAL_DATA_TYPE_b:
        case SIGNAL_DATA_TYPE_c:
        {
            if (0 == lv_default_flag)
            {
                lv_long_temp = strtol(p_str, NULL, 0);
                if ((lv_long_temp > lv_p_setting->max_value.c) || (lv_long_temp < lv_p_setting->min_value.c))
                {
                    TRACE("set value=%d, exceed scope [%d,%d]", lv_long_temp, lv_p_setting->min_value.c, lv_p_setting->max_value.c);
                    return NORMAL_ERROR;
                }
                lv_signal_data.c = lv_long_temp;
            }
            else
            {
                lv_signal_data.c = lv_p_setting->default_value.c;
            }
            lv_p_stream[lv_position] = lv_signal_data.c;
            break;
        }
        case SIGNAL_DATA_TYPE_uc:
        {
            if (0 == lv_default_flag)
            {
                lv_long_temp = strtol(p_str, NULL, 0);
                if ((lv_long_temp > lv_p_setting->max_value.uc) || (lv_long_temp < lv_p_setting->min_value.uc))
                {
                    TRACE("set value=%u, exceed scope [%u,%u]", lv_long_temp, lv_p_setting->min_value.uc, lv_p_setting->max_value.uc);
                    return NORMAL_ERROR;
                }
                lv_signal_data.uc = lv_long_temp;
            }
            else
            {
                lv_signal_data.uc = lv_p_setting->default_value.uc;
            }
            lv_p_stream[lv_position] = lv_signal_data.uc;
            break;
        }
        case SIGNAL_DATA_TYPE_i:
        {
            if (0 == lv_default_flag)
            {
                lv_long_temp = strtol(p_str, NULL, 0);
                if ((lv_long_temp > lv_p_setting->max_value.i) || (lv_long_temp < lv_p_setting->min_value.i))
                {
                    TRACE("set value=%d, exceed scope [%d,%d]", lv_long_temp, lv_p_setting->min_value.i, lv_p_setting->max_value.i);
                    return NORMAL_ERROR;
                }
                lv_signal_data.i = lv_long_temp;
            }
            else
            {
                lv_signal_data.i = lv_p_setting->default_value.i;
            }
            lv_p_stream[lv_position] = LLSB(lv_signal_data.i);
            lv_p_stream[lv_position + 1] = LHSB(lv_signal_data.i);
            break;
        }
        case SIGNAL_DATA_TYPE_ui:
        {
            if (0 == lv_default_flag)
            {
                lv_long_temp = strtol(p_str, NULL, 0);
                if ((lv_long_temp > lv_p_setting->max_value.ui) || (lv_long_temp < lv_p_setting->min_value.ui))
                {
                    TRACE("set value=%u, exceed scope [%u,%u]", lv_long_temp, lv_p_setting->min_value.ui, lv_p_setting->max_value.ui);
                    return NORMAL_ERROR;
                }
                lv_signal_data.ui = lv_long_temp;
            }
            else
            {
                lv_signal_data.ui = lv_p_setting->default_value.ui;
            }
            lv_p_stream[lv_position] = LLSB(lv_signal_data.ui);
            lv_p_stream[lv_position + 1] = LHSB(lv_signal_data.ui);
            break;
        }
        case SIGNAL_DATA_TYPE_l:
        {
            if (0 == lv_default_flag)
            {
                lv_signal_data.l = strtol(p_str, NULL, 0);
                if ((lv_signal_data.l > lv_p_setting->max_value.l) || (lv_signal_data.l < lv_p_setting->min_value.l))
                {
                    TRACE("set value=%d, exceed scope [%d,%d]", lv_signal_data.l, lv_p_setting->min_value.l, lv_p_setting->max_value.l);
                    return NORMAL_ERROR;
                }
            }
            else
            {
                lv_signal_data.l = lv_p_setting->default_value.l;
            }
            lv_p_stream[lv_position] = LLSB(lv_signal_data.l);
            lv_p_stream[lv_position + 1] = LHSB(lv_signal_data.l);
            lv_p_stream[lv_position + 2] = HLSB(lv_signal_data.l);
            lv_p_stream[lv_position + 3] = HHSB(lv_signal_data.l);
            break;
        }
        case SIGNAL_DATA_TYPE_ul:
        {
            if (0 == lv_default_flag)
            {
                lv_signal_data.ul = strtoul(p_str, NULL, 0);
                if ((lv_signal_data.ul > lv_p_setting->max_value.ul) || (lv_signal_data.ul < lv_p_setting->min_value.ul))
                {
                    TRACE("set value=%d, exceed scope [%d,%d]", lv_signal_data.ul, lv_p_setting->min_value.ul, lv_p_setting->max_value.ul);
                    return NORMAL_ERROR;
                }
            }
            else
            {
                lv_signal_data.ul = lv_p_setting->default_value.ul;
            }
            lv_p_stream[lv_position] = LLSB(lv_signal_data.ul);
            lv_p_stream[lv_position + 1] = LHSB(lv_signal_data.ul);
            lv_p_stream[lv_position + 2] = HLSB(lv_signal_data.ul);
            lv_p_stream[lv_position + 3] = HHSB(lv_signal_data.ul);
            break;
        }
        case SIGNAL_DATA_TYPE_f:
        {
            if (0 == lv_default_flag)
            {
                lv_signal_data.f = strtod(p_str, NULL);
                if ((lv_signal_data.f > lv_p_setting->max_value.f) || (lv_signal_data.f < lv_p_setting->min_value.f))
                {
                    TRACE("set value=%f, exceed scope [%f,%f]", lv_signal_data.f, lv_p_setting->min_value.f, lv_p_setting->max_value.f);
                    return NORMAL_ERROR;
                }
            }
            else
            {
                lv_signal_data.f = lv_p_setting->default_value.f;
            }
            lv_p_stream[lv_position] = LLSB(lv_signal_data.l);
            lv_p_stream[lv_position + 1] = LHSB(lv_signal_data.l);
            lv_p_stream[lv_position + 2] = HLSB(lv_signal_data.l);
            lv_p_stream[lv_position + 3] = HHSB(lv_signal_data.l);
            break;
        }
        //���ֽڳ��ȶ�ֵ
        default:
        {
            TRACE("unknow type=%d", lv_p_setting->define->type);
            return NORMAL_ERROR;
        }
    }

    return NORMAL_SUCCESS;
}

//----------------------------------------------------------------------------------------------------
//   Function: CheckRunSettingWithFlash
//      Input: SETTING_GROUP const *p_setting_group: ��ֵ��
//     Output: void
//     Return: int32: ����ִ�����
//Description: ������ж�ֵ��flash��ֵ�Ƿ��в��
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
int32 CheckRunSettingWithFlash(SETTING_GROUP *p_setting_group)
{
    int32 i;
    Uint8 lv_byte_temp;

    for (i = 0; i < p_setting_group->flash_length; i++)
    {
        WinbondW25Read((p_setting_group->flash_addr + i), 1, &lv_byte_temp);
        if (p_setting_group->write_buffer[i] != lv_byte_temp)
        {
            p_setting_group->need_save_flag = 1;
            return NORMAL_ERROR;
        }
    }

    p_setting_group->need_save_flag = 0;
    return NORMAL_SUCCESS;
}

