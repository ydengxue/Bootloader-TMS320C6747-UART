/*****************************************************************************************************
* FileName:                    SpiEeprom.c
*
* Description:                 Eeprom������غ���
*
* Author:                      YanDengxue, Fiberhome-Fuhua
*
* Rev History:
*       <Author>        <Data>        <Hardware>     <Version>        <Description>
*     YanDengxue   2011-03-29 15:30       --           1.00             Create
*****************************************************************************************************/
//====================================================================================================
// ���ļ�ʹ�õ�ͷ�ļ�
//====================================================================================================
// �Զ���ͷ�ļ�
#include "UserTypesDef.h"
#include "C6747Register.h"
#include "SystemBase.h"
#include "Spi.h"
#include "SpiEeprom.h"
#include "Debug.h"

//====================================================================================================
// ���غ�������,�˴������ĺ��������ⲿ�ӿ�
//====================================================================================================
static int32 X25650WaitReady(Uint32 timeout);

//====================================================================================================
// ����ʵ��
//====================================================================================================
//----------------------------------------------------------------------------------------------------
//   Function: X25650ClaimBus
//      Input: void
//     Output: void
//     Return: int32: ����ִ�����
//Description: Initialze SPI Eeprom interface
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
int32 X25650ClaimBus(void)
{
    // Enable the SPI hardware
    pSPIEEPROM->SPIGCR0 = 0;
    DelayLoop(2000);
    pSPIEEPROM->SPIGCR0 = 1;

    // Set master mode, powered up and not activated
    pSPIEEPROM->SPIGCR1 = 3;

    // CS, CLK, SIMO and SOMI are functional pins
    pSPIEEPROM->SPIPC0 = (1 << 0) | (1 << 9) | (1 << 10) | (1 << 11);

    // setup format
    // scalar = ((clk_get(DAVINCI_SPI_CLKID) / ds->freq) - 1 ) & 0xFF;
    pSPIEEPROM->SPIFMT0 = X25650_DATA_LENGTH | (X25650_PRESCALE << 8) | (0 << 16) | (1 << 17) | (0 << 20);

    // release cs active at end of transfer until explicitly de-asserted
    pSPIEEPROM->SPIDAT1 = (0 << 28) | (0 << 16);

    // including a minor delay. No science here. Should be good even with no delay
    pSPIEEPROM->SPIDELAY = (8 << 24) | (8 << 16);

    // default chip select register
    pSPIEEPROM->SPIDEF = 1;

   // no interrupts
    pSPIEEPROM->SPIINT = 0;
    pSPIEEPROM->SPILVL = 0;

    // enable SPI
    pSPIEEPROM->SPIGCR1 |= ( 1 << 24 );

    return NORMAL_SUCCESS;
}

//----------------------------------------------------------------------------------------------------
//   Function: X25650ReleaseBus
//      Input: void
//     Output: void
//     Return: int32: ����ִ�����
//Description: �ͷ�X25650����
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
int32 X25650ReleaseBus(void)
{
    // Disable the SPI hardware
    pSPIEEPROM->SPIGCR0 = 0;

    return NORMAL_SUCCESS;
}

//----------------------------------------------------------------------------------------------------
//   Function: X25650Read
//      Input: Uint32 addr: �����ַ
//             Uint32 length: �������ݵĳ���
//     Output: Uint8 *buffer: �������ݻ����׵�ַ
//     Return: int32: ����ִ�����
//Description: X25650��������
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
int32 X25650Read(int32 addr, int32 length, Uint8 *buffer)
{
    Uint8 lv_cmd[3];

    if (NULL == buffer)
    {
        TRACE("function entrys error!");
        return NORMAL_ERROR;
    }

    if (0 == length)
    {
        TRACE("read length is 0");
        return NORMAL_SUCCESS;
    }

    lv_cmd[0] = X25650_CMD_READ;
    lv_cmd[1] = LHSB(addr);
    lv_cmd[2] = LLSB(addr);

//    X25650ClaimBus();
    SPIXferBytes(pSPIEEPROM, sizeof(lv_cmd), lv_cmd, NULL, 0);
    SPIXferBytes(pSPIEEPROM, length, NULL, buffer, 1);
//    X25650ReleaseBus();

    return NORMAL_SUCCESS;
}

//----------------------------------------------------------------------------------------------------
//   Function: X25650Write
//      Input: Uint32 addr: д���ַ
//             Uint32 length: д�����ݵĳ���
//             Uint8 const *buffer: ��д�������׵�ַ
//     Output: void
//     Return: int32: ����ִ�����
//Description: X25650д�뺯��
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
int32 X25650Write(int32 addr, int32 length, Uint8 const *buffer)
{
    Uint32 lv_chunk_start_offset;
    Uint32 lv_write_chunk_len;
    Uint32 lv_spi_write_addr;
    int32 lv_remainder_length;
    Uint8 lv_cmd[3];
    Uint8 const *lv_p_write_buffer;

    if (NULL == buffer)
    {
        TRACE("function entrys error!");
        return NORMAL_ERROR;
    }

    lv_spi_write_addr = addr;
    lv_p_write_buffer = buffer;
    lv_remainder_length = length;

//    X25650ClaimBus();

    lv_chunk_start_offset = lv_spi_write_addr % X25650_PAGE_SIZE;
    lv_cmd[0] = X25650_CMD_WRITE;
    while (lv_remainder_length > 0)
    {
        lv_write_chunk_len = (X25650_PAGE_SIZE - lv_chunk_start_offset);
        if (lv_remainder_length < lv_write_chunk_len)
        {
            lv_write_chunk_len = lv_remainder_length;
        }
        lv_chunk_start_offset = 0;

        SPIXferOneByte(pSPIEEPROM, X25650_CMD_WREN, 1);

        lv_cmd[1] = LHSB(lv_spi_write_addr);
        lv_cmd[2] = LLSB(lv_spi_write_addr);

        SPIXferBytes(pSPIEEPROM, sizeof(lv_cmd), lv_cmd, NULL, 0);
        SPIXferBytes(pSPIEEPROM, lv_write_chunk_len, lv_p_write_buffer, NULL, 1);

        if (NORMAL_SUCCESS != X25650WaitReady(X25650_PROG_TIMEOUT))
        {
            TRACE("X25650 page programming timed out");
            return NORMAL_ERROR;
        }

        lv_spi_write_addr += lv_write_chunk_len;
        lv_p_write_buffer += lv_write_chunk_len;
        lv_remainder_length -= lv_write_chunk_len;
    }

//    X25650ReleaseBus();
    return NORMAL_SUCCESS;
}

//----------------------------------------------------------------------------------------------------
// ���غ���
//----------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------
//   Function: X25650WaitReady
//      Input: Uint32 timeout: ��ȴ�ʱ��
//     Output: void
//     Return: int32: ����ִ�����
//Description: X25650�ȴ�������ɺ���
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
static int32 X25650WaitReady(Uint32 timeout)
{
    Uint8  lv_status;
    Uint32 lv_count;


    lv_count = timeout;
    do
    {
        SPIXferOneByte(pSPIEEPROM, X25650_CMD_RDSR, 0);
        SPIXferBytes(pSPIEEPROM, 1, NULL, &lv_status, 1);
        if (0 == (lv_status & X25650_STATUS_WIP))
        {
            break;
        }

        lv_count--;
    } while (0 != lv_count);

    SPIXferBytes(pSPIEEPROM, 0, NULL, NULL, 1);

    if (0 != lv_count)
    {
        return NORMAL_SUCCESS;
    }
    else
    {
        TRACE("Wait ready over time");
        return NORMAL_ERROR;
    }
}

