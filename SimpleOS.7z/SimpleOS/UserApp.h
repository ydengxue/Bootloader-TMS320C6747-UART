/*****************************************************************************************************
* FileName:                    UserApp.h
*
* Description:                 �û�����ͷ�ļ�
*
* Author:                      YanDengxue, Fiberhome-Fuhua
*
* Rev History:
*       <Author>        <Data>        <Hardware>     <Version>        <Description>
*     YanDengxue   2011-03-29 15:30       --           1.00             Create
*****************************************************************************************************/
#ifndef _User_App_H
#define _User_App_H

#ifdef __cplusplus
extern "C" {
#endif

//====================================================================================================
// �궨��
//====================================================================================================
//----------------------------------------------------------------------------------------------------
// DSP��FPGA�ӿ���ض���
//----------------------------------------------------------------------------------------------------
#define MU_CHANNEL_NUM           (24u)

#define FPGA_RX_FRAME_MERGE_NUM         64u// DSP�����FPGA���ݺϲ�֡��
#define FPGA_RX_FRAME_MERGE_MASK        (FPGA_RX_FRAME_MERGE_NUM - 1u)
#define FPGA_RX_FRAME_MERGE_ADDR(addr)  ((Uint16)((addr) & (FPGA_RX_FRAME_MERGE_MASK)))// DSP�����FPGA����֡��Ч��ַ

#define FPGA_DMA_RX_CHANNEL    (1u << 23u)
#define FPGA_DMA_TX_CHANNEL    (1u << 31u)
#define FPGA_TX_DMA_TRIGGER    (pEDMA3CC->ESR = FPGA_DMA_TX_CHANNEL)


//----------------------------------------------------------------------------------------------------
// �������
//----------------------------------------------------------------------------------------------------
#define DEBUG_UART_DESIRED_BAUD   (115200u)
#define DEBUG_UART_OVERSAMPLE_CNT (13u)
#define TRACE_ERROR(args) {DebugPrintf("%s:%d:%s: ", __FILE__, __LINE__, __FUNCTION__);  DebugPrintf(args); DebugPrintf("\r\n");}

//----------------------------------------------------------------------------------------------------
// Other
//----------------------------------------------------------------------------------------------------
#define FIR_COEFFICIENT_LENGTH 21u

//====================================================================================================
// �ṹ����
//====================================================================================================
typedef struct
{
    float  amplitude_coefficient;
    int16  delay_adjust;
    int16  phase_adjust;
    Uint8  status_bit[16];
    int32  data;
    int16  data_org;
    Uint32 quality;
} MERGING_UNIT_CHANNEL;

typedef struct
{
    Uint16  smp_freq;
    VUint16 smp_count;
    Uint16  sv_tx_fake_vlan;
    Uint16  goose_tx_fake_vlan;
    Uint8   test;
    Uint8   test_old;
    Uint8   fpga_pps_sync_flag;
    Uint8   pps_hold_flag;
    Uint8   pps_sync_flag;
    int32   pps_hold_width_cal;
    int32   delay_const_value;
    Uint32  delay_const_quality;

    float   primary_rated_voltage;
    float   primary_rated_current;

    MERGING_UNIT_CHANNEL channel[MU_CHANNEL_NUM];
} MERGING_UNIT;

typedef struct
{
    Uint8  device_status;
    Uint32 sv_emac_tx_count;
    Uint32 goose_emac_tx_count;
    Uint32 dma_event_miss_count;
    Uint32 emac_tx_error_count;
    Uint32 emac_tx_error_code;
} SYSTEM_STATISTICS;

//====================================================================================================
// �ⲿ��������
//====================================================================================================
extern Vint8 user_app_passby_mode;
extern Uint16 fpga_rx_data[FPGA_RX_FRAME_NUM][FPGA_RX_DATA_NUM];
extern Uint16 fpga_tx_data[FPGA_TX_DATA_NUM];
extern MERGING_UNIT mu;
extern SYSTEM_STATISTICS sys_statistics;
extern Uint8 emac_packet_data[258];

//====================================================================================================
// �ⲿ��������
//====================================================================================================
extern void  MainInterruptService(void);
extern void  UserApplication(void);
extern int32 UserApplicationInitial(void);
extern int32 UserApplicationSettingHandle(void);
extern void  ProjectDataHandle(void);
extern int32 DebugPrintf(const char *fmt, ...);

#ifdef __cplusplus
}
#endif

#endif

