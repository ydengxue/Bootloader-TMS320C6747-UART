/*****************************************************************************************************
* FileName:                    HardwareInital.c
*
* Description:                 Ӳ����ʼ������
*
* Author:                      YanDengxue, Fiberhome-Fuhua
*
* Rev History:
*       <Author>        <Data>        <Hardware>     <Version>        <Description>
*     YanDengxue   2011-03-29 15:30       --           1.00             Create
*****************************************************************************************************/
//====================================================================================================
// ���ļ�ʹ�õ�ͷ�ļ�
//====================================================================================================
// ��ͷ�ļ�
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

// �Զ���ͷ�ļ�
#include "UserTypesDef.h"
#include "C6747Register.h"
#include "SystemBase.h"
#include "BaseData.h"
#include "SpiFlash.h"
#include "SpiEeprom.h"
#include "LaserPowerControl.h"
#include "UserApp.h"

//====================================================================================================
// ���غ�������,�˴������ĺ��������ⲿ�ӿ�
//====================================================================================================
static int32 GPIOInitial(void);
static int32 DebugUARTInitial(void);
static int32 UART1Initial(void);
static int32 EMIFAInitial(void);
static int32 EmacInitial(void);
static int32 Edma3Initial(void);
static int32 InterruptInitial(void);
static int32 FpgaProgramDownload(void);

//====================================================================================================
// ���ر�������,�˴������ı��������ⲿ�ӿ�
//====================================================================================================
static EDMA3CC_PARAM_SET_REGS fpga_rx_emda3_param_set[2] =
{
    {
        0x00000000, FPGA_RX_DATA_ADDR,  ((FPGA_RX_FRAME_NUM << 16) | (FPGA_RX_DATA_NUM << 1)), (VUint32)fpga_rx_data,
        ((FPGA_RX_DATA_NUM << 1) << 16) | 0x0000, (FPGA_RX_FRAME_NUM << 16) | (Uint16)((Uint32)&pEDMA3CC->PARAMSET[65] - (Uint32)&pEDMA3CC->PARAMSET[0]), (0x0000 << 16) | 0x0000, (0x0000 << 16) | 0x0001
    },
    {
        0x00000000, FPGA_RX_DATA_ADDR,  ((FPGA_RX_FRAME_NUM << 16) | (FPGA_RX_DATA_NUM << 1)), (VUint32)fpga_rx_data,
        ((FPGA_RX_DATA_NUM << 1) << 16) | 0x0000, (FPGA_RX_FRAME_NUM << 16) | (Uint16)((Uint32)&pEDMA3CC->PARAMSET[64] - (Uint32)&pEDMA3CC->PARAMSET[0]), (0x0000 << 16) | 0x0000, (0x0000 << 16) | 0x0001
    }
};

static EDMA3CC_PARAM_SET_REGS const fpga_tx_emda3_param_set =
{
    0x0001F000, (VUint32)fpga_tx_data, (0x0001 << 16) | sizeof(fpga_tx_data), FPGA_TX_DATA_ADDR,
    (0x0000 << 16) | 0x0000, (0x0001 << 16) | (Uint16)((Uint32)&pEDMA3CC->PARAMSET[66] - (Uint32)&pEDMA3CC->PARAMSET[0]), (0x0000 << 16) | 0x0000,  (0x0000 << 16) | 0x0001
};

//====================================================================================================
// ����ʵ��
//====================================================================================================
//----------------------------------------------------------------------------------------------------
// �ӿں���
//----------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------
//   Function: HardwareInitial
//      Input: void
//     Output: void
//     Return: int32: ����ִ�����
//Description: Ӳ����ʼ������
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
int32 HardwareInitial(void)
{
    Vint32 lv_temp_ulong;
    Uint32 i;

    pSYSCFG->KICKR[0] = SYSCFG_UNLOCK0;// Kick0 register + data (unlock)
    pSYSCFG->KICKR[1] = SYSCFG_UNLOCK1;// Kick1 register + data (unlock)

    // Disable L2,L1P,L1D cache
    pCACHE->L2CFG  = 0;
    lv_temp_ulong  = pCACHE->L2CFG;
    pCACHE->L1PCFG = 0;
    lv_temp_ulong  = pCACHE->L1PCFG;
    pCACHE->L1DCFG = 0;
    lv_temp_ulong  = pCACHE->L1DCFG;

    // HardwareInitial
    FeedWatchDog();
    if (    (NORMAL_SUCCESS != InterruptVectorsInitial())
         || (NORMAL_SUCCESS != InterruptInitial())
         || (NORMAL_SUCCESS != GPIOInitial())
         || (NORMAL_SUCCESS != DebugUARTInitial())
         || (NORMAL_SUCCESS != EMIFAInitial())
         || (NORMAL_SUCCESS != WinbondW25ClaimBus())
         || (NORMAL_SUCCESS != X25650ClaimBus())
         || (NORMAL_SUCCESS != EmacInitial())
         || (NORMAL_SUCCESS != Edma3Initial())
         || (NORMAL_SUCCESS != UART1Initial()))
    {
        TRACE_ERROR("Hardware initial failed!");
        return NORMAL_ERROR;
    }

    FeedWatchDog();

    // Enable L2,L1P,L1D cache
    pCACHE->L1PCFG = 4;
    lv_temp_ulong  = pCACHE->L1PCFG;
    pCACHE->L1DCFG = 4;
    lv_temp_ulong  = pCACHE->L1DCFG;
    pCACHE->L2CFG  = 3;
    lv_temp_ulong = pCACHE->L2CFG;

    pCACHE->MAR[128] = 1;
    for (i = 0; i < 32; i++)
    {
        pCACHE->MAR[192 + i] = 1;
    }

    CLR_INTERRUPT_FLAG_MAIN;
    DISABLE_INTERRUPT_MAIN;
    ENABLE_INTERRUPT_COMMUNICATION;

    memset(fpga_rx_data, 0, sizeof(fpga_rx_data));
    memset(fpga_tx_data, 0, sizeof(fpga_tx_data));

    if (NORMAL_SUCCESS != FpgaProgramDownload())
    {
        TRACE_ERROR("Fpga program download failed!");
        return NORMAL_ERROR;
    }

    return NORMAL_SUCCESS;
}


//----------------------------------------------------------------------------------------------------
// ���غ���
//----------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------
//   Function: GPIOInitial
//      Input: void
//     Output: void
//     Return: int32: ����ִ�����
//Description: ͨ��������������ʼ��
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
static int32 GPIOInitial(void)
{
    pGPIO->CLR_DATA23 = GPIO_GP2P13 | GPIO_GP3P14;
    pGPIO->SET_DATA23 = GPIO_GP2P15;
    pGPIO->DIR23 = GPIO_GP2P12 | GPIO_GP3P15;
    pGPIO->DIR45 = GPIO_GP4P14 | GPIO_GP4P3 | GPIO_GP4P6;

    pGPIO->CLR_DATA45 = (GPIO_GP4P4 | GPIO_GP4P5 | GPIO_GP4P7);

    pGPIO->CLR_FAL_TRIG23 = GPIO_GP2P12 | GPIO_GP3P15;
    pGPIO->SET_RIS_TRIG23 = GPIO_GP2P12 | GPIO_GP3P15;

    pGPIO->CLR_FAL_TRIG45 = GPIO_GP4P14;
    pGPIO->SET_RIS_TRIG45 = GPIO_GP4P14;

    pGPIO->BINTEN = GPIO_BANK2 | GPIO_BANK3 | GPIO_BANK4;

    return NORMAL_SUCCESS;
}

//----------------------------------------------------------------------------------------------------
//   Function: DebugUARInitial
//      Input: void
//     Output: void
//     Return: int32: ����ִ�����
//Description: Debug���ڳ�ʼ������
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
static int32 DebugUARTInitial(void)
{
    Uint16 lv_divisor;

    lv_divisor = (FREQ_PLL0_SYSCLK2 / (DEBUG_UART_DESIRED_BAUD * DEBUG_UART_OVERSAMPLE_CNT));

    pDEBUG->PWREMU_MGNT = 0;
    pDEBUG->FCR = 0xF ;//FIFO mode, Clear UART TX & RX FIFOs 1bytes
    pDEBUG->LCR = 0x3;
    pDEBUG->IER = 0;
    pDEBUG->MCR = 0;
    pDEBUG->MDR = 1;
    pDEBUG->DLL = (Uint8)lv_divisor;
    pDEBUG->DLH = (Uint8)(lv_divisor >> 8);
    DelayLoop(4000);
    pDEBUG->PWREMU_MGNT |= 0x6001;

    DebugPrintf("\r\n");

    return NORMAL_SUCCESS;
}

//----------------------------------------------------------------------------------------------------
//   Function: UART1Initial
//      Input: void
//     Output: void
//     Return: int32: ����ִ�����
//Description: ����1��ʼ������
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
static int32 UART1Initial(void)
{
    Uint16 lv_divisor;

    lv_divisor = (FREQ_PLL0_SYSCLK2 / (UART1_DESIRED_BAUD * UART1_OVERSAMPLE_CNT));

    pUART1->PWREMU_MGNT = 0;
    pUART1->FCR = 0xF ;//FIFO mode, Clear UART TX & RX FIFOs 1bytes
    pUART1->LCR = 0x3;
    pUART1->IER = 0;
    pUART1->MCR = 0;
    pUART1->MDR = 1;
    pUART1->DLL = (Uint8)lv_divisor;
    pUART1->DLH = (Uint8)(lv_divisor >> 8);
    DelayLoop(4000);
    pUART1->PWREMU_MGNT |= 0x6001;

    return NORMAL_SUCCESS;
}
//----------------------------------------------------------------------------------------------------
//   Function: EMIFAInitial
//      Input: void
//     Output: void
//     Return: int32: ����ִ�����
//Description: EMIFA��ʼ������
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
static int32 EMIFAInitial(void)
{
    // Use extended wait cycles to keep CE low during NAND access
    pEMIFA->AWCC =   (0xff << 0)// maxinum extended wait cycles
                   | (0x01 << 28);// insert wait cycles if EMA_WAIT is high

    // Setup CS2 - 16-bit normal async */
    pEMIFA->CE2CFG =   (0x01 << 0)// Asynchronous 16 Bit Data bus width
                     | (0x03 << 2)// minimum EMA_CLK cysles between reads and write
                     | (0x00 << 4)// R_HOLD
                     | (0x03 << 7)// R_STROBE
                     | (0x01 << 13)// R_SETUP
                     | (0x01 << 17)// W_HOLD
                     | (0x03 << 20)// W_STROBE
                     | (0x00 << 26)// W_SETUP
                     | (0x00 << 30)// extend wait enable bit
                     | (0x00 << 31);// Select Strobe Mode Enable(1),Normal Mode Enable(0)

    pEMIFA->PMCR &= (~1);

    return NORMAL_SUCCESS;
}

//----------------------------------------------------------------------------------------------------
//   Function: EmacInitial
//      Input: void
//     Output: void
//     Return: int32: ����ִ�����
//Description: Emac��ʼ������
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
static int32 EmacInitial(void)
{
    Uint16 i;
    VUint32 *lv_p_reg;

    pGPIO->CLR_DATA45 = GPIO_GP4P10;
    DelayLoop(1000);
    pGPIO->SET_DATA45 = GPIO_GP4P10;

    // 0. Reset Ethernet
    pEMAC_CONTROL->SOFTRESET = 1;
    while (0 != pEMAC_CONTROL->SOFTRESET);
    DelayLoop(300);

    //  Init PHY / MDIO
    pMDIO->CONTROL = 0x40000020;// Enable MII interface ( MDIOCLK < 5MHz )
    DelayLoop(3000) ;

    // Force 100mbit, full duplex
    pMDIO->USERACCESS0 =   (0x3100 << 0 )// [15-0] Data
                         | (1 << 16 )// [20-16] PHY address
                         | (0 << 21 )// [25-21] PHY register address
                         | (0 << 29 )// [29] Ack
                         | (1 << 30 )// [30] Write
                         | (1 << 31 );// [31] Go

    while (0 != (pMDIO->USERACCESS0 & 0x80000000));// Wait for Results

    // Init EMAC
    // 1. Disable RX/TX interrupts (Ttanmit interrupt enable register )
    pEMAC_CONTROL->C0RXEN = 0x00000000;
    pEMAC_CONTROL->C0TXEN = 0x00000000;

    // 2. Clear the MAC control, receive control, & transmit control
    pEMAC->MACCONTROL = 0;
    pEMAC->RXCONTROL = 0;
    pEMAC->TXCONTROL = 0;

    // 3. Initialize all 16 header descriptor pointers RXnHDP & TXnHDP to zero
    //       (Receive/Transmit Channel 0 DMA Head Descriptor Point Register)
    pEMAC->RX0HDP = 0;
    pEMAC->RX1HDP = 0;
    pEMAC->RX2HDP = 0;
    pEMAC->RX3HDP = 0;
    pEMAC->RX4HDP = 0;
    pEMAC->RX5HDP = 0;
    pEMAC->RX6HDP = 0;
    pEMAC->RX7HDP = 0;

    pEMAC->TX0HDP = 0;
    pEMAC->TX1HDP = 0;
    pEMAC->TX2HDP = 0;
    pEMAC->TX3HDP = 0;
    pEMAC->TX4HDP = 0;
    pEMAC->TX5HDP = 0;
    pEMAC->TX6HDP = 0;
    pEMAC->TX7HDP = 0;

    // 4. Clear all 36 statistics registers by writing 0 (Good Receive Frames Register)
    lv_p_reg = &pEMAC->RXGOODFRAMES;
    for ( i = 0 ; i < 36 ; i++ )
    {
        lv_p_reg[i] = 0;
    }

    // 5. Setup the local Ethernet MAC address.  Be sure to program all 8 MAC addresses
    pEMAC->MACINDEX  = 0x00;
    pEMAC->MACADDRHI = 0x03020100;// Needs to be written only the first time
    pEMAC->MACADDRLO = 0x0504;

    pEMAC->MACINDEX  = 0x01;
    pEMAC->MACADDRLO = 0x1504;

    pEMAC->MACINDEX  = 0x02;
    pEMAC->MACADDRLO = 0x2504;

    pEMAC->MACINDEX  = 0x03;
    pEMAC->MACADDRLO = 0x3504;

    pEMAC->MACINDEX  = 0x04;
    pEMAC->MACADDRLO = 0x4504;

    pEMAC->MACINDEX  = 0x05;
    pEMAC->MACADDRLO = 0x5504;

    pEMAC->MACINDEX  = 0x06;
    pEMAC->MACADDRLO = 0x6504;

    pEMAC->MACINDEX  = 0x07;
    pEMAC->MACADDRLO = 0x7504;

    // 6. Initialize the receive channel N

    // 7. No multicast addressing
    pEMAC->MACHASH1 = 0;
    pEMAC->MACHASH2 = 0;

    // 8. Set RX buffer offset to 0.  Valid data always begins on the 1st byte
    pEMAC->RXBUFFEROFFSET = 0;

    // 9. Enable Unicast RX on channel 0-7
    pEMAC->RXUNICASTSET = 0xFF;

    // 10. Setup the RX( M )ulticast ( B )roadcast ( P )romiscuous channel
    // Enable multi-cast, broadcast and frames with errors
    pEMAC->RXMBPENABLE = 0x01e02020;

    // 11. Set the appropriate configuration bits in MACCONTROL (do not set the GMIIEN bit yet).
    pEMAC->MACCONTROL = 0
                       | ( 1 << 15 )// 100MHz RMII
                       | ( 0 << 9 )// Round robin
                       | ( 0 << 6 )// TX pacing disabled
                       | ( 0 << 5 )// GMII RX & TX
                       | ( 0 << 4 )// TX flow disabled
                       | ( 0 << 3 )// RX flow disabled
                       | ( 0 << 1 )// Loopback disabled
                       | ( 1 << 0 );// full duplex

    // 12. Clear all unused channel interrupt bits
    pEMAC->RXINTMASKCLEAR = 0xFF;
    pEMAC->TXINTMASKCLEAR = 0xFF;

    // 13. Enable the RX & TX channel interrupt bits.
    pEMAC->RXINTMASKSET = 0xFF;
    pEMAC->TXINTMASKSET = 0xFF;

    // Enable Host Error interrupts
    pEMAC->MACINTMASKCLEAR = ( 1 << 1 )// Host Error interrupt disable
                           | ( 1 << 0 );// Statistics interrupt disable
    pEMAC->MACINTMASKSET =   ( 1 << 1 )// Host Error interrupt mask
                           | ( 0 << 0 );// Statistics interrupt mask

    // 14. Initialize the receive and transmit descriptor list queues.

    // 15. Prepare receive by writing a pointer to the head of the receive buffer descriptor list to RXnHDP.
    pEMAC->MACSRCADDRHI = 0x03020100;// bytes 2-5
    pEMAC->MACSRCADDRLO = 0x0405;// bytes 0��1 - channel 0

    // 16. Enable the RX & TX DMA controllers. Then set GMIIEN
    // EMAC_RXCONTROL = 1;
    pEMAC->TXCONTROL = 1;
    pEMAC->MACCONTROL |= (1 << 5);

    return NORMAL_SUCCESS;
}

//----------------------------------------------------------------------------------------------------
//   Function: Edma3Initial
//      Input: void
//     Output: void
//     Return: int32: ����ִ�����
//Description: Edma��ʼ������,����fpga�ӿ�
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
static int32 Edma3Initial(void)
{
    int32 i;
    Uint32 *lv_p_dst_paramset;
    Uint32 const *lv_p_src_paramset;

    lv_p_src_paramset = (Uint32 const *)&fpga_rx_emda3_param_set[0];
    lv_p_dst_paramset = (Uint32 *)&pEDMA3CC->PARAMSET[23];
    for (i = 0; i < 8; i++)
    {
        lv_p_dst_paramset[i] = lv_p_src_paramset[i];
    }
    lv_p_dst_paramset = (Uint32 *)&pEDMA3CC->PARAMSET[64];
    for (i = 0; i < 8; i++)
    {
        lv_p_dst_paramset[i] = lv_p_src_paramset[i];
    }

    lv_p_src_paramset = (Uint32 const *)&fpga_rx_emda3_param_set[1];
    lv_p_dst_paramset = (Uint32 *)&pEDMA3CC->PARAMSET[65];
    for (i = 0; i < 8; i++)
    {
        lv_p_dst_paramset[i] = lv_p_src_paramset[i];
    }


    lv_p_src_paramset = (Uint32 const *)&fpga_tx_emda3_param_set;
    lv_p_dst_paramset = (Uint32 *)&pEDMA3CC->PARAMSET[31];
    for (i = 0; i < 8; i++)
    {
        lv_p_dst_paramset[i] = lv_p_src_paramset[i];
    }
    lv_p_dst_paramset = (Uint32 *)&pEDMA3CC->PARAMSET[66];
    for (i = 0; i < 8; i++)
    {
        lv_p_dst_paramset[i] = lv_p_src_paramset[i];
    }

    pEDMA3CC->QCHMAP[0] = 0x00000000;
    pEDMA3CC->QCHMAP[1] = 0x11110000;
    pEDMA3CC->QCHMAP[2] = 0x00001111;
    pEDMA3CC->QCHMAP[3] = 0x11111111;
    pEDMA3CC->EMCR = 0xffffffff;
    pEDMA3CC->CCERRCLR = 0xffffffff;
    pEDMA3CC->DRA[0].DRAE = 0x00000000;
    pEDMA3CC->DRA[1].DRAE = 0x00000001;
    pEDMA3CC->DRA[2].DRAE = 0x00000000;
    pEDMA3CC->DRA[3].DRAE = 0x00000000;

    return NORMAL_SUCCESS;
}

//----------------------------------------------------------------------------------------------------
//   Function: InterruptInitial
//      Input: void
//     Output: void
//     Return: int32: ����ִ�����
//Description: �жϳ�ʼ������
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
static int32 InterruptInitial(void)
{
    InterruptRegister(MainInterruptService, PRIORITY_MAIN_INTERRUPT, 54u, INTERRUPT_DISABLE);
    return NORMAL_SUCCESS;
}

//----------------------------------------------------------------------------------------------------
//   Function: FpgaProgramDownload
//      Input: void
//     Output: void
//     Return: int32 : ����ִ�����
//Description: FPGA��������
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
static int32 FpgaProgramDownload(void)
{
    Uint8  lv_buffer[SELF_BIN_HEADER_LENGTH];
    Uint32 lv_flash_addr;
    Uint32 lv_fpga_program_lenth;
    Uint8  *lv_fpga_program;

    lv_flash_addr = FLASH_FPGA_START_ADDR;
    WinbondW25Read(lv_flash_addr, SELF_BIN_HEADER_LENGTH, lv_buffer);
    if (    ((SELF_BIN_HEADER_LENGTH >> 2u) != lv_buffer[4])
         || (SELF_BIN_VERSION != lv_buffer[5])
         || (LLSB(BIN_FILE_TYPE_FPGA_PROGRAM) != lv_buffer[6])
         || (LHSB(BIN_FILE_TYPE_FPGA_PROGRAM) != lv_buffer[7])
         || ((0x01u) != lv_buffer[SELF_BIN_HEADER_LENGTH - 2])
         || ((0xA0u) != lv_buffer[SELF_BIN_HEADER_LENGTH - 1])
         || (0 != DefaultCrcCal(lv_buffer, SELF_BIN_HEADER_LENGTH)))
    {
        TRACE_ERROR("Fpga program header crc is error!");
        return NORMAL_ERROR;
    }

    lv_fpga_program_lenth = lv_buffer[0] | (lv_buffer[1] << 8) | (lv_buffer[2] << 16) | (lv_buffer[3] << 24);
    if (    (lv_fpga_program_lenth < (SELF_BIN_HEADER_LENGTH + 3 + 9))
         || (lv_fpga_program_lenth > (FLASH_FPGA_LENGTH - SELF_BIN_HEADER_LENGTH)))
    {
        TRACE_ERROR("Fpga program check error!");
        return NORMAL_ERROR;
    }

    lv_flash_addr += SELF_BIN_HEADER_LENGTH;
    lv_fpga_program = malloc(lv_fpga_program_lenth);
    if (NULL == lv_fpga_program)
    {
        TRACE_ERROR("Fpga program buffer malloc failed!");
        return NORMAL_ERROR;
    }

    WinbondW25FastRead(lv_flash_addr, lv_fpga_program_lenth, lv_fpga_program);
    if (0 != DefaultCrcCal(lv_fpga_program, lv_fpga_program_lenth))
    {
        TRACE_ERROR("Fpga program crc is error!");
        free(lv_fpga_program);
        return NORMAL_ERROR;
    }
    lv_fpga_program_lenth -= 9u;

    if (NORMAL_SUCCESS != FpgaSlaveSerialOutput(   lv_fpga_program, lv_fpga_program_lenth
                                                 , &pGPIO->IN_DATA45,  GPIO_GP4P3
                                                 , &pGPIO->IN_DATA45,  GPIO_GP4P6
                                                 , &pGPIO->OUT_DATA45, GPIO_GP4P4
                                                 , &pGPIO->OUT_DATA45, GPIO_GP4P5
                                                 , &pGPIO->OUT_DATA45, GPIO_GP4P7))
    {
        TRACE_ERROR("FPGA program download failed!");
        free(lv_fpga_program);
        return NORMAL_ERROR;
    }

    free(lv_fpga_program);
    return NORMAL_SUCCESS;
}


