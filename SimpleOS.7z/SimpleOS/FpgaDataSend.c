/*****************************************************************************************************
* FileName:                    FpgaDataSend.c
*
* Description:                 Fpga���ݻش�
*
* Author:                      YanDengxue, Fiberhome-Fuhua
*
* Rev History:
*       <Author>        <Data>        <Hardware>     <Version>        <Description>
*     YanDengxue   2011-03-29 15:30       --           1.00             Create
*****************************************************************************************************/
//====================================================================================================
// ���ļ�ʹ�õ�ͷ�ļ�
//====================================================================================================
// ��ͷ�ļ�
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

// �Զ���ͷ�ļ�
#include "UserTypesDef.h"
#include "C6747Register.h"
#include "SystemBase.h"
#include "FpgaDataSend.h"
#include "UserApp.h"

//====================================================================================================
// ���غ�������,�˴������ĺ��������ⲿ�ӿ�
//====================================================================================================
static Uint16 FT3DataCrcCal(Uint16 const *src, int32 length);

//====================================================================================================
// ���ļ���������ⲿ�Ľӿڱ���
//====================================================================================================
FT3 ft3;

//====================================================================================================
// ���ر�������,�˴������ı��������ⲿ�ӿ�
//====================================================================================================
static Uint16 const ft3_crc_tab[256] =
{
    0x0000, 0x3D65, 0x7ACA, 0x47AF, 0xF594, 0xC8F1, 0x8F5E, 0xB23B,
    0xD64D, 0xEB28, 0xAC87, 0x91E2, 0x23D9, 0x1EBC, 0x5913, 0x6476,
    0x91FF, 0xAC9A, 0xEB35, 0xD650, 0x646B, 0x590E, 0x1EA1, 0x23C4,
    0x47B2, 0x7AD7, 0x3D78, 0x001D, 0xB226, 0x8F43, 0xC8EC, 0xF589,
    0x1E9B, 0x23FE, 0x6451, 0x5934, 0xEB0F, 0xD66A, 0x91C5, 0xACA0,
    0xC8D6, 0xF5B3, 0xB21C, 0x8F79, 0x3D42, 0x0027, 0x4788, 0x7AED,
    0x8F64, 0xB201, 0xF5AE, 0xC8CB, 0x7AF0, 0x4795, 0x003A, 0x3D5F,
    0x5929, 0x644C, 0x23E3, 0x1E86, 0xACBD, 0x91D8, 0xD677, 0xEB12,
    0x3D36, 0x0053, 0x47FC, 0x7A99, 0xC8A2, 0xF5C7, 0xB268, 0x8F0D,
    0xEB7B, 0xD61E, 0x91B1, 0xACD4, 0x1EEF, 0x238A, 0x6425, 0x5940,
    0xACC9, 0x91AC, 0xD603, 0xEB66, 0x595D, 0x6438, 0x2397, 0x1EF2,
    0x7A84, 0x47E1, 0x004E, 0x3D2B, 0x8F10, 0xB275, 0xF5DA, 0xC8BF,
    0x23AD, 0x1EC8, 0x5967, 0x6402, 0xD639, 0xEB5C, 0xACF3, 0x9196,
    0xF5E0, 0xC885, 0x8F2A, 0xB24F, 0x0074, 0x3D11, 0x7ABE, 0x47DB,
    0xB252, 0x8F37, 0xC898, 0xF5FD, 0x47C6, 0x7AA3, 0x3D0C, 0x0069,
    0x641F, 0x597A, 0x1ED5, 0x23B0, 0x918B, 0xACEE, 0xEB41, 0xD624,
    0x7A6C, 0x4709, 0x00A6, 0x3DC3, 0x8FF8, 0xB29D, 0xF532, 0xC857,
    0xAC21, 0x9144, 0xD6EB, 0xEB8E, 0x59B5, 0x64D0, 0x237F, 0x1E1A,
    0xEB93, 0xD6F6, 0x9159, 0xAC3C, 0x1E07, 0x2362, 0x64CD, 0x59A8,
    0x3DDE, 0x00BB, 0x4714, 0x7A71, 0xC84A, 0xF52F, 0xB280, 0x8FE5,
    0x64F7, 0x5992, 0x1E3D, 0x2358, 0x9163, 0xAC06, 0xEBA9, 0xD6CC,
    0xB2BA, 0x8FDF, 0xC870, 0xF515, 0x472E, 0x7A4B, 0x3DE4, 0x0081,
    0xF508, 0xC86D, 0x8FC2, 0xB2A7, 0x009C, 0x3DF9, 0x7A56, 0x4733,
    0x2345, 0x1E20, 0x598F, 0x64EA, 0xD6D1, 0xEBB4, 0xAC1B, 0x917E,
    0x475A, 0x7A3F, 0x3D90, 0x00F5, 0xB2CE, 0x8FAB, 0xC804, 0xF561,
    0x9117, 0xAC72, 0xEBDD, 0xD6B8, 0x6483, 0x59E6, 0x1E49, 0x232C,
    0xD6A5, 0xEBC0, 0xAC6F, 0x910A, 0x2331, 0x1E54, 0x59FB, 0x649E,
    0x00E8, 0x3D8D, 0x7A22, 0x4747, 0xF57C, 0xC819, 0x8FB6, 0xB2D3,
    0x59C1, 0x64A4, 0x230B, 0x1E6E, 0xAC55, 0x9130, 0xD69F, 0xEBFA,
    0x8F8C, 0xB2E9, 0xF546, 0xC823, 0x7A18, 0x477D, 0x00D2, 0x3DB7,
    0xC83E, 0xF55B, 0xB2F4, 0x8F91, 0x3DAA, 0x00CF, 0x4760, 0x7A05,
    0x1E73, 0x2316, 0x64B9, 0x59DC, 0xEBE7, 0xD682, 0x912D, 0xAC48
};

//====================================================================================================
// ����ʵ��
//====================================================================================================
//----------------------------------------------------------------------------------------------------
// �ӿں���
//----------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------
//   Function: FpgaPacketSend
//      Input: Uint16 *dst_buffer :
//     Output: void
//     Return: void
//Description: FPGA�������ݰ�����
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
void FpgaDataSend(Uint16 *dst_buffer)
{
    Uint16 i;
    Uint32 lv_status;
    Uint16 lv_ushort_temp;
    Uint8  lv_ft3_to_local_channel_map;
    Uint8 const *lv_p_ft3_to_local_channel_map;
    MERGING_UNIT_CHANNEL const *lv_p_channel;

    // �����������ﵽ������pps����0����������
    lv_p_channel = mu.channel;
    lv_p_ft3_to_local_channel_map = ft3.local_channel_map;

    dst_buffer[0u] = (mu.pps_hold_width_cal);
    dst_buffer[1u] = (mu.pps_hold_width_cal) >> 16u;

    dst_buffer[FT3_FRAME_START_ADDR] = FT3_FRAME_HEADER;

    // block1
    dst_buffer[FT3_FRAME_START_ADDR - 1u] = FT3_FRAME_LENGTH;
    dst_buffer[FT3_FRAME_START_ADDR - 2u] = (ft3.ln_name << 8) | ft3.data_set;
    dst_buffer[FT3_FRAME_START_ADDR - 3u] = ft3.ld_name;
    dst_buffer[FT3_FRAME_START_ADDR - 4u] = ft3.rated_current;
    dst_buffer[FT3_FRAME_START_ADDR - 5u] = ft3.rated_neutral_current;
    dst_buffer[FT3_FRAME_START_ADDR - 6u] = ft3.rated_voltage;
    dst_buffer[FT3_FRAME_START_ADDR - 7u] = ft3.delay;
    dst_buffer[FT3_FRAME_START_ADDR - 8u] = mu.smp_count;
    dst_buffer[FT3_FRAME_START_ADDR - 9u] = FT3DataCrcCal(&dst_buffer[FT3_FRAME_START_ADDR - 1u], 8u);

    // block2 10, 11, 12, 13, 14, 15, 16, 17
    lv_status = 0;
    for (i = 0u; i < 8u; i++)
    {
        lv_ft3_to_local_channel_map = lv_p_ft3_to_local_channel_map[i];
        if (0 != lv_ft3_to_local_channel_map)
        {
            lv_ft3_to_local_channel_map--;
            dst_buffer[(FT3_FRAME_START_ADDR - 10u) - i] = lv_p_channel[lv_ft3_to_local_channel_map].data_org;
            lv_status |= (lv_p_channel[lv_ft3_to_local_channel_map].status_bit[0] << i);
        }
        else
        {
            dst_buffer[(FT3_FRAME_START_ADDR - 10u) - i] = 0;
            lv_status |=  (1u << i);
        }
    }
    dst_buffer[FT3_FRAME_START_ADDR - 18u] = FT3DataCrcCal(&dst_buffer[FT3_FRAME_START_ADDR - 10u], 8u);

    // block3 19, 20, 21, 22, 23, 24, 25, 26
    for (i = 0u; i < 8u; i++)
    {
        lv_ft3_to_local_channel_map = lv_p_ft3_to_local_channel_map[8u + i];
        if (0 != lv_ft3_to_local_channel_map)
        {
            lv_ft3_to_local_channel_map--;
            dst_buffer[(FT3_FRAME_START_ADDR - 19u) - i] = lv_p_channel[lv_ft3_to_local_channel_map].data_org;
            lv_status |= (lv_p_channel[lv_ft3_to_local_channel_map].status_bit[0] << (8u + i));
        }
        else
        {
            dst_buffer[(FT3_FRAME_START_ADDR - 19u) - i] = 0;
            lv_status |=  (1u << (8u + i));
        }
    }
    dst_buffer[FT3_FRAME_START_ADDR - 27u] = FT3DataCrcCal(&dst_buffer[FT3_FRAME_START_ADDR - 19u], 8u);

    // block4 28, 29, 30, 31, 32, 33, 34, 35
    for (i = 0u; i < 8u; i++)
    {
        lv_ft3_to_local_channel_map = lv_p_ft3_to_local_channel_map[16u + i];
        if (0 != lv_ft3_to_local_channel_map)
        {
            lv_ft3_to_local_channel_map--;
            dst_buffer[(FT3_FRAME_START_ADDR - 28u) - i] = lv_p_channel[lv_ft3_to_local_channel_map].data_org;
            lv_status |= (lv_p_channel[lv_ft3_to_local_channel_map].status_bit[0] << (16u + i));
        }
        else
        {
            dst_buffer[(FT3_FRAME_START_ADDR - 28u) - i] = 0;
            lv_status |=  (1u << (16u + i));
        }
    }
    dst_buffer[FT3_FRAME_START_ADDR - 36u] = FT3DataCrcCal(&dst_buffer[FT3_FRAME_START_ADDR - 28u], 8u);

    ft3.status1 = 0u;
    ft3.status1 |= (mu.test << 1u);
    ft3.status1 |= (1u << 3u);
    ft3.status1 |= ((mu.pps_sync_flag ^ 1u) << 4u);
    ft3.status1 |= ((lv_status & 0x7Fu) << 5u);
    ft3.status1 |= ((lv_status >> 9u) & 0x4000u);
    ft3.status2 = (lv_status >> 7u);

    // block5
    dst_buffer[FT3_FRAME_START_ADDR - 37u] = 0u;
    dst_buffer[FT3_FRAME_START_ADDR - 38u] = 0u;
    dst_buffer[FT3_FRAME_START_ADDR - 39u] = 0u;
    dst_buffer[FT3_FRAME_START_ADDR - 40u] = 0u;
    dst_buffer[FT3_FRAME_START_ADDR - 41u] = 0u;
    dst_buffer[FT3_FRAME_START_ADDR - 42u] = 0u;
    dst_buffer[FT3_FRAME_START_ADDR - 43u] = ft3.status1;
    dst_buffer[FT3_FRAME_START_ADDR - 44u] = ft3.status2;
    dst_buffer[FT3_FRAME_START_ADDR - 45u] = FT3DataCrcCal(&dst_buffer[FT3_FRAME_START_ADDR - 37u], 8u);

    dst_buffer[FT3_FRAME_START_ADDR - 46u] = 0xffffu;

    switch (sys_cfg.sync_mode)
    {
        case 0:
        {
            lv_ushort_temp = 0x06;
            break;
        }
        case 1:
        {
            lv_ushort_temp = 0x05;
            break;
        }
        case 2:
        {
            lv_ushort_temp = 0x01;
            break;
        }
        case 3:
        {
            lv_ushort_temp = 0x07;
            break;
        }
        default:
        {
            lv_ushort_temp = 0x00;
            break;
        }
    }

    dst_buffer[49u] = lv_ushort_temp;

    FPGA_TX_DMA_TRIGGER;
}

//----------------------------------------------------------------------------------------------------
// ���غ���
//----------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------
//   Function: FT3DataCrcCal
//      Input: Uint16 const *src :
//             int32 length :
//     Output: void
//     Return: void
//Description: FT3CRC����
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
static Uint16 FT3DataCrcCal(Uint16 const *src, int32 length)
{
    int32  lv_index;
    Uint16 lv_crc;
    Uint16 lv_data;
    Uint8  lv_byte_temp;
    Uint8  lv_crc_index;

    lv_crc = 0;
    for (lv_index = 0; lv_index < length; lv_index++)
    {
        lv_data = *(src--);

        lv_byte_temp = lv_data >> 8u;
        lv_crc_index = (lv_crc >> 8u) ^ lv_byte_temp;
        lv_crc = ft3_crc_tab[lv_crc_index] ^ (lv_crc << 8u);

        lv_byte_temp = lv_data;
        lv_crc_index = (lv_crc >> 8u) ^ lv_byte_temp;
        lv_crc = ft3_crc_tab[lv_crc_index] ^ (lv_crc << 8u);
    }

    return ~lv_crc;
}

