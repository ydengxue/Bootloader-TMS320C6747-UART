/*****************************************************************************************************
* FileName:                    IconvData.h
*
* Description:                 Iconv�ӿ����ͷ�ļ�
*                              
* Author:                      YanDengxue, Fiberhome-Fuhua
*                              
* Rev History:  
*       <Author>        <Data>        <Hardware>     <Version>        <Description>
*     YanDengxue   2011-03-29 15:30       --           1.00             Create
*****************************************************************************************************/
#ifndef _Iconv_Data_H
#define _Iconv_Data_H

#ifdef __cplusplus
extern "C" {
#endif

//====================================================================================================
// ���Ͷ���
//====================================================================================================
// ucs4���뺯������
typedef int32 (*ICONVDATA_UCS4_ENCODE)(Uint32, int8 *, int32);

//====================================================================================================
// �ⲿ��������
//====================================================================================================
// UTF8�����UCS4
extern int32 Utf8ToUcs4(int8 const *source, int32 source_char_length, Uint32 *destination);

// ����p_encode_type_string��ָ��ucs4���뷽ʽ�ı��뺯��,NULL��ʾδ�ҵ���Ӧ���뺯��
int32 IconvDataEncodeFuntion(int8 const *p_encode_type_string, ICONVDATA_UCS4_ENCODE *p_function);

#ifdef __cplusplus
}
#endif

#endif
