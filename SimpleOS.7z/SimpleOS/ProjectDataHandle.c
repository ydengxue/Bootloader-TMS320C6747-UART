/*****************************************************************************************************
* FileName:                    ProjectDataHandle.c
*
* Description:                 �����������ݴ���
*
* Author:                      YanDengxue, Fiberhome-Fuhua
*
* Rev History:
*       <Author>        <Data>        <Hardware>     <Version>        <Description>
*     YanDengxue   2011-03-29 15:30       --           1.00             Create
*****************************************************************************************************/
//====================================================================================================
// ���ļ�ʹ�õ�ͷ�ļ�
//====================================================================================================
// ��ͷ�ļ�
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

// �Զ���ͷ�ļ�
#include "UserTypesDef.h"
#include "C6747Register.h"
#include "SystemBase.h"
#include "BaseData.h"
#include "Sv.h"
#include "Goose.h"
#include "ProjectDataHandle.h"
#include "UserApp.h"

//====================================================================================================
// ���ļ���������ⲿ�Ľӿڱ���
//====================================================================================================
PROJECT_CFG  prj_cfg;

//====================================================================================================
// ����ʵ��
//====================================================================================================
//----------------------------------------------------------------------------------------------------
// �ӿں���
//----------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------
//   Function: ProjectDataHandle
//      Input: void
//     Output: void
//     Return: void
//Description: �����������ݴ���
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
void ProjectDataHandle(void)
{
    Uint32 lv_intr_flags;
    volatile EMAC_DESCRIPTOR_REGS *lv_p_emac_desc_tmp;

    lv_intr_flags = pEMAC->MACINVECTOR;// Check interrupt flag ��MAC Input Vector Register��
    if (0 != (lv_intr_flags & EMAC_MACINVECTOR_HOSTPEND))
    {
        sys_statistics.emac_tx_error_code = pEMAC->MACSTATUS;// Error code
        sys_statistics.emac_tx_error_count++;
    }

    if (0 != (lv_intr_flags & SV_EMAC_MACINVECTOR_TXPEND))
    {
        lv_p_emac_desc_tmp = pEMAC->TX0CP;
        if (NULL == lv_p_emac_desc_tmp->next)
        {
            sys_statistics.sv_emac_tx_count++;
        }
        pEMAC->TX0CP = lv_p_emac_desc_tmp;
    }

    if (0 != (lv_intr_flags & GOOSE_EMAC_MACINVECTOR_TXPEND))
    {
        lv_p_emac_desc_tmp = pEMAC->TX1CP;
        if (NULL == lv_p_emac_desc_tmp->next)
        {
            sys_statistics.goose_emac_tx_count++;
        }
        pEMAC->TX1CP = lv_p_emac_desc_tmp;
    }

    SvPacketSend();
    GoosePacketSend();
}

