/*****************************************************************************************************
* FileName:                    ProjectData.c
*
* Description:                 ������������ļ�
*
* Author:                      YanDengxue, Fiberhome-Fuhua
*
* Rev History:
*       <Author>        <Data>        <Hardware>     <Version>        <Description>
*     YanDengxue   2011-03-29 15:30       --           1.00             Create
*****************************************************************************************************/
//====================================================================================================
// ���ļ�ʹ�õ�ͷ�ļ�
//====================================================================================================
// ��ͷ�ļ�
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

// �Զ���ͷ�ļ�
#include "UserTypesDef.h"
#include "SystemBase.h"
#include "BaseData.h"
#include "UserApp.h"

//====================================================================================================
// ���ļ���������ⲿ�Ľӿڱ���
//====================================================================================================
SIGNAL_DEFINE const sv_signal_out_define[] =
{
    {"delay_v", &mu.delay_const_value,   SIGNAL_DATA_TYPE_l},
    {"delay_q", &mu.delay_const_quality, SIGNAL_DATA_TYPE_ul},

    {"ch01_v",  &mu.channel[0 ].data,    SIGNAL_DATA_TYPE_l},
    {"ch01_q",  &mu.channel[0 ].quality, SIGNAL_DATA_TYPE_ul},

    {"ch02_v",  &mu.channel[1 ].data,    SIGNAL_DATA_TYPE_l},
    {"ch02_q",  &mu.channel[1 ].quality, SIGNAL_DATA_TYPE_ul},

    {"ch03_v",  &mu.channel[2 ].data,    SIGNAL_DATA_TYPE_l},
    {"ch03_q",  &mu.channel[2 ].quality, SIGNAL_DATA_TYPE_ul},

    {"ch04_v",  &mu.channel[3 ].data,    SIGNAL_DATA_TYPE_l},
    {"ch04_q",  &mu.channel[3 ].quality, SIGNAL_DATA_TYPE_ul},

    {"ch05_v",  &mu.channel[4 ].data,    SIGNAL_DATA_TYPE_l},
    {"ch05_q",  &mu.channel[4 ].quality, SIGNAL_DATA_TYPE_ul},

    {"ch06_v",  &mu.channel[5 ].data,    SIGNAL_DATA_TYPE_l},
    {"ch06_q",  &mu.channel[5 ].quality, SIGNAL_DATA_TYPE_ul},

    {"ch07_v",  &mu.channel[6 ].data,    SIGNAL_DATA_TYPE_l},
    {"ch07_q",  &mu.channel[6 ].quality, SIGNAL_DATA_TYPE_ul},

    {"ch08_v",  &mu.channel[7 ].data,    SIGNAL_DATA_TYPE_l},
    {"ch08_q",  &mu.channel[7 ].quality, SIGNAL_DATA_TYPE_ul},

    {"ch09_v",  &mu.channel[8 ].data,    SIGNAL_DATA_TYPE_l},
    {"ch09_q",  &mu.channel[8 ].quality, SIGNAL_DATA_TYPE_ul},

    {"ch10_v",  &mu.channel[9 ].data,    SIGNAL_DATA_TYPE_l},
    {"ch10_q",  &mu.channel[9 ].quality, SIGNAL_DATA_TYPE_ul},

    {"ch11_v",  &mu.channel[10].data,    SIGNAL_DATA_TYPE_l},
    {"ch11_q",  &mu.channel[10].quality, SIGNAL_DATA_TYPE_ul},

    {"ch12_v",  &mu.channel[11].data,    SIGNAL_DATA_TYPE_l},
    {"ch12_q",  &mu.channel[11].quality, SIGNAL_DATA_TYPE_ul},

    {"ch13_v",  &mu.channel[12].data,    SIGNAL_DATA_TYPE_l},
    {"ch13_q",  &mu.channel[12].quality, SIGNAL_DATA_TYPE_ul},

    {"ch14_v",  &mu.channel[13].data,    SIGNAL_DATA_TYPE_l},
    {"ch14_q",  &mu.channel[13].quality, SIGNAL_DATA_TYPE_ul},

    {"ch15_v",  &mu.channel[14].data,    SIGNAL_DATA_TYPE_l},
    {"ch15_q",  &mu.channel[14].quality, SIGNAL_DATA_TYPE_ul},

    {"ch16_v",  &mu.channel[15].data,    SIGNAL_DATA_TYPE_l},
    {"ch16_q",  &mu.channel[15].quality, SIGNAL_DATA_TYPE_ul},

    {"ch17_v",  &mu.channel[16].data,    SIGNAL_DATA_TYPE_l},
    {"ch17_q",  &mu.channel[16].quality, SIGNAL_DATA_TYPE_ul},

    {"ch18_v",  &mu.channel[17].data,    SIGNAL_DATA_TYPE_l},
    {"ch18_q",  &mu.channel[17].quality, SIGNAL_DATA_TYPE_ul},

    {"ch19_v",  &mu.channel[18].data,    SIGNAL_DATA_TYPE_l},
    {"ch19_q",  &mu.channel[18].quality, SIGNAL_DATA_TYPE_ul},

    {"ch20_v",  &mu.channel[19].data,    SIGNAL_DATA_TYPE_l},
    {"ch20_q",  &mu.channel[19].quality, SIGNAL_DATA_TYPE_ul},

    {"ch21_v",  &mu.channel[20].data,    SIGNAL_DATA_TYPE_l},
    {"ch21_q",  &mu.channel[20].quality, SIGNAL_DATA_TYPE_ul},

    {"ch22_v",  &mu.channel[21].data,    SIGNAL_DATA_TYPE_l},
    {"ch22_q",  &mu.channel[21].quality, SIGNAL_DATA_TYPE_ul},

    {"ch23_v",  &mu.channel[22].data,    SIGNAL_DATA_TYPE_l},
    {"ch23_q",  &mu.channel[22].quality, SIGNAL_DATA_TYPE_ul},

    {"ch24_v",  &mu.channel[23].data,    SIGNAL_DATA_TYPE_l},
    {"ch24_q",  &mu.channel[23].quality, SIGNAL_DATA_TYPE_ul},
};

int32 const sv_signal_out_define_num = sizeof(sv_signal_out_define) / sizeof(SIGNAL_DEFINE);
