/*****************************************************************************************************
* FileName:                    Sv.h
*
* Description:                 Sv���ͷ�ļ�
*
* Author:                      YanDengxue, Fiberhome-Fuhua
*
* Rev History:
*       <Author>        <Data>        <Hardware>     <Version>        <Description>
*     YanDengxue   2011-03-29 15:30       --           1.00             Create
*****************************************************************************************************/
#ifndef _Sv_H
#define _Sv_H

#ifdef __cplusplus
extern "C" {
#endif

//====================================================================================================
// �궨��
//====================================================================================================
// �������������ֵ
#define SV_SMP_FREQ_4K    4000u
#define SV_SMP_FREQ_10K   10000u
#define SV_SMP_FREQ_12K8  12800u

#define SV_TAG_APDU          0x60u
#define SV_TAG_NO_ASDU       0x80u
#define SV_TAG_ASDU          0xA2u
#define SV_TAG_SUB_ASDU      0x30u
#define SV_TAG_ID            0x80u
#define SV_TAG_SMP_CNT       0x82u
#define SV_TAG_CONF_REV      0x83u
#define SV_TAG_SMP_SYNCH     0x85u
#define SV_TAG_DATA_SET      0x87u
#define SV_TAG_CONF_REV      0x83u

#define SV_SAMPLE_DOT_SIZE       64
#define SV_SAMPLE_DOT_MASK       (SV_SAMPLE_DOT_SIZE - 1)
#define SV_SAMPLE_DOT_ADDR(addr) ((Uint16)((addr) & SV_SAMPLE_DOT_MASK))

//====================================================================================================
// �ṹ����
//====================================================================================================
typedef struct
{
    Uint8  priority;
    Uint16 mac_dst_addr;
    Uint16 app_id;
    Uint16 vlan_id;
    Uint16 item_num;
    Uint32 conf_rev;
    char const *id;
    char const *data_set;
    char const *ref;
    SIGNAL_OUT const *singal_out;
    int32 frame_length;
    Uint8 *frame_buffer;
    Uint8 *addr_smp_cnt;
    Uint8 *addr_smp_synch;
    Uint8 *addr_data_set;
    EMAC_DESCRIPTOR_REGS *emac_desc;
} SVCB;

typedef struct
{
    int32  cb_num;
    SVCB   *svcb;
} SV_TX;

//====================================================================================================
// �ⲿ��������
//====================================================================================================
extern SIGNAL_DEFINE const sv_signal_out_define[];
extern int32 const sv_signal_out_define_num;
extern PROJECT_TYPE_DEFINE const sv_prj_type_define[];
extern int32 const sv_prj_type_define_num;

//====================================================================================================
// �ⲿ��������
//====================================================================================================
extern int32 GetSvDataLength(PROJECT_DATA_TYPE data_type);
extern void SvPacketSend(void);

#ifdef __cplusplus
}
#endif

#endif


