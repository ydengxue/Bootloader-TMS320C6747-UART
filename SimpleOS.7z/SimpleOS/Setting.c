/*****************************************************************************************************
* FileName:                    Setting.c
*
* Description:                 ��ֵ�ļ�
*
* Author:                      YanDengxue, Fiberhome-Fuhua
*
* Rev History:
*       <Author>        <Data>        <Hardware>     <Version>        <Description>
*     YanDengxue   2011-03-29 15:30       --           1.00             Create
*****************************************************************************************************/
//====================================================================================================
// ���ļ�ʹ�õ�ͷ�ļ�
//====================================================================================================
// �Զ���ͷ�ļ�
#include "UserTypesDef.h"
#include "SystemBase.h"
#include "BaseData.h"
#include "FpgaDataSend.h"
#include "LaserPowerControl.h"
#include "UserApp.h"

//====================================================================================================
// ���ļ���������ⲿ�Ľӿڱ���
//====================================================================================================
SIGNAL_DEFINE const setting_system_define[] =
{
    {"sync_mode",                 &sys_cfg.sync_mode,                       SIGNAL_DATA_TYPE_uc},
    {"time_zone",                 &sys_cfg.time_zone,                       SIGNAL_DATA_TYPE_l},
                                                                            
    {"sv_fake_vlan",              &mu.sv_tx_fake_vlan,                      SIGNAL_DATA_TYPE_ui},
    {"goose_fake_vlan",           &mu.goose_tx_fake_vlan,                   SIGNAL_DATA_TYPE_ui},
                                                                            
    {"ft3_ln_name",               &ft3.ln_name,                             SIGNAL_DATA_TYPE_uc},
    {"ft3_data_set",              &ft3.data_set,                            SIGNAL_DATA_TYPE_uc},
    {"ft3_ld_name",               &ft3.ld_name,                             SIGNAL_DATA_TYPE_ui},
    {"ft3_rated_current",         &ft3.rated_current,                       SIGNAL_DATA_TYPE_ui},
    {"ft3_rated_neutral_current", &ft3.rated_neutral_current,               SIGNAL_DATA_TYPE_ui},
    {"ft3_rated_voltage",         &ft3.rated_voltage,                       SIGNAL_DATA_TYPE_ui},
    {"ft3_delay",                 &ft3.delay,                               SIGNAL_DATA_TYPE_ui},
    {"ft3_ch01_to_local_map",     &ft3.local_channel_map[0 ],               SIGNAL_DATA_TYPE_uc},
    {"ft3_ch02_to_local_map",     &ft3.local_channel_map[1 ],               SIGNAL_DATA_TYPE_uc},
    {"ft3_ch03_to_local_map",     &ft3.local_channel_map[2 ],               SIGNAL_DATA_TYPE_uc},
    {"ft3_ch04_to_local_map",     &ft3.local_channel_map[3 ],               SIGNAL_DATA_TYPE_uc},
    {"ft3_ch05_to_local_map",     &ft3.local_channel_map[4 ],               SIGNAL_DATA_TYPE_uc},
    {"ft3_ch06_to_local_map",     &ft3.local_channel_map[5 ],               SIGNAL_DATA_TYPE_uc},
    {"ft3_ch07_to_local_map",     &ft3.local_channel_map[6 ],               SIGNAL_DATA_TYPE_uc},
    {"ft3_ch08_to_local_map",     &ft3.local_channel_map[7 ],               SIGNAL_DATA_TYPE_uc},
    {"ft3_ch09_to_local_map",     &ft3.local_channel_map[8 ],               SIGNAL_DATA_TYPE_uc},
    {"ft3_ch10_to_local_map",     &ft3.local_channel_map[9 ],               SIGNAL_DATA_TYPE_uc},
    {"ft3_ch11_to_local_map",     &ft3.local_channel_map[10],               SIGNAL_DATA_TYPE_uc},
    {"ft3_ch12_to_local_map",     &ft3.local_channel_map[11],               SIGNAL_DATA_TYPE_uc},
    {"ft3_ch13_to_local_map",     &ft3.local_channel_map[12],               SIGNAL_DATA_TYPE_uc},
    {"ft3_ch14_to_local_map",     &ft3.local_channel_map[13],               SIGNAL_DATA_TYPE_uc},
    {"ft3_ch15_to_local_map",     &ft3.local_channel_map[14],               SIGNAL_DATA_TYPE_uc},
    {"ft3_ch16_to_local_map",     &ft3.local_channel_map[15],               SIGNAL_DATA_TYPE_uc},
    {"ft3_ch17_to_local_map",     &ft3.local_channel_map[16],               SIGNAL_DATA_TYPE_uc},
    {"ft3_ch18_to_local_map",     &ft3.local_channel_map[17],               SIGNAL_DATA_TYPE_uc},
    {"ft3_ch19_to_local_map",     &ft3.local_channel_map[18],               SIGNAL_DATA_TYPE_uc},
    {"ft3_ch20_to_local_map",     &ft3.local_channel_map[19],               SIGNAL_DATA_TYPE_uc},
    {"ft3_ch21_to_local_map",     &ft3.local_channel_map[20],               SIGNAL_DATA_TYPE_uc},
    {"ft3_ch22_to_local_map",     &ft3.local_channel_map[21],               SIGNAL_DATA_TYPE_uc},
    {"ft3_ch23_to_local_map",     &ft3.local_channel_map[22],               SIGNAL_DATA_TYPE_uc},
    {"ft3_ch24_to_local_map",     &ft3.local_channel_map[23],               SIGNAL_DATA_TYPE_uc},
                                                                            
    {"laser_power_online",        &laser_power.online,                      SIGNAL_DATA_TYPE_uc},
    {"laser_power_comm_interval", &laser_power.communication_interval,      SIGNAL_DATA_TYPE_ul},
    {"laser_power_on_min_time",   &laser_power.power_on_min_time,           SIGNAL_DATA_TYPE_ul},
    {"laser_power_on_current",    &laser_power.power_on_effective_current,  SIGNAL_DATA_TYPE_f},
    {"laser_power_off_current",   &laser_power.power_off_effective_current, SIGNAL_DATA_TYPE_f},

    {"primary_rated_voltage",     &mu.primary_rated_voltage,                SIGNAL_DATA_TYPE_f},
    {"primary_rated_current",     &mu.primary_rated_current,                SIGNAL_DATA_TYPE_f},
    {"smp_freq",                  &mu.smp_freq,                             SIGNAL_DATA_TYPE_ui},
    {"delay_const",               &mu.delay_const_value,                    SIGNAL_DATA_TYPE_l},
                                                                            
    {"ch01_amp_coeff",            &mu.channel[0 ].amplitude_coefficient,    SIGNAL_DATA_TYPE_f},
    {"ch01_delay_adjust",         &mu.channel[0 ].delay_adjust,             SIGNAL_DATA_TYPE_i},
    {"ch01_phase_adjust",         &mu.channel[0 ].phase_adjust,             SIGNAL_DATA_TYPE_i},
                                                                            
    {"ch02_amp_coeff",            &mu.channel[1 ].amplitude_coefficient,    SIGNAL_DATA_TYPE_f},
    {"ch02_delay_adjust",         &mu.channel[1 ].delay_adjust,             SIGNAL_DATA_TYPE_i},
    {"ch02_phase_adjust",         &mu.channel[1 ].phase_adjust,             SIGNAL_DATA_TYPE_i},
                                                                            
    {"ch03_amp_coeff",            &mu.channel[2 ].amplitude_coefficient,    SIGNAL_DATA_TYPE_f},
    {"ch03_delay_adjust",         &mu.channel[2 ].delay_adjust,             SIGNAL_DATA_TYPE_i},
    {"ch03_phase_adjust",         &mu.channel[2 ].phase_adjust,             SIGNAL_DATA_TYPE_i},
                                                                            
    {"ch04_amp_coeff",            &mu.channel[3 ].amplitude_coefficient,    SIGNAL_DATA_TYPE_f},
    {"ch04_delay_adjust",         &mu.channel[3 ].delay_adjust,             SIGNAL_DATA_TYPE_i},
    {"ch04_phase_adjust",         &mu.channel[3 ].phase_adjust,             SIGNAL_DATA_TYPE_i},
                                                                            
    {"ch05_amp_coeff",            &mu.channel[4 ].amplitude_coefficient,    SIGNAL_DATA_TYPE_f},
    {"ch05_delay_adjust",         &mu.channel[4 ].delay_adjust,             SIGNAL_DATA_TYPE_i},
    {"ch05_phase_adjust",         &mu.channel[4 ].phase_adjust,             SIGNAL_DATA_TYPE_i},
                                                                            
    {"ch06_amp_coeff",            &mu.channel[5 ].amplitude_coefficient,    SIGNAL_DATA_TYPE_f},
    {"ch06_delay_adjust",         &mu.channel[5 ].delay_adjust,             SIGNAL_DATA_TYPE_i},
    {"ch06_phase_adjust",         &mu.channel[5 ].phase_adjust,             SIGNAL_DATA_TYPE_i},
                                                                            
    {"ch07_amp_coeff",            &mu.channel[6 ].amplitude_coefficient,    SIGNAL_DATA_TYPE_f},
    {"ch07_delay_adjust",         &mu.channel[6 ].delay_adjust,             SIGNAL_DATA_TYPE_i},
    {"ch07_phase_adjust",         &mu.channel[6 ].phase_adjust,             SIGNAL_DATA_TYPE_i},
                                                                            
    {"ch08_amp_coeff",            &mu.channel[7 ].amplitude_coefficient,    SIGNAL_DATA_TYPE_f},
    {"ch08_delay_adjust",         &mu.channel[7 ].delay_adjust,             SIGNAL_DATA_TYPE_i},
    {"ch08_phase_adjust",         &mu.channel[7 ].phase_adjust,             SIGNAL_DATA_TYPE_i},
                                                                            
    {"ch09_amp_coeff",            &mu.channel[8 ].amplitude_coefficient,    SIGNAL_DATA_TYPE_f},
    {"ch09_delay_adjust",         &mu.channel[8 ].delay_adjust,             SIGNAL_DATA_TYPE_i},
    {"ch09_phase_adjust",         &mu.channel[8 ].phase_adjust,             SIGNAL_DATA_TYPE_i},
                                                                            
    {"ch10_amp_coeff",            &mu.channel[9 ].amplitude_coefficient,    SIGNAL_DATA_TYPE_f},
    {"ch10_delay_adjust",         &mu.channel[9 ].delay_adjust,             SIGNAL_DATA_TYPE_i},
    {"ch10_phase_adjust",         &mu.channel[9 ].phase_adjust,             SIGNAL_DATA_TYPE_i},
                                                                            
    {"ch11_amp_coeff",            &mu.channel[10].amplitude_coefficient,    SIGNAL_DATA_TYPE_f},
    {"ch11_delay_adjust",         &mu.channel[10].delay_adjust,             SIGNAL_DATA_TYPE_i},
    {"ch11_phase_adjust",         &mu.channel[10].phase_adjust,             SIGNAL_DATA_TYPE_i},
                                                                            
    {"ch12_amp_coeff",            &mu.channel[11].amplitude_coefficient,    SIGNAL_DATA_TYPE_f},
    {"ch12_delay_adjust",         &mu.channel[11].delay_adjust,             SIGNAL_DATA_TYPE_i},
    {"ch12_phase_adjust",         &mu.channel[11].phase_adjust,             SIGNAL_DATA_TYPE_i},
                                                                            
    {"ch13_amp_coeff",            &mu.channel[12].amplitude_coefficient,    SIGNAL_DATA_TYPE_f},
    {"ch13_delay_adjust",         &mu.channel[12].delay_adjust,             SIGNAL_DATA_TYPE_i},
    {"ch13_phase_adjust",         &mu.channel[12].phase_adjust,             SIGNAL_DATA_TYPE_i},
                                                                            
    {"ch14_amp_coeff",            &mu.channel[13].amplitude_coefficient,    SIGNAL_DATA_TYPE_f},
    {"ch14_delay_adjust",         &mu.channel[13].delay_adjust,             SIGNAL_DATA_TYPE_i},
    {"ch14_phase_adjust",         &mu.channel[13].phase_adjust,             SIGNAL_DATA_TYPE_i},
                                                                            
    {"ch15_amp_coeff",            &mu.channel[14].amplitude_coefficient,    SIGNAL_DATA_TYPE_f},
    {"ch15_delay_adjust",         &mu.channel[14].delay_adjust,             SIGNAL_DATA_TYPE_i},
    {"ch15_phase_adjust",         &mu.channel[14].phase_adjust,             SIGNAL_DATA_TYPE_i},
                                                                            
    {"ch16_amp_coeff",            &mu.channel[15].amplitude_coefficient,    SIGNAL_DATA_TYPE_f},
    {"ch16_delay_adjust",         &mu.channel[15].delay_adjust,             SIGNAL_DATA_TYPE_i},
    {"ch16_phase_adjust",         &mu.channel[15].phase_adjust,             SIGNAL_DATA_TYPE_i},
                                                                            
    {"ch17_amp_coeff",            &mu.channel[16].amplitude_coefficient,    SIGNAL_DATA_TYPE_f},
    {"ch17_delay_adjust",         &mu.channel[16].delay_adjust,             SIGNAL_DATA_TYPE_i},
    {"ch17_phase_adjust",         &mu.channel[16].phase_adjust,             SIGNAL_DATA_TYPE_i},
                                                                            
    {"ch18_amp_coeff",            &mu.channel[17].amplitude_coefficient,    SIGNAL_DATA_TYPE_f},
    {"ch18_delay_adjust",         &mu.channel[17].delay_adjust,             SIGNAL_DATA_TYPE_i},
    {"ch18_phase_adjust",         &mu.channel[17].phase_adjust,             SIGNAL_DATA_TYPE_i},
                                                                            
    {"ch19_amp_coeff",            &mu.channel[18].amplitude_coefficient,    SIGNAL_DATA_TYPE_f},
    {"ch19_delay_adjust",         &mu.channel[18].delay_adjust,             SIGNAL_DATA_TYPE_i},
    {"ch19_phase_adjust",         &mu.channel[18].phase_adjust,             SIGNAL_DATA_TYPE_i},
                                                                            
    {"ch20_amp_coeff",            &mu.channel[19].amplitude_coefficient,    SIGNAL_DATA_TYPE_f},
    {"ch20_delay_adjust",         &mu.channel[19].delay_adjust,             SIGNAL_DATA_TYPE_i},
    {"ch20_phase_adjust",         &mu.channel[19].phase_adjust,             SIGNAL_DATA_TYPE_i},
                                                                            
    {"ch21_amp_coeff",            &mu.channel[20].amplitude_coefficient,    SIGNAL_DATA_TYPE_f},
    {"ch21_delay_adjust",         &mu.channel[20].delay_adjust,             SIGNAL_DATA_TYPE_i},
    {"ch21_phase_adjust",         &mu.channel[20].phase_adjust,             SIGNAL_DATA_TYPE_i},
                                                                            
    {"ch22_amp_coeff",            &mu.channel[21].amplitude_coefficient,    SIGNAL_DATA_TYPE_f},
    {"ch22_delay_adjust",         &mu.channel[21].delay_adjust,             SIGNAL_DATA_TYPE_i},
    {"ch22_phase_adjust",         &mu.channel[21].phase_adjust,             SIGNAL_DATA_TYPE_i},
                                                                            
    {"ch23_amp_coeff",            &mu.channel[22].amplitude_coefficient,    SIGNAL_DATA_TYPE_f},
    {"ch23_delay_adjust",         &mu.channel[22].delay_adjust,             SIGNAL_DATA_TYPE_i},
    {"ch23_phase_adjust",         &mu.channel[22].phase_adjust,             SIGNAL_DATA_TYPE_i},
                                                                            
    {"ch24_amp_coeff",            &mu.channel[23].amplitude_coefficient,    SIGNAL_DATA_TYPE_f},
    {"ch24_delay_adjust",         &mu.channel[23].delay_adjust,             SIGNAL_DATA_TYPE_i},
    {"ch24_phase_adjust",         &mu.channel[23].phase_adjust,             SIGNAL_DATA_TYPE_i},
};

int32 const setting_system_define_num = sizeof(setting_system_define) / sizeof(SIGNAL_DEFINE);

