/*****************************************************************************************************
* FileName:                    ApplicationInitial.c
*
* Description:                 Ӧ�ó����ʼ������
*
* Author:                      YanDengxue, Fiberhome-Fuhua
*
* Rev History:
*       <Author>        <Data>        <Hardware>     <Version>        <Description>
*     YanDengxue   2011-03-29 15:30       --           1.00             Create
*****************************************************************************************************/
//====================================================================================================
// ���ļ�ʹ�õ�ͷ�ļ�
//====================================================================================================
// ��ͷ�ļ�
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

// �Զ���ͷ�ļ�
#include "UserTypesDef.h"
#include "C6747Register.h"
#include "SystemBase.h"
#include "BaseData.h"
#include "ProjectDataHandle.h"
#include "UserApp.h"

//====================================================================================================
// ���غ�������,�˴������ĺ��������ⲿ�ӿ�
//====================================================================================================
static int32 SvFrameInitial(void );
static int32 GooseFrameInitial(void );

//====================================================================================================
// ����ȫ�ֱ���
//====================================================================================================
static char const sv_goose_frame_header[] =
{
    0x01, 0x0C, 0xCD, 0x00, 0x00, 0x00,
    0x00, 0x70, 0x12, 0x24, 0x00, 0x00,
    0x81, 0x00, 0x00, 0x00, 0x81, 0x00,
    0x00, 0x00, 0x88, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00
};

//====================================================================================================
// ����ʵ��
//====================================================================================================
//----------------------------------------------------------------------------------------------------
// �ӿں���
//----------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------
//   Function: AppInitial
//      Input: void
//     Output: void
//     Return: int32: ����ִ�����
//Description: Ӧ�ó����ʼ������
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
int32 ApplicationInitial(void)
{
    system_running_status = CPU_WARNING_FLAG;

    if (    (NORMAL_SUCCESS != ParseDevConfig())
         || (NORMAL_SUCCESS != ParsePrjConfig())
         || (NORMAL_SUCCESS != GooseFrameInitial())
         || (NORMAL_SUCCESS != SvFrameInitial()))
    {
        TRACE_ERROR("Application initial failed!");
        return NORMAL_ERROR;
    }

    if (NORMAL_SUCCESS != UserApplicationInitial())
    {
        TRACE_ERROR("User application initial failed!");
        return NORMAL_ERROR;
    }

    return NORMAL_SUCCESS;
}

//----------------------------------------------------------------------------------------------------
// ���غ���
//----------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------
//   Function: GooseFrameInitial
//      Input: void
//     Output: void
//     Return: int32: ����ִ�����
//Description: GOOSE���ķ����ڴ沢��ʼ��
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
static int32 GooseFrameInitial(void )
{
    int32 i;
    int32 lv_cb_index;
    int32 lv_apdu_max_length;
    int32 lv_frame_max_length;
    int32 lv_project_data_length;
    Uint8 *lv_p_buffer;
    GOCB  *lv_p_gocb;

    for (lv_cb_index = 0; lv_cb_index < prj_cfg.goose_tx.cb_num; lv_cb_index++)
    {
        lv_p_gocb = &prj_cfg.goose_tx.gocb[lv_cb_index];
        lv_apdu_max_length = 0;
        for (i = 0; i < lv_p_gocb->item_num; i++)
        {
            lv_project_data_length = GetGooseDataMaxLength(lv_p_gocb->singal_out[i].prj_type_define->type);
            if ((lv_project_data_length < 0) || (lv_project_data_length > 127))
            {
                TRACE_ERROR("Get GoCb project data length failed!");
                return NORMAL_ERROR;
            }
            lv_apdu_max_length += (lv_project_data_length + 2);
        }

        lv_apdu_max_length += 4;
        lv_apdu_max_length += 3;
        lv_apdu_max_length += 6;
        lv_apdu_max_length += 3;
        lv_apdu_max_length += 6;
        lv_apdu_max_length += 6;
        lv_apdu_max_length += 10;
        lv_apdu_max_length += (strlen(lv_p_gocb->id) + 4);
        lv_apdu_max_length += 6;
        lv_apdu_max_length += (strlen(lv_p_gocb->data_set) + 4);
        lv_apdu_max_length += (strlen(lv_p_gocb->ref) + 4);

        lv_apdu_max_length += 4;

        lv_frame_max_length = lv_apdu_max_length + sizeof(sv_goose_frame_header);
        if ((lv_frame_max_length < 0) || (lv_frame_max_length > 65535u))
        {
            TRACE_ERROR("GoCb frame_length exceed [0,65535]");
            return NORMAL_ERROR;
        }

        lv_p_gocb->frame_buffer = (Uint8 *)CallocSpaceFromUserFastBuffer(lv_frame_max_length);
        if (NULL == lv_p_gocb->frame_buffer)
        {
            TRACE_ERROR("GoCb frame_buffer malloc failed");
            return NORMAL_ERROR;
        }
        lv_p_gocb->frame_buffer_end = lv_p_gocb->frame_buffer + lv_frame_max_length;

        lv_p_buffer = (Uint8 *)CallocSpaceFromUserFastBuffer(sizeof(sv_goose_frame_header));
        if (NULL == lv_p_buffer)
        {
            TRACE_ERROR("GoCb frame_header malloc failed");
            return NORMAL_ERROR;
        }

        memcpy(lv_p_buffer, sv_goose_frame_header, sizeof(sv_goose_frame_header));
        lv_p_buffer[3]  = 0x01u;
        lv_p_buffer[4]  = LHSB(lv_p_gocb->mac_dst_addr);
        lv_p_buffer[5]  = LLSB(lv_p_gocb->mac_dst_addr);
        lv_p_buffer[10] = LHSB(prj_cfg.goose_tx.gocb[0].mac_dst_addr);
        lv_p_buffer[11] = LLSB(prj_cfg.goose_tx.gocb[0].mac_dst_addr);
        lv_p_buffer[14] = 0x80u | ((mu.goose_tx_fake_vlan >> 8u) & 0xFu);
        lv_p_buffer[15] = mu.goose_tx_fake_vlan & 0xFFu;
        lv_p_buffer[18] = (lv_p_gocb->priority << 5u) | (LHSB(lv_p_gocb->vlan_id) & 0xFu);
        lv_p_buffer[19] = LLSB(lv_p_gocb->vlan_id);
        lv_p_buffer[21] = 0xB8u;
        lv_p_buffer[22] = LHSB(lv_p_gocb->app_id);
        lv_p_buffer[23] = LLSB(lv_p_gocb->app_id);
        lv_p_gocb->frame_header = lv_p_buffer;

        lv_p_gocb->emac_desc->buffer = lv_p_gocb->frame_buffer;
        lv_p_gocb->emac_desc->buffer_offset_and_length = (0 | lv_frame_max_length);
    }
    return NORMAL_SUCCESS;
}

//----------------------------------------------------------------------------------------------------
//   Function: SvFrameInitial
//      Input: void
//     Output: void
//     Return: int32: ����ִ�����
//Description: SV���ķ����ڴ沢��ʼ��
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
static int32 SvFrameInitial(void )
{
    int32 i;
    int32 lv_cb_index;
    int32 lv_project_data_length;
    int32 lv_data_set_value_length;
    int32 lv_data_set_length;
    int32 lv_id_value_length;
    int32 lv_id_length;
    int32 lv_sub_asdu_value_length;
    int32 lv_sub_asdu_length;
    int32 lv_asdu_value_length;
    int32 lv_asdu_length;
    int32 lv_apdu_value_length;
    int32 lv_apdu_length;
    Uint8 *lv_p_frame_addr;
    SVCB  *lv_p_svcb;

    for (lv_cb_index = 0; lv_cb_index < prj_cfg.sv_tx.cb_num; lv_cb_index++)
    {
        lv_p_svcb = &prj_cfg.sv_tx.svcb[lv_cb_index];
        lv_data_set_value_length = 0;
        for (i = 0; i < lv_p_svcb->item_num; i++)
        {
            lv_project_data_length = GetSvDataLength(lv_p_svcb->singal_out[i].prj_type_define->type);
            if (lv_project_data_length < 0)
            {
                TRACE_ERROR("SvCb get project data length failed");
                return NORMAL_ERROR;
            }
            lv_data_set_value_length += lv_project_data_length;
        }
        if (lv_data_set_value_length > 255)
        {
            lv_data_set_length = lv_data_set_value_length + 4;
        }
        else if (lv_data_set_value_length > 127)
        {
            lv_data_set_length = lv_data_set_value_length + 3;
        }
        else
        {
            lv_data_set_length = lv_data_set_value_length + 2;
        }

        lv_id_value_length = strlen(lv_p_svcb->id);
        if (lv_id_value_length > 255)
        {
            lv_id_length = lv_id_value_length + 4;
        }
        else if (lv_id_value_length > 127)
        {
            lv_id_length = lv_id_value_length + 3;
        }
        else
        {
            lv_id_length = lv_id_value_length + 2;
        }

        lv_sub_asdu_value_length = lv_data_set_length + 3 + 6 + 4 + lv_id_length;
        if (lv_sub_asdu_value_length > 255)
        {
            lv_sub_asdu_length = lv_sub_asdu_value_length + 4;
        }
        else if (lv_sub_asdu_value_length > 127)
        {
            lv_sub_asdu_length = lv_sub_asdu_value_length + 3;
        }
        else
        {
            lv_sub_asdu_length = lv_sub_asdu_value_length + 2;
        }

        lv_asdu_value_length = lv_sub_asdu_length;
        if (lv_asdu_value_length > 255)
        {
            lv_asdu_length = lv_asdu_value_length + 4;
        }
        else if (lv_asdu_value_length > 127)
        {
            lv_asdu_length = lv_asdu_value_length + 3;
        }
        else
        {
            lv_asdu_length = lv_asdu_value_length + 2;
        }

        lv_apdu_value_length = lv_asdu_length + 3;
        if (lv_apdu_value_length > 255)
        {
            lv_apdu_length = lv_apdu_value_length + 4;
        }
        else if (lv_apdu_value_length > 127)
        {
            lv_apdu_length = lv_apdu_value_length + 3;
        }
        else
        {
            lv_apdu_length = lv_apdu_value_length + 2;
        }

        lv_p_svcb->frame_length = lv_apdu_length + sizeof(sv_goose_frame_header);
        if ((lv_p_svcb->frame_length < 0) || (lv_p_svcb->frame_length > 65535u))
        {
            TRACE_ERROR("SvCb frame_length exceed [0,65535]");
            return NORMAL_ERROR;
        }

        lv_p_svcb->frame_buffer = (Uint8 *)CallocSpaceFromUserFastBuffer(lv_p_svcb->frame_length);
        if (NULL == lv_p_svcb->frame_buffer)
        {
            TRACE_ERROR("SvCb frame_buffer malloc failed");
            return NORMAL_ERROR;
        }

        memcpy(lv_p_svcb->frame_buffer, sv_goose_frame_header, sizeof(sv_goose_frame_header));
        lv_p_svcb->frame_buffer[3]  = 0x04u;
        lv_p_svcb->frame_buffer[4]  = LHSB(lv_p_svcb->mac_dst_addr);
        lv_p_svcb->frame_buffer[5]  = LLSB(lv_p_svcb->mac_dst_addr);
        lv_p_svcb->frame_buffer[10] = LHSB(prj_cfg.sv_tx.svcb[0].mac_dst_addr);
        lv_p_svcb->frame_buffer[11] = LLSB(prj_cfg.sv_tx.svcb[0].mac_dst_addr);
        lv_p_svcb->frame_buffer[14] = 0xC0u | ((mu.sv_tx_fake_vlan >> 8u) & 0xFu);
        lv_p_svcb->frame_buffer[15] = mu.sv_tx_fake_vlan & 0xFFu;
        lv_p_svcb->frame_buffer[18] = (lv_p_svcb->priority << 5u) | (LHSB(lv_p_svcb->vlan_id) & 0xFu);
        lv_p_svcb->frame_buffer[19] = LLSB(lv_p_svcb->vlan_id);
        lv_p_svcb->frame_buffer[21] = 0xBAu;
        lv_p_svcb->frame_buffer[22] = LHSB(lv_p_svcb->app_id);
        lv_p_svcb->frame_buffer[23] = LLSB(lv_p_svcb->app_id);
        lv_p_svcb->frame_buffer[24] = LHSB(lv_apdu_length + 8u);
        lv_p_svcb->frame_buffer[25] = LLSB(lv_apdu_length + 8u);
        lv_p_frame_addr = &lv_p_svcb->frame_buffer[sizeof(sv_goose_frame_header)];

        *lv_p_frame_addr++ = SV_TAG_APDU;
        if (lv_apdu_value_length > 255)
        {
            *lv_p_frame_addr++ = 0x82;
            *lv_p_frame_addr++ = LHSB(lv_apdu_value_length);
            *lv_p_frame_addr++ = LLSB(lv_apdu_value_length);
        }
        else if (lv_apdu_value_length > 127)
        {
            *lv_p_frame_addr++ = 0x81;
            *lv_p_frame_addr++ = LLSB(lv_apdu_value_length);
        }
        else
        {
            *lv_p_frame_addr++ = LLSB(lv_apdu_value_length);
        }

        *lv_p_frame_addr++ = SV_TAG_NO_ASDU;
        *lv_p_frame_addr++ = 1;
        *lv_p_frame_addr++ = 1;

        *lv_p_frame_addr++ = SV_TAG_ASDU;
        if (lv_asdu_value_length > 255)
        {
            *lv_p_frame_addr++ = 0x82;
            *lv_p_frame_addr++ = LHSB(lv_asdu_value_length);
            *lv_p_frame_addr++ = LLSB(lv_asdu_value_length);
        }
        else if (lv_asdu_value_length > 127)
        {
            *lv_p_frame_addr++ = 0x81;
            *lv_p_frame_addr++ = LLSB(lv_asdu_value_length);
        }
        else
        {
            *lv_p_frame_addr++ = LLSB(lv_asdu_value_length);
        }

        *lv_p_frame_addr++ = SV_TAG_SUB_ASDU;
        if (lv_sub_asdu_value_length > 255)
        {
            *lv_p_frame_addr++ = 0x82;
            *lv_p_frame_addr++ = LHSB(lv_sub_asdu_value_length);
            *lv_p_frame_addr++ = LLSB(lv_sub_asdu_value_length);
        }
        else if (lv_sub_asdu_value_length > 127)
        {
            *lv_p_frame_addr++ = 0x81;
            *lv_p_frame_addr++ = LLSB(lv_sub_asdu_value_length);
        }
        else
        {
            *lv_p_frame_addr++ = LLSB(lv_sub_asdu_value_length);
        }

        *lv_p_frame_addr++ = SV_TAG_ID;
        if (lv_id_value_length > 255)
        {
            *lv_p_frame_addr++ = 0x82;
            *lv_p_frame_addr++ = LHSB(lv_id_value_length);
            *lv_p_frame_addr++ = LLSB(lv_id_value_length);
        }
        else if (lv_id_value_length > 127)
        {
            *lv_p_frame_addr++ = 0x81;
            *lv_p_frame_addr++ = LLSB(lv_id_value_length);
        }
        else
        {
            *lv_p_frame_addr++ = LLSB(lv_id_value_length);
        }
        memcpy(lv_p_frame_addr, lv_p_svcb->id, lv_id_value_length);
        lv_p_frame_addr += lv_id_value_length;

        *lv_p_frame_addr++ = SV_TAG_SMP_CNT;
        *lv_p_frame_addr++ = 2;
        lv_p_svcb->addr_smp_cnt = lv_p_frame_addr;
        lv_p_frame_addr += 2;

        *lv_p_frame_addr++ = SV_TAG_CONF_REV;
        *lv_p_frame_addr++ = 4;
        *lv_p_frame_addr++ = HHSB(lv_p_svcb->conf_rev);
        *lv_p_frame_addr++ = HLSB(lv_p_svcb->conf_rev);
        *lv_p_frame_addr++ = LHSB(lv_p_svcb->conf_rev);
        *lv_p_frame_addr++ = LLSB(lv_p_svcb->conf_rev);

        *lv_p_frame_addr++ = SV_TAG_SMP_SYNCH;
        *lv_p_frame_addr++ = 1;
        lv_p_svcb->addr_smp_synch = lv_p_frame_addr;
        lv_p_frame_addr++;

        *lv_p_frame_addr++ = SV_TAG_DATA_SET;
        if (lv_data_set_value_length > 255)
        {
            *lv_p_frame_addr++ = 0x82;
            *lv_p_frame_addr++ = LHSB(lv_data_set_value_length);
            *lv_p_frame_addr++ = LLSB(lv_data_set_value_length);
        }
        else if (lv_data_set_value_length > 127)
        {
            *lv_p_frame_addr++ = 0x81;
            *lv_p_frame_addr++ = LLSB(lv_data_set_value_length);
        }
        else
        {
            *lv_p_frame_addr++ = LLSB(lv_data_set_value_length);
        }
        lv_p_svcb->addr_data_set = lv_p_frame_addr;

        lv_p_svcb->emac_desc->buffer = lv_p_svcb->frame_buffer;
        lv_p_svcb->emac_desc->buffer_offset_and_length = (0 | lv_p_svcb->frame_length);

    }
    return NORMAL_SUCCESS;
}

