/*****************************************************************************************************
* FileName:                    LaserPowerControl.h
*
* Description:                 �⹦�ܿ���ͷ�ļ�
*
* Author:                      YanDengxue, Fiberhome-Fuhua
*
* Rev History:
*       <Author>        <Data>        <Hardware>     <Version>        <Description>
*     YanDengxue   2011-08-22 15:30       --           1.00             Create
*****************************************************************************************************/
#ifndef _Laser_Power_Control_H
#define _Laser_Power_Control_H

#ifdef __cplusplus
extern "C" {
#endif

//====================================================================================================
// �궨��
//====================================================================================================
#define UART1_DESIRED_BAUD   (19200u)
#define UART1_OVERSAMPLE_CNT (13u)

#define LASER_POWER_CURRENT_DOT_NUM         128u
#define LASER_POWER_CURRENT_DOT_MASK        (LASER_POWER_CURRENT_DOT_NUM - 1u)
#define LASER_POWER_CURRENT_DOT_ADDR(addr)  ((Uint16)((addr) & (LASER_POWER_CURRENT_DOT_MASK)))

//====================================================================================================
// �ṹ����
//====================================================================================================
typedef struct
{
    Uint8  online;
    Uint8  status_bit[8];
    Uint8  on;
    Uint8  uart_rx_overtime_flag;
    Uint32 current_effective_a;
    Uint32 current_effective_b;
    Uint32 current_effective_c;
    Uint32 communication_interval;
    Uint32 power_on_min_time;
    float  power_on_effective_current;
    float  power_off_effective_current;
} LASER_POWER;

//====================================================================================================
// �ⲿ��������
//====================================================================================================
extern LASER_POWER laser_power;
extern Uint8  laser_power_online;
extern Uint32 laser_power_on_effective_current;
extern Uint32 laser_power_off_effective_current;
extern Uint32 laser_power_communication_interval;
extern Uint32 laser_power_on_min_time;

//====================================================================================================
// �ⲿ��������
//====================================================================================================
extern void LaserPowerControl(void);

#ifdef __cplusplus
}
#endif

#endif



