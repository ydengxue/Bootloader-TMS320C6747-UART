/*****************************************************************************************************
* FileName:                    Goose.h
*
* Description:                 Goose���ͷ�ļ�
*
* Author:                      YanDengxue, Fiberhome-Fuhua
*
* Rev History:
*       <Author>        <Data>        <Hardware>     <Version>        <Description>
*     YanDengxue   2011-03-29 15:30       --           1.00             Create
*****************************************************************************************************/
#ifndef _Goose_H
#define _Goose_H

#ifdef __cplusplus
extern "C" {
#endif

//====================================================================================================
// �궨��
//====================================================================================================
#define GOOSE_TAG_APDU                   0x61u
#define GOOSE_TAG_REF                    0x80u
#define GOOSE_TAG_TAL                    0x81u
#define GOOSE_TAG_DAT_SET                0x82u
#define GOOSE_TAG_ID                     0x83u
#define GOOSE_TAG_TIMESTAMP              0x84u
#define GOOSE_TAG_ST_NUM                 0x85u
#define GOOSE_TAG_SQ_NUM                 0x86u
#define GOOSE_TAG_TEST                   0x87u
#define GOOSE_TAG_CONF_REV               0x88u
#define GOOSE_TAG_NDS_COM                0x89u
#define GOOSE_TAG_NUM_DAT                0x8Au
#define GOOSE_TAG_ALL_DAT                0xABu
#define GOOSE_TAG_SECURITY               0x8Cu

#define GOOSE_TYPE_TAG_BOOLEAN           0x83u
#define GOOSE_TYPE_TAG_BIT_STRING        0x84u
#define GOOSE_TYPE_TAG_INTEGER           0x85u
#define GOOSE_TYPE_TAG_UNSIGNED          0x86u
#define GOOSE_TYPE_TAG_FLOAT             0x87u
#define GOOSE_TYPE_TAG_OCTET_STRING      0x89u
#define GOOSE_TYPE_TAG_VISIBLE_STRING    0x8Au
#define GOOSE_TYPE_TAG_GENERALIZED_TIME  0x8Bu
#define GOOSE_TYPE_TAG_BINARY_TIME       0x8Cu
#define GOOSE_TYPE_TAG_BCD               0x8Du
#define GOOSE_TYPE_TAG_MMS_STRING        0x90u
#define GOOSE_TYPE_TAG_UTC_TIME          0x91u

//====================================================================================================
// enum����
//====================================================================================================
typedef enum
{
    GOCB_SEND_STATUS_HEARTBEAT    = 1,
    GOCB_SEND_STATUS_FIRST_FRAME  = 2,
    GOCB_SEND_STATUS_SECOND_FRAME = 3,
    GOCB_SEND_STATUS_THIRD_FRAME  = 4,
    GOCB_SEND_STATUS_FOURTH_FRAME = 5,
    GOCB_SEND_STATUS_FIFTH_FRAME  = 6
} GOCB_SEND_STATUS;

//====================================================================================================
// �ṹ����
//====================================================================================================
typedef struct
{
    Uint8  status;
    Uint8  priority;
    Uint16 mac_dst_addr;
    Uint16 app_id;
    Uint16 vlan_id;
    Uint16 item_num;
    Uint32 conf_rev;
    Uint32 last_frame_time;
    Uint32 st_num;
    Uint32 sq_num;
    Uint32 tal;
    Uint32 heartbeat_tal;
    Uint32 first_frame_tal;
    Uint32 second_frame_tal;
    Uint32 third_frame_tal;
    Uint32 fourth_frame_tal;
    char const *id;
    char const *data_set;
    char const *ref;
    SIGNAL_OUT *singal_out;
    Uint8 const *frame_header;
    Uint8 *frame_buffer;
    Uint8 *frame_buffer_end;
    EMAC_DESCRIPTOR_REGS *emac_desc;
} GOCB;

typedef struct GOOSE_TX
{
    Uint8  status;
    int32  cb_num;
    GOCB   *gocb;
} GOOSE_TX;

//====================================================================================================
// �ⲿ��������
//====================================================================================================
extern SIGNAL_DEFINE const goose_signal_out_define[];
extern int32 const goose_signal_out_define_num;
extern PROJECT_TYPE_DEFINE const goose_prj_type_define[];
extern int32 const goose_prj_type_define_num;

//====================================================================================================
// �ⲿ��������
//====================================================================================================
extern int32 GetGooseDataMaxLength(PROJECT_DATA_TYPE data_type);
extern void GoosePacketSend(void);

#ifdef __cplusplus
}
#endif

#endif


