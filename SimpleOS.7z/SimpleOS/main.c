/*****************************************************************************************************
* FileName:                    main.c
*
* Description:                 �������
*
* Author:                      YanDengxue, Fiberhome-Fuhua
*
* Rev History:
*       <Author>        <Data>        <Hardware>     <Version>        <Description>
*     YanDengxue   2011-03-29 15:30       --           1.00             Create
*****************************************************************************************************/
//====================================================================================================
// ���ļ�ʹ�õ�ͷ�ļ�
//====================================================================================================
// �Զ���ͷ�ļ�
#include "UserTypesDef.h"
#include "C6747Register.h"
#include "SystemBase.h"
#include "BaseData.h"
#include "ProjectDataHandle.h"
#include "LaserPowerControl.h"
#include "NormalServices.h"
#include "UserApp.h"

//====================================================================================================
// ���غ�������,�˴������ĺ��������ⲿ�ӿ�
//====================================================================================================
static void LedControl(void);

//====================================================================================================
// ���ļ����õ��ⲿ��������
//====================================================================================================
extern int32 HardwareInitial(void);
extern int32 ApplicationInitial(void);

//====================================================================================================
// ���ļ���������ⲿ�Ľӿڱ���
//====================================================================================================
Vint8 user_app_passby_mode = 0;
VUint32 main_isr_max_run_time = 0;
VUint32 main_isr_run_time = 0;
VUint8  system_running_status = 0;
VUint16 fpga_rx_addr = 0;

//====================================================================================================
// ���ر�������,�˴������ı��������ⲿ�ӿ�
//====================================================================================================
static IRIGB   irigb;

//====================================================================================================
// ����ʵ��
//====================================================================================================
//----------------------------------------------------------------------------------------------------
// �ӿں���
//----------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------
//   Function: main
//      Input: void
//     Output: void
//     Return: int32: ����ִ�����
//Description: ϵͳ���������
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
int main(void)
{
    // ��ʼ��Ӳ��
    if (NORMAL_SUCCESS != HardwareInitial())
    {
        TRACE_ERROR("System hardware initial failed!");
        return NORMAL_ERROR;
    }

    DebugPrintf("Hardware ready!\r\n");
    DebugPrintf("----------------------------------------------------------------------------------------------------\r\n");
    DebugPrintf("User Application Compile Time : %s %s\r\n", __DATE__, __TIME__);
    DebugPrintf("User Application Author       : YanDengxue\r\n");
    DebugPrintf("----------------------------------------------------------------------------------------------------\r\n");
    DebugPrintf("Enter user application!\r\n\r\n");

    // Ӧ�ó����ʼ��
    if (NORMAL_SUCCESS != ApplicationInitial())
    {
        TRACE_ERROR("Application initial failed!");
    }
    else
    {
        DelayLoop(100000);

        DISABLE_INTERRUPT_ALL;
        CLR_INTERRUPT_FLAG_MAIN;

        pEDMA3CC->CCERRCLR = 0x00010003;
        pEDMA3CC->EMCR  = 0xffffffff;
        pEDMA3CC->ICR  = 0xffffffff;
        pEDMA3CC->ECR  = 0xffffffff;
        pEDMA3CC->EESR = (FPGA_DMA_RX_CHANNEL | FPGA_DMA_TX_CHANNEL);

        ENABLE_INTERRUPT_COMMUNICATION;
        ENABLE_INTERRUPT_MAIN;
        DebugPrintf("Device start to run!\r\n\r\n");
    }

    return NORMAL_SUCCESS;
}

//----------------------------------------------------------------------------------------------------
//   Function: MainInterruptService
//      Input: void
//     Output: void
//     Return: void
//Description: ���жϴ��������жϴ�������
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
#pragma INTERRUPT(MainInterruptService)
void MainInterruptService(void)
{
    Uint32 lv_time_cal;
    Uint16 lv_b_cnt;
    Uint16 lv_half_word_temp;
    Uint16 const *lv_p_fpga_frame;
    LOCAL_TIME lv_local_time;

    lv_time_cal = pTIMER0->TIM12;

    lv_b_cnt = pEDMA3CC->PARAMSET[23].A_B_CNT >> 16u;
    if (lv_b_cnt >= FPGA_RX_FRAME_NUM)
    {
        lv_b_cnt = 0;
    }
    fpga_rx_addr = FPGA_RX_FRAME_ADDR(FPGA_RX_FRAME_NUM - 2 - lv_b_cnt);
    lv_p_fpga_frame = fpga_rx_data[fpga_rx_addr];
    if (0 == (lv_p_fpga_frame[135u] & 0x10u))
    {
        lv_half_word_temp = lv_p_fpga_frame[120u];
        irigb.year =   ((lv_half_word_temp >> 12) & 0xfu) * 1000u
                     + ((lv_half_word_temp >> 8) & 0xfu) * 100u
                     + ((lv_half_word_temp >> 4) & 0xfu) * 10u
                     + (lv_half_word_temp & 0xfu);
        if ((0 == irigb.year) || (irigb.year > 4000u))
        {
            Usecond2LocalTime(&lv_local_time, system_local_usecond);
            irigb.year = lv_local_time.year - 2000u;
        }
        else if (irigb.year > 2000u)
        {
            irigb.year -= 2000u;
        }

        lv_half_word_temp = lv_p_fpga_frame[121u];
        irigb.day =      ((lv_half_word_temp >> 8) & 0xfu) * 100u
                       + ((lv_half_word_temp >> 4) & 0xfu) * 10u
                       + (lv_half_word_temp & 0xfu);
        lv_half_word_temp = lv_p_fpga_frame[122u];
        irigb.hour =     ((lv_half_word_temp >> 4) & 0xfu) * 10u
                       + (lv_half_word_temp & 0xfu);
        lv_half_word_temp = lv_p_fpga_frame[123u];
        irigb.minute =   ((lv_half_word_temp >> 4) & 0xfu) * 10u
                       + (lv_half_word_temp & 0xfu);
        lv_half_word_temp = lv_p_fpga_frame[124u];
        irigb.second =   ((lv_half_word_temp >> 4) & 0xfu) * 10u
                       + (lv_half_word_temp & 0xfu);
        irigb.msecond = lv_p_fpga_frame[125u];

        AppBeginNormalServices(&irigb, lv_time_cal);
    }
    else
    {
        AppBeginNormalServices(NULL, lv_time_cal);
    }


    if (0 != (pEDMA3CC->EMR & ((1 << 22) | (1 << 31))))
    {
        pEDMA3CC->EMCR = ((1 << 22) | (1 << 31));
        sys_statistics.dma_event_miss_count++;
    }

    if (0 == user_app_passby_mode)
    {
        UserApplication();
    }
    else
    {
        system_running_status &= (~CPU_RUNNING_FLAG);
    }

    AppEndNormalServices();
    LedControl();

    if (0 == (system_running_status & CPU_RUNNING_FLAG))
    {
        if (system_ms_count >= 5000u)
        {
            system_running_status |= CPU_RUNNING_FLAG;
            main_isr_max_run_time = 0;
        }
    }
    else
    {
        main_isr_run_time = pTIMER0->TIM12 - lv_time_cal;
        if (main_isr_run_time > main_isr_max_run_time)
        {
            main_isr_max_run_time = main_isr_run_time;
        }
    }
}

//----------------------------------------------------------------------------------------------------
// ���غ���
//----------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------
//   Function: LedControl
//      Input: void
//     Output: void
//     Return: void
//Description: ���ƿ���
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
static void LedControl(void)
{
    Uint8 lv_device_warning;

    if (0 != (system_running_status & CPU_RUNNING_FLAG))
    {
        lv_device_warning = 0;
        pGPIO->SET_DATA23 = GPIO_GP2P13;
    }
    else
    {
        pGPIO->CLR_DATA23 = GPIO_GP2P13;
        lv_device_warning = 1;
    }

    if (0 != laser_power.on)
    {
        pGPIO->SET_DATA23 = GPIO_GP3P14;
    }
    else
    {
        pGPIO->CLR_DATA23 = GPIO_GP3P14;
    }

    if ((0 != lv_device_warning) || (0 != sys_statistics.device_status))
    {
        pGPIO->SET_DATA23 = GPIO_GP2P15;
    }
    else
    {
        system_running_status &= (~CPU_WARNING_FLAG);
        pGPIO->CLR_DATA23 = GPIO_GP2P15;
    }
}


