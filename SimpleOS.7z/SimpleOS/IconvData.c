/*****************************************************************************************************
* FileName     :    IconvData.c
*
* Reference    :    NULL
*
* Description  :    ���ݱ��������ҵ���Ӧ���뺯��
*
* History      :
*       <AUTHOR>        <DATA>        <VERSION>        <DESCRIPTION>
*      YanDengxue     2009-12-19        *.**              Created
*
*****************************************************************************************************/
//====================================================================================================
// ���ļ�ʹ�õ�ͷ�ļ�
//====================================================================================================
// ��ͷ�ļ�
#include <string.h>

// �Զ���ͷ�ļ�
#include "UserTypesDef.h"
#include "IconvData.h"

//====================================================================================================
// �������Ͷ��弰�궨��
//====================================================================================================
// ֧�ֵı��뼰��Ӧ�ı��뺯���ṹ����
typedef struct
{
    int8 const  *p_encode_type_string;
    ICONVDATA_UCS4_ENCODE function;
} ICONVDATA_ENCODE_FUNCTION;

//====================================================================================================
// �ⲿ���ú�������
//====================================================================================================
// UCS4���뺯������
extern int32 Ucs4ToGb2312(Uint32 wch, int8 *destination, int32 dest_buffer_length);
extern int32 Ucs4ToKoi8_u(Uint32 wch, int8 *destination, int32 dest_buffer_length);
extern int32 Ucs4ToKoi8_r(Uint32 wch, int8 *destination, int32 dest_buffer_length);
extern int32 Ucs4ToWindows2512(Uint32 wch, int8 *destination, int32 dest_buffer_length);
extern int32 Ucs4ToWindows1251(Uint32 wch, int8 *destination, int32 dest_buffer_length);

//====================================================================================================
// ����ȫ�ֱ���
//====================================================================================================
// ϵͳ֧�ֵı��뷽ʽ
static ICONVDATA_ENCODE_FUNCTION const iconvdata_encode_function[] =
{
    {"NULL",        NULL},
    {"GB2312",      Ucs4ToGb2312},
    {"KOI8-R",      Ucs4ToKoi8_u},
    {"KOI8-U",      Ucs4ToKoi8_r},
    {"WINDOWS2512", Ucs4ToWindows2512},
    {"WINDOWS1251", Ucs4ToWindows1251},
};

#define ICONVDATA_MAX_ENCODE_TYPE (sizeof(iconvdata_encode_function) / sizeof(ICONVDATA_ENCODE_FUNCTION))// ��֧�ֵı�����Ŀ

//====================================================================================================
// ����ʵ��
//====================================================================================================
//----------------------------------------------------------------------------------------------------
//   Function: IconvdataEncodeFuntion
//      Input: int8 const *p_encode_type_string : ���������ַ����׵�ַ
//     Output: void
//     Return: ICONVDATA_ENCODE_FUNCTION : �������Ͷ�Ӧ�ı��뺯��
//Description: ����p_encode_type_string��ָ��ucs4���뷽ʽ�ı��뺯��
//             NULL��ʾδ�ҵ���Ӧ���뺯��
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2009-12-19 17:00          Created
//----------------------------------------------------------------------------------------------------
int32 IconvDataEncodeFuntion(int8 const *p_encode_type_string, ICONVDATA_UCS4_ENCODE *p_function)
{
    Uint32 i;

    // p_encode_type_stringָ��Ϊ�ջ���ָ��ĵ�һ���ַ�Ϊ��,��ֱ�ӷ���NULL
    if ((NULL == p_encode_type_string) || ('\0' == p_encode_type_string[0]))
    {
        *p_function = NULL;
        return NORMAL_SUCCESS;
    }

    for (i = 0; i < ICONVDATA_MAX_ENCODE_TYPE; i++)
    {
        if (0 == strcmp(iconvdata_encode_function[i].p_encode_type_string, p_encode_type_string))
        {
            *p_function = iconvdata_encode_function[i].function;
            return NORMAL_SUCCESS;
        }
    }

    return NORMAL_ERROR;
}

