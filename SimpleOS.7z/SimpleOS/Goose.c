/*****************************************************************************************************
* FileName:                    UserApp.c
*
* Description:                 �û�����������
*
* Author:                      YanDengxue, Fiberhome-Fuhua
*
* Rev History:
*       <Author>        <Data>        <Hardware>     <Version>        <Description>
*     YanDengxue   2011-03-29 15:30       --           1.00             Create
*****************************************************************************************************/
//====================================================================================================
// ���ļ�ʹ�õ�ͷ�ļ�
//====================================================================================================
// ��ͷ�ļ�
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

// �Զ���ͷ�ļ�
#include "UserTypesDef.h"
#include "C6747Register.h"
#include "SystemBase.h"
#include "BaseData.h"
#include "Goose.h"
#include "ProjectDataHandle.h"
#include "Asn1rEncodeDecode.h"
#include "Debug.h"
#include "NormalServices.h"
#include "UserApp.h"

//====================================================================================================
// ���غ�������,�˴������ĺ��������ⲿ�ӿ�
//====================================================================================================
static int32 GooseDataEventCheck(GOCB *p_gocb);
static void GooseSendDataHandle(GOCB *p_gocb);

//====================================================================================================
// ���ļ���������ⲿ�Ľӿڱ���
//====================================================================================================
PROJECT_TYPE_DEFINE const goose_prj_type_define[] =
{
    {"BOOLEAN",       PROJECT_DATA_TYPE_BOOLEAN},
    {"INT32",         PROJECT_DATA_TYPE_INT32},
    {"Dbpos",         PROJECT_DATA_TYPE_DBPOS},
    {"Quality",       PROJECT_DATA_TYPE_QUALITY},
};

int32 const goose_prj_type_define_num = sizeof(goose_prj_type_define) / sizeof(goose_prj_type_define[0]);

//====================================================================================================
// ����ʵ��
//====================================================================================================
//----------------------------------------------------------------------------------------------------
// �ӿں���
//----------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------
//   Function: GetGooseDataMaxLength
//      Input: PROJECT_DATA_TYPE data_type
//     Output: void
//     Return: int32: ���ݳ���,-1��ʾ�Ҳ�����Ӧ������
//Description: ��ȡ���ݳ���
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
int32 GetGooseDataMaxLength(PROJECT_DATA_TYPE data_type)
{
    switch (data_type)
    {
        case PROJECT_DATA_TYPE_BOOLEAN:
        {
            return 3;
        }
        case PROJECT_DATA_TYPE_DBPOS:
        {
            return 4;
        }
        case PROJECT_DATA_TYPE_INT32:
        {
            return 6;
        }
        case PROJECT_DATA_TYPE_QUALITY:
        {
            return 5;
        }
        case PROJECT_DATA_TYPE_UINT32:
        {
            return 7;
        }
        case PROJECT_DATA_TYPE_TIMESTAMP:
        {
            return 10;
        }
        default :
        {
            TRACE("unknow project data type \"%d\"", data_type);
            return NORMAL_ERROR;
        }
    }
}

//----------------------------------------------------------------------------------------------------
//   Function: GoosePacketSend
//      Input: void
//     Output: void
//     Return: void
//Description: Ӧ�ó���
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
void GoosePacketSend(void)
{
    Uint8 lv_force_send;
    int16 lv_cb_index;
    GOOSE_TX *lv_p_goose_tx;
    GOCB  *lv_p_gocb;
    Uint32 lv_time_cal;
    EMAC_DESCRIPTOR_REGS *lv_p_emac_desc_header;
    EMAC_DESCRIPTOR_REGS *lv_p_emac_desc_current;

    lv_p_goose_tx = &prj_cfg.goose_tx;
    if (0 != lv_p_goose_tx->cb_num)
    {
        if (0 != lv_p_goose_tx->status)
        {
            lv_p_emac_desc_header = NULL;
            lv_p_emac_desc_current = NULL;
            if (mu.test_old != mu.test)
            {
                lv_force_send = 1;
            }
            else
            {
                lv_force_send = 0;
            }
            for (lv_cb_index = 0; lv_cb_index < lv_p_goose_tx->cb_num; lv_cb_index++)
            {
                lv_p_gocb = &lv_p_goose_tx->gocb[lv_cb_index];
                if ((0 != GooseDataEventCheck(lv_p_gocb)) || (0 != lv_force_send))
                {
                    lv_p_gocb->status = GOCB_SEND_STATUS_FIRST_FRAME;
                }

                switch (lv_p_gocb->status)
                {
                    case GOCB_SEND_STATUS_HEARTBEAT:
                    {
                        lv_time_cal = system_ms_count - lv_p_gocb->last_frame_time;
                        if (lv_time_cal > lv_p_gocb->tal)
                        {
                            lv_p_gocb->last_frame_time += lv_p_gocb->tal;
                            lv_p_gocb->sq_num++;
                            if (0 == lv_p_gocb->sq_num)
                            {
                                lv_p_gocb->sq_num = 1;
                            }
                            GooseSendDataHandle(lv_p_gocb);
                            if (NULL == lv_p_emac_desc_header)
                            {
                                lv_p_emac_desc_header = lv_p_gocb->emac_desc;
                                lv_p_emac_desc_current = lv_p_gocb->emac_desc;
                            }
                            else
                            {
                                lv_p_emac_desc_current->next = lv_p_gocb->emac_desc;
                                lv_p_emac_desc_current = lv_p_gocb->emac_desc;
                            }
                        }
                        break;
                    }
                    case GOCB_SEND_STATUS_FIRST_FRAME:
                    {
                        lv_p_gocb->last_frame_time = system_ms_count;
                        lv_p_gocb->tal = lv_p_gocb->first_frame_tal;
                        lv_p_gocb->sq_num = 0;
                        lv_p_gocb->st_num++;
                        if (0 == lv_p_gocb->st_num)
                        {
                            lv_p_gocb->st_num = 1;
                        }
                        GooseSendDataHandle(lv_p_gocb);
                        if (NULL == lv_p_emac_desc_header)
                        {
                            lv_p_emac_desc_header = lv_p_gocb->emac_desc;
                            lv_p_emac_desc_current = lv_p_gocb->emac_desc;
                        }
                        else
                        {
                            lv_p_emac_desc_current->next = lv_p_gocb->emac_desc;
                            lv_p_emac_desc_current = lv_p_gocb->emac_desc;
                        }
                        lv_p_gocb->status = GOCB_SEND_STATUS_SECOND_FRAME;
                        break;
                    }
                    case GOCB_SEND_STATUS_SECOND_FRAME:
                    {
                        lv_time_cal = system_ms_count - lv_p_gocb->last_frame_time;
                        if (lv_time_cal >= lv_p_gocb->tal)
                        {
                            lv_p_gocb->last_frame_time += lv_p_gocb->tal;
                            lv_p_gocb->tal = lv_p_gocb->second_frame_tal;
                            lv_p_gocb->sq_num++;
                            if (0 == lv_p_gocb->sq_num)
                            {
                                lv_p_gocb->sq_num = 1;
                            }
                            GooseSendDataHandle(lv_p_gocb);
                            if (NULL == lv_p_emac_desc_header)
                            {
                                lv_p_emac_desc_header = lv_p_gocb->emac_desc;
                                lv_p_emac_desc_current = lv_p_gocb->emac_desc;
                            }
                            else
                            {
                                lv_p_emac_desc_current->next = lv_p_gocb->emac_desc;
                                lv_p_emac_desc_current = lv_p_gocb->emac_desc;
                            }
                            lv_p_gocb->status = GOCB_SEND_STATUS_THIRD_FRAME;
                        }
                        break;
                    }
                    case GOCB_SEND_STATUS_THIRD_FRAME:
                    {
                        lv_time_cal = system_ms_count - lv_p_gocb->last_frame_time;
                        if (lv_time_cal >= lv_p_gocb->tal)
                        {
                            lv_p_gocb->last_frame_time += lv_p_gocb->tal;
                            lv_p_gocb->tal = lv_p_gocb->third_frame_tal;
                            lv_p_gocb->sq_num++;
                            if (0 == lv_p_gocb->sq_num)
                            {
                                lv_p_gocb->sq_num = 1;
                            }
                            GooseSendDataHandle(lv_p_gocb);
                            if (NULL == lv_p_emac_desc_header)
                            {
                                lv_p_emac_desc_header = lv_p_gocb->emac_desc;
                                lv_p_emac_desc_current = lv_p_gocb->emac_desc;
                            }
                            else
                            {
                                lv_p_emac_desc_current->next = lv_p_gocb->emac_desc;
                                lv_p_emac_desc_current = lv_p_gocb->emac_desc;
                            }
                            lv_p_gocb->status = GOCB_SEND_STATUS_FOURTH_FRAME;
                        }
                        break;
                    }
                    case GOCB_SEND_STATUS_FOURTH_FRAME:
                    {
                        lv_time_cal = system_ms_count - lv_p_gocb->last_frame_time;
                        if (lv_time_cal >= lv_p_gocb->tal)
                        {
                            lv_p_gocb->last_frame_time += lv_p_gocb->tal;
                            lv_p_gocb->tal = lv_p_gocb->fourth_frame_tal;
                            lv_p_gocb->sq_num++;
                            if (0 == lv_p_gocb->sq_num)
                            {
                                lv_p_gocb->sq_num = 1;
                            }
                            GooseSendDataHandle(lv_p_gocb);
                            if (NULL == lv_p_emac_desc_header)
                            {
                                lv_p_emac_desc_header = lv_p_gocb->emac_desc;
                                lv_p_emac_desc_current = lv_p_gocb->emac_desc;
                            }
                            else
                            {
                                lv_p_emac_desc_current->next = lv_p_gocb->emac_desc;
                                lv_p_emac_desc_current = lv_p_gocb->emac_desc;
                            }
                            lv_p_gocb->status = GOCB_SEND_STATUS_FIFTH_FRAME;
                        }
                        break;
                    }
                    case GOCB_SEND_STATUS_FIFTH_FRAME:
                    {
                        lv_time_cal = system_ms_count - lv_p_gocb->last_frame_time;
                        if (lv_time_cal >= lv_p_gocb->tal)
                        {
                            lv_p_gocb->last_frame_time += lv_p_gocb->tal;
                            lv_p_gocb->tal = lv_p_gocb->heartbeat_tal;
                            lv_p_gocb->sq_num++;
                            if (0 == lv_p_gocb->sq_num)
                            {
                                lv_p_gocb->sq_num = 1;
                            }
                            GooseSendDataHandle(lv_p_gocb);
                            if (NULL == lv_p_emac_desc_header)
                            {
                                lv_p_emac_desc_header = lv_p_gocb->emac_desc;
                                lv_p_emac_desc_current = lv_p_gocb->emac_desc;
                            }
                            else
                            {
                                lv_p_emac_desc_current->next = lv_p_gocb->emac_desc;
                                lv_p_emac_desc_current = lv_p_gocb->emac_desc;
                            }
                            lv_p_gocb->status = GOCB_SEND_STATUS_HEARTBEAT;
                        }
                        break;
                    }
                    default:
                    {
                        break;
                    }
                }
            }
            if (NULL != lv_p_emac_desc_header)
            {
                lv_p_emac_desc_current->next = NULL;
                pEMAC->TX1HDP = lv_p_emac_desc_header;
            }
        }
        else
        {
            if (0 != (system_running_status & CPU_RUNNING_FLAG))
            {
                for (lv_cb_index = 0; lv_cb_index < lv_p_goose_tx->cb_num; lv_cb_index++)
                {
                    lv_p_gocb = &lv_p_goose_tx->gocb[lv_cb_index];
                    lv_p_gocb->sq_num = 1;
                    lv_p_gocb->st_num = 1;
                    lv_p_gocb->last_frame_time = system_ms_count;
                    lv_p_gocb->tal = lv_p_gocb->heartbeat_tal;
                    GooseDataEventCheck(lv_p_gocb);
                    GooseSendDataHandle(lv_p_gocb);
                    lv_p_gocb->status = GOCB_SEND_STATUS_HEARTBEAT;
                }
                pEMAC->TX1HDP = lv_p_goose_tx->gocb[0].emac_desc;
                pEMAC_CONTROL->C0TXEN |= 0x00000002;// Enable TX interrupts
                lv_p_goose_tx->status = 1;
            }
        }
    }
}

//----------------------------------------------------------------------------------------------------
// ���غ���
//----------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------
//   Function: GooseDataEventCheck
//      Input: GOCB *p_gocb
//     Output: void
//     Return: int32: ���ݳ���,-1��ʾ�Ҳ�����Ӧ������
//Description: �Ƿ���GOOSE�¼�
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
static int32 GooseDataEventCheck(GOCB *p_gocb)
{
    int32 lv_ret;
    int32 lv_cb_data_index;
    GOCB *lv_p_gocb;
    SIGNAL_OUT *lv_p_signal_out;
    PROJECT_TYPE_DEFINE const *lv_p_prj_type;
    SIGNAL_DEFINE const *lv_p_signal_define;
    SIGNAL_DATA lv_signal_data_temp;
    SIGNAL_DATA *lv_p_signal_data_last_value;

    lv_p_gocb = p_gocb;

    lv_ret = 0;
    for (lv_cb_data_index = lv_p_gocb->item_num - 1; lv_cb_data_index >= 0 ; lv_cb_data_index--)
    {
        lv_p_signal_out = &lv_p_gocb->singal_out[lv_cb_data_index];
        lv_p_prj_type = lv_p_signal_out->prj_type_define;
        lv_p_signal_define = lv_p_signal_out->define;
        lv_p_signal_data_last_value = &lv_p_signal_out->last_value;
        switch (lv_p_prj_type->type)
        {
            case PROJECT_DATA_TYPE_BOOLEAN:
            {
                lv_signal_data_temp.uc = *((Uint8 *)(lv_p_signal_define->addr));
                if (lv_signal_data_temp.uc != lv_p_signal_data_last_value->uc)
                {
                    lv_p_signal_data_last_value->uc = lv_signal_data_temp.uc;
                    lv_ret = 1;
                }
                break;
            }
            case PROJECT_DATA_TYPE_DBPOS:
            {
                lv_signal_data_temp.uc = *((Uint8 *)(lv_p_signal_define->addr));
                if (lv_signal_data_temp.uc != lv_p_signal_data_last_value->uc)
                {
                    lv_p_signal_data_last_value->uc = lv_signal_data_temp.uc;
                    lv_ret = 1;
                }
                break;
            }
            case PROJECT_DATA_TYPE_INT32 :
            {
                lv_signal_data_temp.l = *((int32 *)(lv_p_signal_define->addr));
                if (lv_signal_data_temp.l != lv_p_signal_data_last_value->l)
                {
                    lv_p_signal_data_last_value->l = lv_signal_data_temp.l;
                    lv_ret = 1;
                }
                break;
            }
            case PROJECT_DATA_TYPE_TIMESTAMP:
            {
                lv_signal_data_temp.l = *((int32 *)(lv_p_signal_define->addr));
                if (lv_signal_data_temp.l != lv_p_signal_data_last_value->l)
                {
                    lv_p_signal_data_last_value->l = lv_signal_data_temp.l;
                    lv_ret = 1;
                }
                break;
            }
            case PROJECT_DATA_TYPE_QUALITY :
            {
                lv_signal_data_temp.ul = *((Uint32 *)(lv_p_signal_define->addr));
                if (lv_signal_data_temp.ul != lv_p_signal_data_last_value->ul)
                {
                    lv_p_signal_data_last_value->ul = lv_signal_data_temp.ul;
                    lv_ret = 1;
                }
                break;
            }
            default :
            {
                break;
            }
        }
    }

    return lv_ret;
}

//----------------------------------------------------------------------------------------------------
//   Function: GooseSendDataHandle
//      Input: GOCB *p_gocb
//     Output: void
//     Return: void
//Description: Goose�������ݴ���
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
static void GooseSendDataHandle(GOCB *p_gocb)
{
    Uint8 *lv_p_frame_addr;
    Uint16 lv_all_data_length;
    Uint16 lv_apdu_length;
    Uint16 lv_frame_length;
    int32 lv_cb_data_index;
    GOCB *lv_p_gocb;
    SIGNAL_OUT const *lv_p_signal_out;
    PROJECT_TYPE_DEFINE const *lv_p_prj_type;
    SIGNAL_DEFINE const *lv_p_signal_define;
    SIGNAL_DATA lv_signal_data_temp;

    lv_p_gocb = p_gocb;
    lv_p_frame_addr = lv_p_gocb->frame_buffer_end;

    for (lv_cb_data_index = lv_p_gocb->item_num - 1; lv_cb_data_index >= 0 ; lv_cb_data_index--)
    {
        lv_p_signal_out = &lv_p_gocb->singal_out[lv_cb_data_index];
        lv_p_prj_type = lv_p_signal_out->prj_type_define;
        lv_p_signal_define = lv_p_signal_out->define;
        switch (lv_p_prj_type->type)
        {
            case PROJECT_DATA_TYPE_BOOLEAN:
            {
                lv_signal_data_temp.uc = *((Uint8 *)(lv_p_signal_define->addr));
                Bool2Asn1r(&lv_p_frame_addr, GOOSE_TYPE_TAG_BOOLEAN, lv_signal_data_temp.uc);
                break;
            }
            case PROJECT_DATA_TYPE_DBPOS:
            {
                lv_signal_data_temp.uc = *((Uint8 *)(lv_p_signal_define->addr));
                Dbpos2Asn1r(&lv_p_frame_addr, GOOSE_TYPE_TAG_BIT_STRING, lv_signal_data_temp.uc);
                break;
            }
            case PROJECT_DATA_TYPE_INT32 :
            {
                lv_signal_data_temp.l = *((int32 *)(lv_p_signal_define->addr));
                Int322Asn1r(&lv_p_frame_addr, GOOSE_TYPE_TAG_INTEGER, lv_signal_data_temp.l);
                break;
            }
            case PROJECT_DATA_TYPE_TIMESTAMP:
            {
                lv_signal_data_temp.l = *((int32 *)(lv_p_signal_define->addr));
                UTCTime2Asn1r(&lv_p_frame_addr, GOOSE_TYPE_TAG_UTC_TIME, system_local_usecond, sys_cfg.time_zone, 0);
                break;
            }
            case PROJECT_DATA_TYPE_QUALITY:
            {
                lv_signal_data_temp.ul = *((Uint32 *)(lv_p_signal_define->addr));
                Quality2Asn1r(&lv_p_frame_addr, GOOSE_TYPE_TAG_BIT_STRING, lv_signal_data_temp.ul);
                break;
            }
            default :
            {
                break;
            }
        }
    }

    lv_all_data_length = lv_p_gocb->frame_buffer_end - lv_p_frame_addr;
    Length2Asn1r(&lv_p_frame_addr, GOOSE_TAG_ALL_DAT, lv_all_data_length);

    Uint162Asn1r(&lv_p_frame_addr, GOOSE_TAG_NUM_DAT, lv_p_gocb->item_num);
    Bool2Asn1r(&lv_p_frame_addr, GOOSE_TAG_NDS_COM, 0u);
    Uint322Asn1r(&lv_p_frame_addr, GOOSE_TAG_CONF_REV, lv_p_gocb->conf_rev);
    Bool2Asn1r(&lv_p_frame_addr, GOOSE_TAG_TEST, mu.test);
    Uint322Asn1r(&lv_p_frame_addr, GOOSE_TAG_SQ_NUM, lv_p_gocb->sq_num);
    Uint322Asn1r(&lv_p_frame_addr, GOOSE_TAG_ST_NUM, lv_p_gocb->st_num);
    UTCTime2Asn1r(&lv_p_frame_addr, GOOSE_TAG_TIMESTAMP, system_local_usecond, sys_cfg.time_zone, 0);
    String2Asn1r(&lv_p_frame_addr, GOOSE_TAG_ID, lv_p_gocb->id);
    String2Asn1r(&lv_p_frame_addr, GOOSE_TAG_DAT_SET, lv_p_gocb->data_set);
    Uint322Asn1r(&lv_p_frame_addr, GOOSE_TAG_TAL, (lv_p_gocb->tal << 2));
    String2Asn1r(&lv_p_frame_addr, GOOSE_TAG_REF, lv_p_gocb->ref);

    lv_apdu_length = lv_p_gocb->frame_buffer_end - lv_p_frame_addr;
    Length2Asn1r(&lv_p_frame_addr, GOOSE_TAG_APDU, lv_apdu_length);

    lv_frame_length = lv_p_gocb->frame_buffer_end - lv_p_frame_addr + 30u;
    lv_p_frame_addr -= 30u;
    memcpy(lv_p_frame_addr, lv_p_gocb->frame_header, 30u);
    lv_p_frame_addr[24u] = LHSB(lv_frame_length - 22u);
    lv_p_frame_addr[25u] = LLSB(lv_frame_length - 22u);

    lv_p_gocb->emac_desc->buffer = lv_p_frame_addr;
    lv_p_gocb->emac_desc->buffer_offset_and_length =  0 | lv_frame_length;
    lv_p_gocb->emac_desc->flags_and_packet_length =  (EMAC_DESC_FLAG_OWNER | EMAC_DESC_FLAG_SOP | EMAC_DESC_FLAG_EOP)
                                                    | lv_frame_length;

}

