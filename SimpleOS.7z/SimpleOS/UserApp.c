/*****************************************************************************************************
* FileName:                    UserApp.c
*
* Description:                 �û�����������
*
* Author:                      YanDengxue, Fiberhome-Fuhua
*
* Rev History:
*       <Author>        <Data>        <Hardware>     <Version>        <Description>
*     YanDengxue   2011-03-29 15:30       --           1.00             Create
*****************************************************************************************************/
//====================================================================================================
// ���ļ�ʹ�õ�ͷ�ļ�
//====================================================================================================
// ��ͷ�ļ�
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

// �Զ���ͷ�ļ�
#include "UserTypesDef.h"
#include "C6747Register.h"
#include "SystemBase.h"
#include "FpgaDataSend.h"
#include "LaserPowerControl.h"
#include "UserApp.h"

//====================================================================================================
// ���ļ���������ⲿ�Ľӿڱ���
//====================================================================================================
MERGING_UNIT mu;
SYSTEM_STATISTICS sys_statistics;

float sv_9_2_coefficient_local[MU_CHANNEL_NUM];
float amplitude_coefficient_local[MU_CHANNEL_NUM];
int16 delay_coefficient_local[MU_CHANNEL_NUM];
float phase_coefficient_a_local[MU_CHANNEL_NUM];
float phase_coefficient_b_local[MU_CHANNEL_NUM];

//====================================================================================================
// ���ر�������,�˴������ı��������ⲿ�ӿ�
//====================================================================================================
static Uint8  sync_mode_last = 0;
static Uint8  setting_change_flag = 0;
static Uint16 user_app_run_cnt = 0;
static Uint32 pps_count_last = 0;
static int16  channel_data[MU_CHANNEL_NUM][FPGA_RX_FRAME_MERGE_NUM];
static Uint32 channel_count_last[MU_CHANNEL_NUM];
static Uint32 channel_count_last_last[MU_CHANNEL_NUM];
static Uint16 sv_addr[MU_CHANNEL_NUM];
static Uint16 sv_merge_addr[MU_CHANNEL_NUM];
static Uint32 channel_err_cnt[MU_CHANNEL_NUM];
static float sv_channel_data_org_last[MU_CHANNEL_NUM];

static float sv_9_2_coefficient_local_temp[MU_CHANNEL_NUM];
static float amplitude_coefficient_local_temp[MU_CHANNEL_NUM];
static int16 delay_coefficient_local_temp[MU_CHANNEL_NUM];
static float phase_coefficient_a_local_temp[MU_CHANNEL_NUM];
static float phase_coefficient_b_local_temp[MU_CHANNEL_NUM];

static Uint8  laser_power_online_temp;
static Uint32 laser_power_on_effective_current_temp;
static Uint32 laser_power_off_effective_current_temp;
static Uint32 laser_power_communication_interval_temp;
static Uint32 laser_power_on_min_time_temp;

static Uint8 const fpga_data_coeff_index[] =
{
    0, 0, 0, 0, 0, 0, 0, 0,
    1, 1, 1, 1, 1, 1, 2, 2,
    2, 2, 2, 2, 2, 2, 2, 2
};

static float const fir_coefficient_hamming_lowpass_800_10k[FIR_COEFFICIENT_LENGTH] =
{
    -0.0024482423658892891,
    -0.003600288344644092,
    -0.0052020582335030171,
    -0.0045625221555773898,
     0.0026742058557356718,
     0.020426809430029998,
     0.049652620680280202,
     0.086749779584897393,
     0.1239094637670982,
     0.1515282741312857,
     0.16174391530057336,
     0.1515282741312857,
     0.1239094637670982,
     0.086749779584897393,
     0.049652620680280202,
     0.020426809430029998,
     0.0026742058557356718,
    -0.0045625221555773898,
    -0.0052020582335030171,
    -0.003600288344644092,
    -0.0024482423658892891,
};

//====================================================================================================
// ����ʵ��
//====================================================================================================
//----------------------------------------------------------------------------------------------------
// �ӿں���
//----------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------
//   Function: UserApplicationInitial
//      Input: void
//     Output: void
//     Return: int32: ����ִ�����
//Description: Ӧ�ó����ʼ������
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
int32 UserApplicationInitial(void)
{
    int16  lv_channel_index;
    
    for (lv_channel_index = 0; lv_channel_index < MU_CHANNEL_NUM; lv_channel_index++)
    {
        channel_err_cnt[lv_channel_index] = 0u;
    }
    setting_change_flag = 0;
    return UserApplicationSettingHandle();
}

//----------------------------------------------------------------------------------------------------
//   Function: UserApplicationSettingHandle
//      Input: void
//     Output: void
//     Return: int32: ����ִ�����
//Description: Ӧ�ó�����������ļ�
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
int32 UserApplicationSettingHandle(void)
{
    Uint32 i;
    float lv_float_temp;
    float lv_sv_9_2_coefficient[3];

    lv_sv_9_2_coefficient[0] = mu.primary_rated_current * 1000.00f / 11585.00f;
    lv_sv_9_2_coefficient[1] = mu.primary_rated_current * 1000.00f / 463.00f;
    lv_sv_9_2_coefficient[2] = mu.primary_rated_voltage * 100000.00f / 11585.00f;
    for (i = 0; i < MU_CHANNEL_NUM; i++)
    {
        sv_9_2_coefficient_local_temp[i] = lv_sv_9_2_coefficient[fpga_data_coeff_index[i]];
        if ((mu.channel[i].amplitude_coefficient < 0.0000001f) && (mu.channel[i].amplitude_coefficient > -0.0000001f))
        {
            amplitude_coefficient_local_temp[i] = 1.0000f;
        }
        else
        {
            amplitude_coefficient_local_temp[i] = mu.channel[i].amplitude_coefficient;
        }

        delay_coefficient_local_temp[i] = (mu.channel[i].delay_adjust * 2000 + 27) / 54;

        lv_float_temp =  mu.channel[i].phase_adjust * PI / (180 *  60);
        phase_coefficient_a_local_temp[i] = sin(lv_float_temp + 2 * PI / 80) / 0.07845909572784494503296024599346;  
        phase_coefficient_b_local_temp[i] = sin(lv_float_temp) / 0.07845909572784494503296024599346;  
    }

    if (laser_power.power_off_effective_current <= laser_power.power_on_effective_current)
    {
        TRACE_ERROR("laser power off current must greater than laser power on current");
        return NORMAL_ERROR;
    }
    laser_power_online_temp = laser_power.online;
    laser_power_on_effective_current_temp  = laser_power.power_on_effective_current  * 1000;
    laser_power_off_effective_current_temp = laser_power.power_off_effective_current * 1000;
    laser_power_communication_interval_temp = laser_power.communication_interval;
    laser_power_on_min_time_temp = laser_power.power_on_min_time;

    setting_change_flag = 1;

    return NORMAL_SUCCESS;
}

//----------------------------------------------------------------------------------------------------
//   Function: UpdateUserRunningSetting
//      Input: void
//     Output: void
//     Return: int32: ����ִ�����
//Description: �û���ֵ���º���
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
void UpdateUserRunningSetting(void)
{
    int32 lv_channel_index;

    for (lv_channel_index = 0; lv_channel_index < MU_CHANNEL_NUM; lv_channel_index++)
    {
       delay_coefficient_local[lv_channel_index]     = delay_coefficient_local_temp[lv_channel_index];
       amplitude_coefficient_local[lv_channel_index] = amplitude_coefficient_local_temp[lv_channel_index];
       phase_coefficient_a_local[lv_channel_index]   = phase_coefficient_a_local_temp[lv_channel_index];
       phase_coefficient_b_local[lv_channel_index]   = phase_coefficient_b_local_temp[lv_channel_index];
       sv_9_2_coefficient_local[lv_channel_index]    = sv_9_2_coefficient_local_temp[lv_channel_index];
    }
    
    laser_power_online = laser_power_online_temp;
    laser_power_on_effective_current  = laser_power_on_effective_current_temp;
    laser_power_off_effective_current = laser_power_off_effective_current_temp;
    laser_power_communication_interval = laser_power_communication_interval_temp;
    laser_power_on_min_time = laser_power_on_min_time_temp;
}

//----------------------------------------------------------------------------------------------------
//   Function: UserApplication
//      Input: void
//     Output: void
//     Return: void
//Description: Ӧ�ó���
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
void UserApplication(void)
{
    int16  lv_channel_index;
    int16  lv_rsv_dot_index;
    int16  lv_dot_index;
    float  lv_ret;
    float  lv_data[3];
    int32  lv_diff_t0;
    int32  lv_diff_t1;
    int32  lv_diff_t2;
    int32  lv_diff_t0t1;
    int32  lv_diff_t0t2;
    int32  lv_diff_t1t2;
    Uint32 lv_channel_count_last;
    Uint32 lv_channel_count_last_last;
    Uint16 lv_rsv_addr;
    Uint16 const *lv_p_fpga_frame_current;
    Uint16 const *lv_p_fpga_frame;
    int16  const *lv_p_channel_data_org;
    Uint16 lv_bit_index;
    int32  lv_diff_pps_count;
    Uint16 lv_delay_addr_h;
    Uint16 lv_delay_addr_l;
    Uint32 lv_pps_count_current;
    Uint32 lv_frame_count_current;
    Uint32 lv_frame_count_cal;
    int16  lv_channel_data;
    Uint32 lv_channel_count;
    int32  lv_diff_frame_to_data_count;
    Uint32 lv_pps_hold_width;
    Uint16 lv_merge_addr;
    Uint16 lv_channel_status;
    float  lv_sv_channel_data_org_last;
    MERGING_UNIT_CHANNEL *lv_p_channel;
    MERGING_UNIT_CHANNEL *lv_p_current_channel;

    if (user_app_run_cnt < 4)
    {
        user_app_run_cnt++;
        if (4 == user_app_run_cnt)
        {
            for (lv_channel_index = 0; lv_channel_index < MU_CHANNEL_NUM; lv_channel_index++)
            {
                sv_addr[lv_channel_index] = FPGA_RX_FRAME_ADDR(fpga_rx_addr - 6);
                sv_merge_addr[lv_channel_index] = 0;
            }
        }
        return;
    }

    ProjectDataHandle();
    if (mu.smp_count < (mu.smp_freq - 1))
    {
        mu.smp_count++;
    }
    else
    {
        mu.smp_count = 0;
    }

    if (0 != setting_change_flag)
    {
        setting_change_flag = 0;
        UpdateUserRunningSetting();
    }

    lv_p_fpga_frame_current = fpga_rx_data[FPGA_RX_FRAME_ADDR(fpga_rx_addr - 2)];
    if (0 != (system_running_status & CPU_RUNNING_FLAG))
    {
        lv_pps_count_current = lv_p_fpga_frame_current[127u] | (lv_p_fpga_frame_current[128u] << 16u);
        lv_diff_pps_count = lv_pps_count_current - pps_count_last;
        if (0 != lv_diff_pps_count)
        {
            mu.smp_count = 0;
            lv_pps_hold_width = lv_p_fpga_frame_current[133u] | (lv_p_fpga_frame_current[134u] << 16u);
            mu.pps_hold_flag = PPSHoldControl(&lv_pps_hold_width, 39999999u, 400000u, (lv_p_fpga_frame_current[135] & 1), (sync_mode_last != sys_cfg.sync_mode));
            mu.pps_hold_width_cal = lv_pps_hold_width;
            sync_mode_last = sys_cfg.sync_mode;
        }
        pps_count_last = lv_pps_count_current;
    }

    mu.test_old = mu.test;
    mu.test = (lv_p_fpga_frame_current[126] & 1);

    mu.fpga_pps_sync_flag = ((~lv_p_fpga_frame_current[135]) & 1u);
    mu.pps_sync_flag = (mu.pps_hold_flag | mu.fpga_pps_sync_flag);

    mu.delay_const_quality = (mu.test << 11u);

    lv_p_channel = mu.channel;
    lv_frame_count_current = lv_p_fpga_frame_current[131u] | (lv_p_fpga_frame_current[132u] << 16u);
    for (lv_channel_index = 0; lv_channel_index < MU_CHANNEL_NUM; lv_channel_index++)
    {
        lv_p_current_channel = &lv_p_channel[lv_channel_index];
        lv_delay_addr_l = 60u + (lv_channel_index << 1);
        lv_delay_addr_h = lv_delay_addr_l + 1;
        lv_frame_count_cal = lv_frame_count_current + delay_coefficient_local[lv_channel_index];
        while (sv_addr[lv_channel_index] != fpga_rx_addr)
        {
            sv_addr[lv_channel_index] = FPGA_RX_FRAME_ADDR(sv_addr[lv_channel_index] + 1);
            lv_p_fpga_frame = fpga_rx_data[sv_addr[lv_channel_index]];

            lv_channel_count = lv_p_fpga_frame[lv_delay_addr_l] | (lv_p_fpga_frame[lv_delay_addr_h] << 16u);

            lv_channel_data = lv_p_fpga_frame[lv_channel_index];
            lv_channel_status = (lv_p_fpga_frame[30u + lv_channel_index] ^ 1u);

            lv_merge_addr = sv_merge_addr[lv_channel_index];
            if ((0 != (lv_channel_status & 1u)) || (0 != channel_err_cnt[lv_channel_index]))
            {
                lv_p_current_channel->data = 0;
                lv_p_current_channel->data_org = 0;
                channel_data[lv_channel_index][lv_merge_addr] = lv_channel_data;
                sv_channel_data_org_last[lv_channel_index] = 0;
                sv_merge_addr[lv_channel_index] = FPGA_RX_FRAME_MERGE_ADDR(lv_merge_addr + 1);
                if (channel_err_cnt[lv_channel_index] < (FIR_COEFFICIENT_LENGTH + 5))
                {
                    channel_err_cnt[lv_channel_index]++;
                }
                else
                {
                    if (0 == (lv_channel_status & 1u))
                    {
                        channel_err_cnt[lv_channel_index] = 0;
                    }
                }
            }
            else
            {
                lv_channel_count_last = channel_count_last[lv_channel_index];
                if (lv_channel_count == lv_channel_count_last)
                {
                    continue;
                }
                else
                {
                    lv_channel_count_last_last = channel_count_last_last[lv_channel_index];
                    channel_count_last_last[lv_channel_index] = lv_channel_count_last;
                    channel_count_last[lv_channel_index] = lv_channel_count;

                    sv_merge_addr[lv_channel_index] = FPGA_RX_FRAME_MERGE_ADDR(lv_merge_addr + 1);
                    channel_data[lv_channel_index][lv_merge_addr] = lv_channel_data;

                    lv_diff_frame_to_data_count = (lv_frame_count_cal - lv_channel_count);
                    if (lv_diff_frame_to_data_count < 0)
                    {
                        lv_diff_t1 = lv_frame_count_cal - lv_channel_count_last;
                        lv_diff_t0 = lv_frame_count_cal - lv_channel_count_last_last;
                        lv_diff_t2 = lv_diff_frame_to_data_count;
                        lv_diff_t0t1 = lv_channel_count_last_last - lv_channel_count_last;
                        lv_diff_t0t2 = lv_channel_count_last_last - lv_channel_count;
                        lv_diff_t1t2 = lv_channel_count_last - lv_channel_count;
                        if ((0 == lv_diff_t0t1) || (0 == lv_diff_t0t2) || (0 == lv_diff_t0t2))
                        {
                            lv_p_current_channel->data = 0;
                            lv_p_current_channel->data_org = 0;
                        }
                        else
                        {
                            lv_p_channel_data_org = channel_data[lv_channel_index];
                            for (lv_rsv_dot_index = 0; lv_rsv_dot_index < 3; lv_rsv_dot_index++)
                            {
                                lv_ret = 0;
                                lv_rsv_addr = lv_merge_addr - 2u + lv_rsv_dot_index;
                                for (lv_dot_index = 0; lv_dot_index < FIR_COEFFICIENT_LENGTH; lv_dot_index++)
                                {
                                    lv_ret += (float)lv_p_channel_data_org[FPGA_RX_FRAME_MERGE_ADDR(lv_rsv_addr - lv_dot_index)] * fir_coefficient_hamming_lowpass_800_10k[lv_dot_index];
                                }
                                lv_data[lv_rsv_dot_index] = lv_ret;
                            }
                            
                            lv_ret =   (lv_data[0] * lv_diff_t1 * lv_diff_t2) / (lv_diff_t0t1 * lv_diff_t0t2)
                                     - (lv_data[1] * lv_diff_t0 * lv_diff_t2) / (lv_diff_t0t1 * lv_diff_t1t2)
                                     + (lv_data[2] * lv_diff_t0 * lv_diff_t1) / (lv_diff_t1t2 * lv_diff_t0t2);
                            lv_ret *= amplitude_coefficient_local[lv_channel_index];
                            lv_sv_channel_data_org_last = sv_channel_data_org_last[lv_channel_index];
                            sv_channel_data_org_last[lv_channel_index] = lv_ret;

                            lv_ret = lv_ret * phase_coefficient_a_local[lv_channel_index] - lv_sv_channel_data_org_last * phase_coefficient_b_local[lv_channel_index];
                            
                            lv_p_current_channel->data = lv_ret * sv_9_2_coefficient_local[lv_channel_index];
                            lv_p_current_channel->data_org = lv_ret;
                        }
                        break;
                    }
                }
            }
            for (lv_bit_index = 0; lv_bit_index < 16; lv_bit_index++)
            {
                lv_p_current_channel->status_bit[lv_bit_index] = ((lv_channel_status >> lv_bit_index) & 1);
            }
            lv_p_current_channel->quality = ((mu.test << 11u) | lv_p_current_channel->status_bit[0]);
        }
    }

    FpgaDataSend(fpga_tx_data);
    LaserPowerControl();

    if (0 != laser_power.uart_rx_overtime_flag)
    {
        sys_statistics.device_status = 1;
    }
    else
    {
        sys_statistics.device_status = 0;
    }
}


