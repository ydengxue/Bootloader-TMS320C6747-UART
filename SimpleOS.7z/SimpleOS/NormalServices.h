/*****************************************************************************************************
* FileName     :    NormalServices.h
*
* Reference    :    NULL
*
* Description  :    ϵͳ���û���ͷ�ļ�
*
* History      :
*       <Author>        <Data>        <Hardware>     <Version>        <Description>
*     YanDengxue   2011-03-29 15:30       --           1.00             Create
*****************************************************************************************************/
#ifndef _Normal_Services_H_
#define _Normal_Services_H_

#ifdef __cplusplus
extern "C" {
#endif

//====================================================================================================
// �ⲿ��������
//====================================================================================================
extern VUint32 system_ms_count;
extern VUint64 system_local_usecond;

//====================================================================================================
// �ⲿ��������
//====================================================================================================
extern void AppBeginNormalServices(IRIGB const *p_irig_b, Uint32 timer0b12_current_value);
extern void AppEndNormalServices(void);
extern void HmiCommunicationDataTransport(void);

#ifdef __cplusplus
}
#endif

#endif
