/*****************************************************************************************************
* FileName:                    Command.c
*
* Description:                 ���������
*
* Author:                      YanDengxue, Fiberhome-Fuhua
*
* Rev History:
*       <Author>        <Data>        <Hardware>     <Version>        <Description>
*     YanDengxue   2011-03-29 15:30       --           1.00             Create
*****************************************************************************************************/
//====================================================================================================
// ���ļ�ʹ�õ�ͷ�ļ�
//====================================================================================================
// ��ͷ�ļ�
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

// �Զ���ͷ�ļ�
#include "UserTypesDef.h"
#include "C6747Register.h"
#include "SystemBase.h"
#include "BaseData.h"
#include "ParseConfig.h"
#include "SettingManage.h"
#include "SpiFlash.h"
#include "HmiCommunication.h"
#include "Debug.h"
#include "NormalServices.h"
#include "UserApp.h"

//====================================================================================================
// ���Ͷ���
//====================================================================================================
typedef int32 (*COMMAND_FUNCTION)(int8 const *);

//====================================================================================================
// �������Ͷ��弰�궨��
//====================================================================================================
// ֧�ֵ������Ӧ��������ṹ����
typedef struct
{
    int8 const  *p_command_string;
    COMMAND_FUNCTION function;
    int8 const  *help;
} COMMAND_FUNCTION_DIFINE;

//====================================================================================================
// ���غ�������,�˴������ĺ��������ⲿ�ӿ�
//====================================================================================================
static int32 CommandTime(char const *args);
static int32 CommandDf(char const *args);
static int32 CommandDd(char const *args);
static int32 CommandDw(char const *args);
static int32 CommandDb(char const *args);
static int32 CommandDbSpi0(char const *args);
static int32 CommandIf(char const *args);
static int32 CommandId(char const *args);
static int32 CommandIw(char const *args);
static int32 CommandIb(char const *args);
static int32 CommandCat(char const *args);
static int32 CommandLs(char const *args);
static int32 CommandSet(char const *args);
static int32 CommandSave(char const *args);
static int32 CommandDownload(char const *args);
static int32 CommandReboot(char const *args);
static int32 CommandHelp(char const *args);

//====================================================================================================
// ����ȫ�ֱ���
//====================================================================================================
// ϵͳ֧�ֵı��뷽ʽ
static COMMAND_FUNCTION_DIFINE const command_function_define[] =
{
    {"time",     CommandTime,     "useage:time xxxx-xx-xx xx:xx:xx"},
    {"df",       CommandDf,       "useage:df address num"},
    {"dd",       CommandDd,       "useage:dd address num"},
    {"dw",       CommandDw,       "useage:dw address num"},
    {"db",       CommandDb,       "useage:db address num"},
    {"db.spi0",  CommandDbSpi0,   "useage:db.spi0 address num"},
    {"if",       CommandIf,       "useage:if interval address num"},
    {"id",       CommandId,       "useage:id interval address num"},
    {"iw",       CommandIw,       "useage:iw interval address num"},
    {"ib",       CommandIb,       "useage:ib interval address num"},
    {"cat",      CommandCat,      "useage:cat \"file name\""},
    {"ls",       CommandLs,       "useage:ls"},
    {"set",      CommandSet,      "useage:set"},
    {"save",     CommandSave,     "useage:save"},
    {"download", CommandDownload, "useage:download"},
    {"reboot",   CommandReboot,   "useage:reboot"},
    {"help",     CommandHelp,     "useage:help"},
};

static int32 const command_function_define_num = (sizeof(command_function_define) / sizeof(command_function_define[0]));

//====================================================================================================
// ����ʵ��
//====================================================================================================
//----------------------------------------------------------------------------------------------------
// �ӿں���
//----------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------
//   Function: RunCommand
//      Input: void
//     Output: void
//     Return: int32: ����ִ�����
//Description: ���������ִ�к���
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
int32 RunCommand(char const *args)
{
    int32 i;
    char lv_buffer[256u];
    char const *lv_p_frame_buffer;

    if (NULL == args)
    {
        TRACE("function entry error!");
        return NORMAL_ERROR;
    }

    lv_p_frame_buffer = GetContentToSplit(args, lv_buffer, 256u);
    for (i = 0; i < command_function_define_num; i++)
    {
        if (0 == strcmp(command_function_define[i].p_command_string, lv_buffer))
        {
            if (NORMAL_ERROR == command_function_define[i].function(lv_p_frame_buffer))
            {
                DebugPrintf("%s\r\n", command_function_define[i].help);
                return NORMAL_ERROR;
            }
            else
            {
                return NORMAL_SUCCESS;
            }
        }
    }

    DebugPrintf("Unknow command \"%s\"!\r\n", args);
    CommandHelp(NULL);

    return NORMAL_ERROR;
}

//----------------------------------------------------------------------------------------------------
// ���غ���
//----------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------
//   Function: CommandDate
//      Input: char const *args
//     Output: void
//     Return: int32: ����ִ�����
//Description: �ڴ�������ʾ����,������ʾ
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
static int32 CommandTime(char const *args)
{
    char lv_buffer[256u];
    char *lv_p_next;
    char *lv_p_buffer_end;
    Uint32 lv_time_cal;
    Uint32 lv_ulong_temp;
    LOCAL_TIME lv_local_time;

    if (NULL == args)
    {
        Usecond2LocalTime(&lv_local_time, system_local_usecond);
        DebugPrintf("    %04u-%02u-%02u %02u:%02u:%02u.%03u"
                    , lv_local_time.year
                    , lv_local_time.month
                    , lv_local_time.day
                    , lv_local_time.hour
                    , lv_local_time.minute
                    , lv_local_time.second
                    , lv_local_time.msecond);

        lv_time_cal = system_ms_count;
        while (debug_rx_buffer_rd_ptr == debug_rx_buffer_wr_ptr)
        {
            if ((system_ms_count - lv_time_cal) > 50u)
            {
                lv_time_cal += 50u;
                DebugPrintf("\r");
                Usecond2LocalTime(&lv_local_time, system_local_usecond);
                DebugPrintf("    %04u-%02u-%02u %02u:%02u:%02u.%03u"
                            , lv_local_time.year
                            , lv_local_time.month
                            , lv_local_time.day
                            , lv_local_time.hour
                            , lv_local_time.minute
                            , lv_local_time.second
                            , lv_local_time.msecond);
            }
        }
    }
    else
    {
        args = GetContentToSplit(args, lv_buffer, 256u);
        lv_p_buffer_end = lv_buffer + strlen(lv_buffer);
        lv_local_time.year  = strtoul(lv_buffer, &lv_p_next, 10);
        lv_p_next++;
        if (lv_p_next >= lv_p_buffer_end)
        {
            DebugPrintf("date input error\r\n");
            return NORMAL_ERROR;
        }
        lv_local_time.month = strtoul(lv_p_next, &lv_p_next, 10);
        lv_p_next++;
        if (lv_p_next >= lv_p_buffer_end)
        {
            DebugPrintf("date input error\r\n");
            return NORMAL_ERROR;
        }
        lv_local_time.day   = strtoul(lv_p_next, NULL, 10);

        lv_ulong_temp = (system_local_usecond / 1000u) % (24u * 60u * 60u * 1000u);
        lv_local_time.msecond = lv_ulong_temp % 1000u;
        if (NULL != args)
        {
            GetContentToSplit(args, lv_buffer, 256u);
            lv_p_buffer_end = lv_buffer + strlen(lv_buffer);
            lv_local_time.hour   = strtoul(lv_buffer, &lv_p_next, 10);
            lv_p_next++;
            if (lv_p_next >= lv_p_buffer_end)
            {
                DebugPrintf("date input error\r\n");
                return NORMAL_ERROR;
            }
            lv_local_time.minute = strtoul(lv_p_next, &lv_p_next, 10);
            lv_p_next++;
            if (lv_p_next >= lv_p_buffer_end)
            {
                DebugPrintf("date input error\r\n");
                return NORMAL_ERROR;
            }
            lv_local_time.second = strtoul(lv_p_next, &lv_p_next, 10);
            lv_p_next++;
            if (lv_p_next < lv_p_buffer_end)
            {
                lv_local_time.msecond = strtoul(lv_p_next, NULL, 10);
            }
        }
        else
        {
            lv_ulong_temp /= 1000u;
            lv_local_time.second = lv_ulong_temp % 60u;
            lv_ulong_temp /= 60u;
            lv_local_time.minute = lv_ulong_temp % 60u;
            lv_ulong_temp /= 60u;
            lv_local_time.hour   = lv_ulong_temp;
        }

        if (NORMAL_SUCCESS != CheckLocalTimeValid(&lv_local_time))
        {
            DebugPrintf("time check failed\r\n");
            return NORMAL_ERROR;
        }

        system_local_usecond = LocalTime2Usecond(&lv_local_time);

        DebugPrintf("    %04u-%02u-%02u %02u:%02u:%02u.%03u"
                    , lv_local_time.year
                    , lv_local_time.month
                    , lv_local_time.day
                    , lv_local_time.hour
                    , lv_local_time.minute
                    , lv_local_time.second
                    , lv_local_time.msecond);
    }

    return NORMAL_SUCCESS;
}

//----------------------------------------------------------------------------------------------------
//   Function: CommandDf
//      Input: char const *args
//     Output: void
//     Return: int32: ����ִ�����
//Description: �ڴ�������ʾ����,������ʾ
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
static int32 CommandDf(char const *args)
{
    char   lv_buffer[256u];
    int32  lv_index;
    Uint32 lv_word_temp;
    Uint32 lv_display_num;
    float *lv_float_buffer;
    float const *lv_float_addr;

    if (NULL == args)
    {
        DebugPrintf("df must have one argment!\r\n");
        return NORMAL_ERROR;
    }

    args = GetContentToSplit(args, lv_buffer, 256u);
    lv_word_temp = strtoul(lv_buffer, NULL, 0);
    lv_word_temp = ((lv_word_temp >> 2) << 2);

    if (NULL == args)
    {
        lv_display_num = 1;
    }
    else
    {
        GetContentToSplit(args, lv_buffer, 256u);
        lv_display_num = strtoul(lv_buffer, NULL, 0);
        if ((lv_display_num <= 0) || (lv_display_num > 0x800000))
        {
            DebugPrintf("lv_display_num=%u is exceed (0, 0x800000]\r\n", lv_display_num);
            return NORMAL_ERROR;
        }
    }

    lv_float_buffer = malloc(lv_display_num * sizeof(float));
    if (NULL == lv_float_buffer)
    {
        DebugPrintf("df display buffer malloc failed\r\n");
        return NORMAL_ERROR;
    }

    lv_float_addr = (float const *)lv_word_temp;
    for (lv_index = 0; lv_index < lv_display_num; lv_index++)
    {
        lv_float_buffer[lv_index] = lv_float_addr[lv_index];
    }

    for (lv_index = 0; lv_index < lv_display_num; lv_index++)
    {
        if (0 == (lv_index % 4))
        {
            DebugPrintf("\r\n%08X:", (Uint32)&lv_float_addr[lv_index]);
        }
        DebugPrintf("%27.12f ", lv_float_buffer[lv_index]);
    }

    free(lv_float_buffer);

    return lv_display_num;
}

//----------------------------------------------------------------------------------------------------
//   Function: CommandDd
//      Input: char const *args
//     Output: void
//     Return: int32: ����ִ�����
//Description: �ڴ�������ʾ����,������ʾ
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
static int32 CommandDd(char const *args)
{
    char   lv_buffer[256u];
    int32  lv_index;
    Uint32 lv_word_temp;
    Uint32 lv_display_num;
    Uint32 *lv_word_buffer;
    Uint32 const *lv_word_addr;

    if (NULL == args)
    {
        DebugPrintf("dd must have one argment!\r\n");
        return NORMAL_ERROR;
    }

    args = GetContentToSplit(args, lv_buffer, 256u);
    lv_word_temp = strtoul(lv_buffer, NULL, 0);
    lv_word_temp = ((lv_word_temp >> 2) << 2);

    if (NULL == args)
    {
        lv_display_num = 1;
    }
    else
    {
        GetContentToSplit(args, lv_buffer, 256u);
        lv_display_num = strtoul(lv_buffer, NULL, 0);
        if ((lv_display_num <= 0) || (lv_display_num > 0x800000))
        {
            DebugPrintf("lv_display_num=%u is exceed (0, 0x800000]\r\n", lv_display_num);
            return NORMAL_ERROR;
        }
    }

    lv_word_buffer = malloc(lv_display_num * sizeof(Uint32));
    if (NULL == lv_word_buffer)
    {
        DebugPrintf("dd display buffer malloc failed\r\n");
        return NORMAL_ERROR;
    }

    lv_word_addr = (Uint32 const *)lv_word_temp;
    for (lv_index = 0; lv_index < lv_display_num; lv_index++)
    {
        lv_word_buffer[lv_index] = lv_word_addr[lv_index];
    }

    for (lv_index = 0; lv_index < lv_display_num; lv_index++)
    {
        if (0 == (lv_index % 4))
        {
            DebugPrintf("\r\n%08X:", (Uint32)&lv_word_addr[lv_index]);
        }
        DebugPrintf("%08X ", lv_word_buffer[lv_index]);
    }

    free(lv_word_buffer);

    return lv_display_num;
}

//----------------------------------------------------------------------------------------------------
//   Function: CommandDw
//      Input: char const *args
//     Output: void
//     Return: int32: ����ִ�����
//Description: �ڴ�������ʾ����,��������ʾ
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
static int32 CommandDw(char const *args)
{
    char   lv_buffer[256u];
    int32  lv_index;
    Uint32 lv_word_temp;
    Uint32 lv_display_num;
    Uint16 *lv_half_word_buffer;
    Uint16 const *lv_half_word_addr;

    if (NULL == args)
    {
        DebugPrintf("dw must have one argment!\r\n");
        return NORMAL_ERROR;
    }

    args = GetContentToSplit(args, lv_buffer, 256u);
    lv_word_temp = strtoul(lv_buffer, NULL, 0);
    lv_word_temp = ((lv_word_temp >> 1) << 1);

    if (NULL == args)
    {
        lv_display_num = 1;
    }
    else
    {
        GetContentToSplit(args, lv_buffer, 256u);
        lv_display_num = strtoul(lv_buffer, NULL, 0);
        if ((lv_display_num <= 0) || (lv_display_num > 0x1000000))
        {
            DebugPrintf("lv_display_num=%u is exceed (0, 0x1000000]\r\n", lv_display_num);
            return NORMAL_ERROR;
        }
    }

    lv_half_word_buffer = malloc(lv_display_num * sizeof(Uint16));
    if (NULL == lv_half_word_buffer)
    {
        DebugPrintf("dw display buffer malloc failed\r\n");
        return NORMAL_ERROR;
    }

    lv_half_word_addr = (Uint16 const *)lv_word_temp;
    for (lv_index = 0; lv_index < lv_display_num; lv_index++)
    {
        lv_half_word_buffer[lv_index] = lv_half_word_addr[lv_index];
    }

    for (lv_index = 0; lv_index < lv_display_num; lv_index++)
    {
        if (0 == (lv_index % 8))
        {
            DebugPrintf("\r\n%08X:", (Uint32)&lv_half_word_addr[lv_index]);
        }
        DebugPrintf("%04X ", lv_half_word_buffer[lv_index]);
    }

    free(lv_half_word_buffer);

    return lv_display_num;
}

//----------------------------------------------------------------------------------------------------
//   Function: CommandDw
//      Input: char const *args
//     Output: void
//     Return: int32: ����ִ�����
//Description: �ڴ�������ʾ����,���ֽ���ʾ
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
static int32 CommandDb(char const *args)
{
    char   lv_buffer[256u];
    int32  lv_index;
    Uint32 lv_word_temp;
    int32  lv_display_num;
    Uint8  *lv_byte_buffer;
    Uint8  const *lv_byte_addr;

    if (NULL == args)
    {
        DebugPrintf("db must have one argment!\r\n");
        return NORMAL_ERROR;
    }

    args = GetContentToSplit(args, lv_buffer, 256);
    lv_word_temp = strtoul(lv_buffer, NULL, 0);
    if (NULL == args)
    {
        lv_display_num = 1;
    }
    else
    {
        GetContentToSplit(args, lv_buffer, 256u);
        lv_display_num = strtoul(lv_buffer, NULL, 0);
        if ((lv_display_num <= 0) ||  (lv_display_num > 0x2000000))
        {
            DebugPrintf("lv_display_num=%u is exceed (0, 0x2000000]\r\n", lv_display_num);
            return NORMAL_ERROR;
        }
    }

    lv_byte_buffer = malloc(lv_display_num * sizeof(Uint8));
    if (NULL == lv_byte_buffer)
    {
        DebugPrintf("db display buffer malloc failed\r\n");
        return NORMAL_ERROR;
    }

    lv_byte_addr = (Uint8 const *)lv_word_temp;
    for (lv_index = 0; lv_index < lv_display_num; lv_index++)
    {
        lv_byte_buffer[lv_index] = lv_byte_addr[lv_index];
    }

    for (lv_index = 0; lv_index < lv_display_num; lv_index++)
    {
        if (0 == (lv_index % 16))
        {
            DebugPrintf("\r\n%08X:", (Uint32)&lv_byte_addr[lv_index]);
        }
        DebugPrintf("%02X ", lv_byte_buffer[lv_index]);
    }

    free(lv_byte_buffer);

    return lv_display_num;
}

//----------------------------------------------------------------------------------------------------
//   Function: CommandDbSpi0
//      Input: char const *args
//     Output: void
//     Return: int32: ����ִ�����
//Description: Spi0������ʾ����,���ֽ���ʾ
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
static int32 CommandDbSpi0(char const *args)
{
    char   lv_buffer[256u];
    Uint8  lv_byte_temp;
    int32  lv_index;
    Uint32 lv_word_temp;
    int32  lv_display_num;
    Uint8  *lv_byte_buffer;

    if (NULL == args)
    {
        DebugPrintf("db must have one argment!\r\n");
        return NORMAL_ERROR;
    }

    args = GetContentToSplit(args, lv_buffer, 256u);
    lv_word_temp = strtoul(lv_buffer, NULL, 0);
    if (NULL == args)
    {
        lv_display_num = 1;
    }
    else
    {
        GetContentToSplit(args, lv_buffer, 256u);
        lv_display_num = strtoul(lv_buffer, NULL, 0);
        if ((lv_display_num <= 0) ||  (lv_display_num > 0x2000000))
        {
            DebugPrintf("lv_display_num=%u is exceed (0, 0x2000000]\r\n", lv_display_num);
            return NORMAL_ERROR;
        }
    }

    lv_byte_buffer = malloc(lv_display_num * sizeof(Uint8));
    if (NULL == lv_byte_buffer)
    {
        DebugPrintf("db display buffer malloc failed\r\n");
        return NORMAL_ERROR;
    }

    WinbondW25FastRead(lv_word_temp, lv_display_num, lv_byte_buffer);
    for (lv_index = 0; lv_index < lv_display_num; lv_index++)
    {
        if (0 == (lv_index % 16))
        {
            DebugPrintf("\r\n%08X:", lv_word_temp);
        }
        lv_byte_temp = lv_byte_buffer[lv_index];
        DebugPrintf("%02X ", lv_byte_temp);
        lv_word_temp++;
    }

    free(lv_byte_buffer);

    return NORMAL_SUCCESS;
}

//----------------------------------------------------------------------------------------------------
//   Function: CommandIf
//      Input: char const *args
//     Output: void
//     Return: int32: ����ִ�����
//Description: �ڴ�����������ʾ����,������ʾ
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
static int32 CommandIf(char const *args)
{
    int32 i;
    char  lv_buffer[256u];
    int32 lv_display_num;
    int32 lv_row_num;
    Uint32 lv_time_cal;
    Uint32 lv_display_time_interval;

    if (NULL == args)
    {
        DebugPrintf("id must have two argments!\r\n");
        return NORMAL_ERROR;
    }

    args = GetContentToSplit(args, lv_buffer, 256u);
    lv_display_time_interval = strtoul(lv_buffer, NULL, 0);
    if (lv_display_time_interval > 30000u)
    {
        lv_display_time_interval = 30000u;
    }

    lv_display_num = CommandDf(args);
    if (lv_display_num < 0)
    {
        TRACE("Command df error");
        return NORMAL_ERROR;
    }

    lv_time_cal = system_ms_count;
    lv_row_num = ((lv_display_num + 3) >> 2);
    while (debug_rx_buffer_rd_ptr == debug_rx_buffer_wr_ptr)
    {
        if ((system_ms_count - lv_time_cal) > lv_display_time_interval)
        {
            lv_time_cal += lv_display_time_interval;
            DebugPrintf("\r");
            for (i = 0; i < lv_row_num; i++)
            {
                DebugPrintf("\e[A");
            }
            if (CommandDf(args) < 0)
            {
                TRACE("Command df error");
                return NORMAL_ERROR;
            }
        }
    }
    debug_rx_buffer_rd_ptr++;

    return NORMAL_SUCCESS;
}

//----------------------------------------------------------------------------------------------------
//   Function: CommandId
//      Input: char const *args
//     Output: void
//     Return: int32: ����ִ�����
//Description: �ڴ�����������ʾ����,������ʾ
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
static int32 CommandId(char const *args)
{
    int32 i;
    char  lv_buffer[256u];
    int32 lv_display_num;
    int32 lv_row_num;
    Uint32 lv_time_cal;
    Uint32 lv_display_time_interval;

    if (NULL == args)
    {
        DebugPrintf("id must have two argments!\r\n");
        return NORMAL_ERROR;
    }

    args = GetContentToSplit(args, lv_buffer, 256u);
    lv_display_time_interval = strtoul(lv_buffer, NULL, 0);
    if (lv_display_time_interval > 30000u)
    {
        lv_display_time_interval = 30000u;
    }

    lv_display_num = CommandDd(args);
    if (lv_display_num < 0)
    {
        TRACE("Command db error");
        return NORMAL_ERROR;
    }

    lv_time_cal = system_ms_count;
    lv_row_num = ((lv_display_num + 3) >> 2);
    while (debug_rx_buffer_rd_ptr == debug_rx_buffer_wr_ptr)
    {
        if ((system_ms_count - lv_time_cal) > lv_display_time_interval)
        {
            lv_time_cal += lv_display_time_interval;
            DebugPrintf("\r");
            for (i = 0; i < lv_row_num; i++)
            {
                DebugPrintf("\e[A");
            }
            if (CommandDd(args) < 0)
            {
                TRACE("Command dd error");
                return NORMAL_ERROR;
            }
        }
    }
    debug_rx_buffer_rd_ptr++;

    return NORMAL_SUCCESS;
}

//----------------------------------------------------------------------------------------------------
//   Function: CommandIw
//      Input: char const *args
//     Output: void
//     Return: int32: ����ִ�����
//Description: �ڴ�����������ʾ����,��������ʾ
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
static int32 CommandIw(char const *args)
{
    int32 i;
    char  lv_buffer[256u];
    int32 lv_display_num;
    int32 lv_row_num;
    Uint32 lv_time_cal;
    Uint32 lv_display_time_interval;

    if (NULL == args)
    {
        DebugPrintf("iw must have two argments!\r\n");
        return NORMAL_ERROR;
    }

    args = GetContentToSplit(args, lv_buffer, 256u);
    lv_display_time_interval = strtoul(lv_buffer, NULL, 0);
    if (lv_display_time_interval > 30000u)
    {
        lv_display_time_interval = 30000u;
    }

    lv_display_num = CommandDw(args);
    if (lv_display_num < 0)
    {
        TRACE("Command db error");
        return NORMAL_ERROR;
    }

    lv_time_cal = system_ms_count;
    lv_row_num = ((lv_display_num + 7) >> 3);
    while (debug_rx_buffer_rd_ptr == debug_rx_buffer_wr_ptr)
    {
        if ((system_ms_count - lv_time_cal) > lv_display_time_interval)
        {
            lv_time_cal += lv_display_time_interval;
            DebugPrintf("\r");
            for (i = 0; i < lv_row_num; i++)
            {
                DebugPrintf("\e[A");
            }
            if (CommandDw(args) < 0)
            {
                TRACE("Command dw error");
                return NORMAL_ERROR;
            }
        }
    }

    debug_rx_buffer_rd_ptr++;

    return NORMAL_SUCCESS;
}

//----------------------------------------------------------------------------------------------------
//   Function: CommandIb
//      Input: char const *args
//     Output: void
//     Return: int32: ����ִ�����
//Description: �ڴ�����������ʾ����,���ֽ���ʾ
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
static int32 CommandIb(char const *args)
{
    int32 i;
    char  lv_buffer[256u];
    int32 lv_display_num;
    int32 lv_row_num;
    Uint32 lv_time_cal;
    Uint32 lv_display_time_interval;

    if (NULL == args)
    {
        DebugPrintf("ib must have two argments!\r\n");
        return NORMAL_ERROR;
    }

    args = GetContentToSplit(args, lv_buffer, 256u);
    lv_display_time_interval = strtoul(lv_buffer, NULL, 0);
    if (lv_display_time_interval > 30000u)
    {
        lv_display_time_interval = 30000u;
    }

    lv_display_num = CommandDb(args);
    if (lv_display_num < 0)
    {
        TRACE("Command db error");
        return NORMAL_ERROR;
    }

    lv_time_cal = system_ms_count;
    lv_row_num = ((lv_display_num + 15) >> 4);
    while (debug_rx_buffer_rd_ptr == debug_rx_buffer_wr_ptr)
    {
        if ((system_ms_count - lv_time_cal) > lv_display_time_interval)
        {
            lv_time_cal += lv_display_time_interval;
            DebugPrintf("\r");
            for (i = 0; i < lv_row_num; i++)
            {
                DebugPrintf("\e[A");
            }
            if (CommandDb(args) < 0)
            {
                TRACE("Command db error");
                return NORMAL_ERROR;
            }
        }
    }

    debug_rx_buffer_rd_ptr++;

    return NORMAL_SUCCESS;
}

//----------------------------------------------------------------------------------------------------
//   Function: CommandCat
//      Input: char const *args
//     Output: void
//     Return: int32: ����ִ�����
//Description: �����ļ���ʾ����
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
static int32 CommandCat(char const *args)
{
    char  lv_buffer[256u];
    Uint8 *lv_uchar_buffer;
    Uint8  lv_uchar_temp;
    int32  lv_index;
    int32  lv_cfg_length;
    int32  lv_spi_addr;
    int32  lv_cfg_max_length;

    if (NULL == args)
    {
        DebugPrintf("cat must have one argment!\r\n");
        return NORMAL_ERROR;
    }

    lv_spi_addr = 0;
    GetContentToSplit(args, lv_buffer, 256u);
    if (0 == strcmp("DevCfg.txt", lv_buffer))
    {
        lv_spi_addr = FLASH_DEV_CFG_START_ADDR;
        lv_cfg_max_length = FLASH_DEV_CFG_LENGTH;
    }
    else if (0 == strcmp("PrjCfg.txt", lv_buffer))
    {
        lv_spi_addr = FLASH_PRJ_CFG_START_ADDR;
        lv_cfg_max_length = FLASH_PRJ_CFG_LENGTH;
    }
    else
    {
        DebugPrintf("\r\nUnknow config file name \"%s\"!\r\n", lv_buffer);
        return NORMAL_ERROR;
    }

    lv_uchar_buffer = (Uint8 *)lv_buffer;
    WinbondW25FastRead(lv_spi_addr, SELF_BIN_HEADER_LENGTH, lv_uchar_buffer);

    lv_cfg_length = lv_uchar_buffer[0] | (lv_uchar_buffer[1] << 8u) | (lv_uchar_buffer[2] << 16u) | (lv_uchar_buffer[3] << 24u);
    if ((lv_cfg_length < 3u) ||(lv_cfg_length + SELF_BIN_HEADER_LENGTH) > lv_cfg_max_length)
    {
        DebugPrintf(" length=%d failed, exceed %d\r\n", lv_cfg_length, lv_cfg_max_length - (SELF_BIN_HEADER_LENGTH));
        return NORMAL_ERROR;
    }

    lv_spi_addr += (SELF_BIN_HEADER_LENGTH + 3u);
    lv_cfg_length -= (9u + 3u);
    for (lv_index = 0u; lv_index < lv_cfg_length; lv_index++)
    {
        WinbondW25Read(lv_spi_addr + lv_index, 1u, &lv_uchar_temp);
        if (('\r' == lv_uchar_temp) || ('\n' == lv_uchar_temp))
        {
            DebugPrintf("\r\n");
            if ('\r' == lv_uchar_temp)
            {
                lv_index++;
            }
        }
        else
        {
            DebugPrintf("%c", lv_uchar_temp);
        }
    }

    return NORMAL_SUCCESS;
}

//----------------------------------------------------------------------------------------------------
//   Function: CommandLs
//      Input: char const *args
//     Output: void
//     Return: int32: ����ִ�����
//Description: װ��֧�ֵ������ļ�������ʾ����
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
static int32 CommandLs(char const *args)
{
    Uint8  lv_uchar_buffer[256u];
    int32  lv_file_length;
    int32  lv_spi_timecrc_addr;
    int32  lv_spi_addr;
    Uint32 lv_word_temp;
    float  lv_version;

    DebugPrintf(" FlashAddr     Size          ModifyTime       Version   CRC    FileName\r\n");
    DebugPrintf("------------------------------------------------------------------------------\r\n");

    lv_spi_addr = FLASH_APP_START_ADDR;
    WinbondW25FastRead(FLASH_APP_END_ADDR - SELF_BIN_HEADER_LENGTH + 1u, SELF_BIN_HEADER_LENGTH, lv_uchar_buffer);

    lv_file_length = lv_uchar_buffer[0] | (lv_uchar_buffer[1] << 8u) | (lv_uchar_buffer[2] << 16u) | (lv_uchar_buffer[3] << 24u);
    if ((lv_file_length < 0) && ((lv_file_length + SELF_BIN_HEADER_LENGTH) > FLASH_APP_LENGTH))
    {
        DebugPrintf(" length=%d failed, exceed [0,%d]\r\n", lv_file_length, FLASH_APP_LENGTH - SELF_BIN_HEADER_LENGTH);
        return NORMAL_ERROR;
    }

    lv_word_temp = (lv_uchar_buffer[8]) | (lv_uchar_buffer[9] << 8) | (lv_uchar_buffer[10] << 16) | (lv_uchar_buffer[11] << 24);
    lv_version = *((float *)&lv_word_temp);

    lv_file_length -= 9;
    lv_spi_timecrc_addr = lv_spi_addr + lv_file_length;
    WinbondW25FastRead(lv_spi_timecrc_addr, 9u, lv_uchar_buffer);
    DebugPrintf("0x%08X", FLASH_APP_START_ADDR);
    DebugPrintf("  0x%08X", lv_file_length);
    DebugPrintf("  %04u-%02u-%02u %02u:%02u:%02u"
                 , lv_uchar_buffer[0] | (lv_uchar_buffer[1] << 8)
                 , lv_uchar_buffer[2]
                 , lv_uchar_buffer[3]
                 , lv_uchar_buffer[4]
                 , lv_uchar_buffer[5]
                 , lv_uchar_buffer[6]);
    DebugPrintf("  % 8.4f", lv_version);
    DebugPrintf("  0x%04X", lv_uchar_buffer[7] | (lv_uchar_buffer[8] << 8));
    DebugPrintf("  %s\r\n", "UserApplication");

    lv_spi_addr = FLASH_FPGA_START_ADDR;
    WinbondW25FastRead(lv_spi_addr, SELF_BIN_HEADER_LENGTH, lv_uchar_buffer);

    lv_word_temp = (buffer_public[8]) | (buffer_public[9] << 8) | (buffer_public[10] << 16) | (buffer_public[11] << 24);
    lv_version = *((float *)&lv_word_temp);

    lv_file_length = lv_uchar_buffer[0] | (lv_uchar_buffer[1] << 8u) | (lv_uchar_buffer[2] << 16u) | (lv_uchar_buffer[3] << 24u);
    if ((lv_file_length < 0) && ((lv_file_length + SELF_BIN_HEADER_LENGTH) > FLASH_FPGA_LENGTH))
    {
        DebugPrintf(" length=%d failed, exceed 0,%d]\r\n", lv_file_length, FLASH_FPGA_LENGTH - SELF_BIN_HEADER_LENGTH);
        return NORMAL_ERROR;
    }

    lv_word_temp = (lv_uchar_buffer[8]) | (lv_uchar_buffer[9] << 8) | (lv_uchar_buffer[10] << 16) | (lv_uchar_buffer[11] << 24);
    lv_version = *((float *)&lv_word_temp);

    lv_file_length -= 9;
    lv_spi_addr += SELF_BIN_HEADER_LENGTH;
    lv_spi_timecrc_addr = lv_spi_addr + lv_file_length;
    WinbondW25FastRead(lv_spi_timecrc_addr, 9u, lv_uchar_buffer);
    DebugPrintf("0x%08X", FLASH_FPGA_START_ADDR + SELF_BIN_HEADER_LENGTH);
    DebugPrintf("  0x%08X", lv_file_length);
    DebugPrintf("  %04u-%02u-%02u %02u:%02u:%02u"
                 , lv_uchar_buffer[0] | (lv_uchar_buffer[1] << 8)
                 , lv_uchar_buffer[2]
                 , lv_uchar_buffer[3]
                 , lv_uchar_buffer[4]
                 , lv_uchar_buffer[5]
                 , lv_uchar_buffer[6]);
    DebugPrintf("  % 8.4f", lv_version);
    DebugPrintf("  0x%04X", lv_uchar_buffer[7] | (lv_uchar_buffer[8] << 8));
    DebugPrintf("  %s\r\n", "Fpga");

    lv_spi_addr = FLASH_DEV_CFG_START_ADDR;
    WinbondW25FastRead(lv_spi_addr, SELF_BIN_HEADER_LENGTH, lv_uchar_buffer);

    lv_file_length = lv_uchar_buffer[0] | (lv_uchar_buffer[1] << 8u) | (lv_uchar_buffer[2] << 16u) | (lv_uchar_buffer[3] << 24u);
    if ((lv_file_length < 0) && ((lv_file_length + SELF_BIN_HEADER_LENGTH) > FLASH_DEV_CFG_LENGTH))
    {
        DebugPrintf(" length=%d failed, exceed [0,%d]\r\n", lv_file_length, FLASH_DEV_CFG_LENGTH - SELF_BIN_HEADER_LENGTH);
        return NORMAL_ERROR;
    }

    lv_word_temp = (lv_uchar_buffer[8]) | (lv_uchar_buffer[9] << 8) | (lv_uchar_buffer[10] << 16) | (lv_uchar_buffer[11] << 24);
    lv_version = *((float *)&lv_word_temp);

    lv_file_length -= 9;
    lv_spi_addr += SELF_BIN_HEADER_LENGTH;
    lv_spi_timecrc_addr = lv_spi_addr + lv_file_length;
    WinbondW25FastRead(lv_spi_timecrc_addr, 9u, lv_uchar_buffer);
    DebugPrintf("0x%08X", FLASH_DEV_CFG_START_ADDR + SELF_BIN_HEADER_LENGTH);
    DebugPrintf("  0x%08X", lv_file_length);
    DebugPrintf("  %04u-%02u-%02u %02u:%02u:%02u"
                 , lv_uchar_buffer[0] | (lv_uchar_buffer[1] << 8)
                 , lv_uchar_buffer[2]
                 , lv_uchar_buffer[3]
                 , lv_uchar_buffer[4]
                 , lv_uchar_buffer[5]
                 , lv_uchar_buffer[6]);
    DebugPrintf("  % 8.4f", lv_version);
    DebugPrintf("  0x%04X", lv_uchar_buffer[7] | (lv_uchar_buffer[8] << 8));
    DebugPrintf("  %s\r\n", "DevCfg.txt");

    lv_spi_addr = FLASH_PRJ_CFG_START_ADDR;
    WinbondW25FastRead(lv_spi_addr, SELF_BIN_HEADER_LENGTH, lv_uchar_buffer);

    lv_file_length = lv_uchar_buffer[0] | (lv_uchar_buffer[1] << 8u) | (lv_uchar_buffer[2] << 16u) | (lv_uchar_buffer[3] << 24u);
    if ((lv_file_length < 0) && ((lv_file_length + SELF_BIN_HEADER_LENGTH) > FLASH_PRJ_CFG_LENGTH))
    {
        DebugPrintf(" length=%d failed, exceed [0,%d]\r\n", lv_file_length, FLASH_PRJ_CFG_LENGTH - (SELF_BIN_HEADER_LENGTH));
        return NORMAL_ERROR;
    }

    lv_word_temp = (lv_uchar_buffer[8]) | (lv_uchar_buffer[9] << 8) | (lv_uchar_buffer[10] << 16) | (lv_uchar_buffer[11] << 24);
    lv_version = *((float *)&lv_word_temp);

    lv_file_length -= 9;
    lv_spi_addr += SELF_BIN_HEADER_LENGTH;
    lv_spi_timecrc_addr = lv_spi_addr + lv_file_length;
    WinbondW25FastRead(lv_spi_timecrc_addr, 9u, lv_uchar_buffer);
    DebugPrintf("0x%08X", FLASH_PRJ_CFG_START_ADDR + SELF_BIN_HEADER_LENGTH);
    DebugPrintf("  0x%08X", lv_file_length);
    DebugPrintf("  %04u-%02u-%02u %02u:%02u:%02u"
                 , lv_uchar_buffer[0] | (lv_uchar_buffer[1] << 8)
                 , lv_uchar_buffer[2]
                 , lv_uchar_buffer[3]
                 , lv_uchar_buffer[4]
                 , lv_uchar_buffer[5]
                 , lv_uchar_buffer[6]);
    DebugPrintf("  % 8.4f", lv_version);
    DebugPrintf("  0x%04X", lv_uchar_buffer[7] | (lv_uchar_buffer[8] << 8));
    DebugPrintf("  %s\r\n", "PrjCfg.txt");

    return NORMAL_SUCCESS;
}

//----------------------------------------------------------------------------------------------------
//   Function: CommandSet
//      Input: char const *args
//     Output: void
//     Return: int32 :����ִ�����
//Description: ��ֵ�鿴����
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
static int32 CommandSet(char const *args)
{
    int32 i;
    int32 j;
    int32 lv_index;
    int8  lv_debug_mode;
    int8  lv_all_setting_flag;
    char  lv_buffer[256u];
    int32 lv_space_length;
    int32 lv_setting_start_addr;
    int32 lv_setting_end_addr;
    SETTING const *lv_p_setting;
    SIGNAL_DATA lv_signal_data;

    lv_debug_mode = 0;
    lv_all_setting_flag = 0;
    if (NULL == args)
    {
        lv_setting_start_addr = 0;
        lv_setting_end_addr   = setting_system.num;
    }
    else
    {
        args = GetContentToSplit(args, lv_buffer, 256u);
        if (0 == strcmp(lv_buffer, "debug"))
        {
            if (NULL != args)
            {
                DebugPrintf("after \"debug\" must be \"\"!\r\n");
                return NORMAL_ERROR;
            }
            lv_debug_mode = 1;
            lv_setting_start_addr = 0;
            lv_setting_end_addr   = setting_system.num;
        }
        else if (0 == strcmp(lv_buffer, "all"))
        {
            lv_all_setting_flag = 1;
            lv_setting_start_addr = 0;
            lv_setting_end_addr   = setting_system.num;
        }
        else
        {
            lv_setting_start_addr = strtoul(lv_buffer, NULL, 0);
            for (i = 0, lv_index = 0; i < setting_system.num; i++)
            {
                lv_p_setting = &setting_system.setting[i];
                if ((0 != lv_p_setting->visible))
                {
                    lv_index++;
                }
            }
            if ((lv_setting_start_addr < 1) || (lv_setting_start_addr > lv_index))
            {
                DebugPrintf("set index=%d exceed [1, %d] !\r\n", lv_setting_start_addr, lv_index);
                return NORMAL_ERROR;
            }
            lv_setting_start_addr--;
            lv_setting_end_addr = lv_setting_start_addr + 1;
        }
    }

    if ((NULL != args) && (0 == lv_debug_mode))
    {
        GetContentToSplit(args, lv_buffer, 256u);
        if ((0 != lv_all_setting_flag) && (0 != strcmp(lv_buffer, "default")))
        {
            DebugPrintf("after \"all\" must be \"default\"!\r\n");
            return NORMAL_ERROR;
        }

        for (i = 0, lv_index = 0; i < setting_system.num; i++)
        {
            lv_p_setting = &setting_system.setting[i];
            if ((0 == lv_all_setting_flag) && (0 == lv_p_setting->visible))
            {
                continue;
            }
            if (lv_index >= lv_setting_start_addr)
            {
                if (NORMAL_SUCCESS != SetOneWriteSettingStringValue(&setting_system, args, i))
                {
                    DebugPrintf("setting set error!\n\r");
                    return NORMAL_ERROR;
                }
            }
            lv_index++;
            if (lv_index >= lv_setting_end_addr)
            {
                break;
            }
        }
        RunSettingUpdateFromWriteBuffer(&setting_system);
        if (NORMAL_SUCCESS != UserApplicationSettingHandle())
        {
            RunSettingAndWriteBufferUpdateFromRunBuffer(&setting_system);
            UserApplicationSettingHandle();
            DebugPrintf("Application settings check failed!\n\r");
        }
        else
        {
            SettingRunBufferUpdateFromWriteBuffer(&setting_system);
        }
    }

    DebugPrintf("  NO :                                DESCRIPTION                      MIN             MAX         DEFAULT          ACTIVE UNIT\n\r");
    DebugPrintf("-----------------------------------------------------------------------------------------------------------------------------------\n\r");
    for (i = 0, lv_index = 0; i < setting_system.num; i++)
    {
        lv_p_setting = &setting_system.setting[i];
        if ((0 == lv_debug_mode) && (0 == lv_p_setting->visible))
        {
            continue;
        }
        if (lv_index >= lv_setting_start_addr)
        {
            DebugPrintf("  %3d:", lv_index + 1);
            lv_space_length = 48 - strlen(lv_p_setting->desc);
            if (lv_space_length > 0)
            {
                for (j = 0; j < lv_space_length; j++)
                {
                    DebugPrintf(" ");
                }
            }
            DebugPrintf("\"");
            DebugPrintf("%s\"  ", lv_p_setting->desc);
            switch (lv_p_setting->define->type)
            {
                //�ַ�������SET_VAL_LEN_MAX�ֽ�
                case SIGNAL_DATA_TYPE_b:
                case SIGNAL_DATA_TYPE_c:
                {
                    lv_signal_data.c = lv_p_setting->min_value.c;
                    DebugPrintf("% 16d", lv_signal_data.c);
                    lv_signal_data.c = lv_p_setting->max_value.c;
                    DebugPrintf("% 16d", lv_signal_data.c);
                    lv_signal_data.c = lv_p_setting->default_value.c;
                    DebugPrintf("% 16d", lv_signal_data.c);
                    lv_signal_data.c = *((char *)lv_p_setting->define->addr);
                    DebugPrintf("% 16d", lv_signal_data.c);
                    break;
                }
                case SIGNAL_DATA_TYPE_uc:
                {
                    lv_signal_data.uc = lv_p_setting->min_value.uc;
                    DebugPrintf("% 16u", lv_signal_data.uc);
                    lv_signal_data.uc = lv_p_setting->max_value.uc;
                    DebugPrintf("% 16u", lv_signal_data.uc);
                    lv_signal_data.uc = lv_p_setting->default_value.uc;
                    DebugPrintf("% 16u", lv_signal_data.uc);
                    lv_signal_data.uc = *((Uint8 *)lv_p_setting->define->addr);
                    DebugPrintf("% 16u", lv_signal_data.uc);
                    break;
                }
                case SIGNAL_DATA_TYPE_i:
                {
                    lv_signal_data.i = lv_p_setting->min_value.i;
                    DebugPrintf("% 16d", lv_signal_data.i);
                    lv_signal_data.i = lv_p_setting->max_value.i;
                    DebugPrintf("% 16d", lv_signal_data.i);
                    lv_signal_data.i = lv_p_setting->default_value.i;
                    DebugPrintf("% 16d", lv_signal_data.i);
                    lv_signal_data.i = *((int16 *)lv_p_setting->define->addr);
                    DebugPrintf("% 16d", lv_signal_data.i);
                    break;
                }
                case SIGNAL_DATA_TYPE_ui:
                {
                    lv_signal_data.ui = lv_p_setting->min_value.ui;
                    DebugPrintf("% 16u", lv_signal_data.ui);
                    lv_signal_data.ui = lv_p_setting->max_value.ui;
                    DebugPrintf("% 16u", lv_signal_data.ui);
                    lv_signal_data.ui = lv_p_setting->default_value.ui;
                    DebugPrintf("% 16u", lv_signal_data.ui);
                    lv_signal_data.ui = *((Uint16 *)lv_p_setting->define->addr);
                    DebugPrintf("% 16u", lv_signal_data.ui);
                    break;
                }
                case SIGNAL_DATA_TYPE_l:
                {
                    lv_signal_data.l = lv_p_setting->min_value.l;
                    DebugPrintf("% 16d", lv_signal_data.l);
                    lv_signal_data.l = lv_p_setting->max_value.l;
                    DebugPrintf("% 16d", lv_signal_data.l);
                    lv_signal_data.l = lv_p_setting->default_value.l;
                    DebugPrintf("% 16d", lv_signal_data.l);
                    lv_signal_data.l = *((int32 *)lv_p_setting->define->addr);
                    DebugPrintf("% 16d", lv_signal_data.l);
                    break;
                }
                case SIGNAL_DATA_TYPE_ul:
                {
                    lv_signal_data.ul = lv_p_setting->min_value.ul;
                    DebugPrintf("% 16u", lv_signal_data.ul);
                    lv_signal_data.ul = lv_p_setting->max_value.ul;
                    DebugPrintf("% 16u", lv_signal_data.ul);
                    lv_signal_data.ul = lv_p_setting->default_value.ul;
                    DebugPrintf("% 16u", lv_signal_data.ul);
                    lv_signal_data.ul = *((Uint32 *)lv_p_setting->define->addr);
                    DebugPrintf("% 16u", lv_signal_data.ul);
                    break;
                }
                case SIGNAL_DATA_TYPE_f:
                {
                    lv_signal_data.f = lv_p_setting->min_value.f;
                    DebugPrintf("% 16.7f", lv_signal_data.f);
                    lv_signal_data.f = lv_p_setting->max_value.f;
                    DebugPrintf("% 16.7f", lv_signal_data.f);
                    lv_signal_data.f = lv_p_setting->default_value.f;
                    DebugPrintf("% 16.7f", lv_signal_data.f);
                    lv_signal_data.f = *((float *)lv_p_setting->define->addr);
                    DebugPrintf("% 16.7f", lv_signal_data.f);
                    break;
                }
                //���ֽڳ��ȶ�ֵ
                default:
                {
                    DebugPrintf("unknow setting type=%d\n\r", lv_p_setting->define->type);
                    return NORMAL_ERROR;
                }
            }
            DebugPrintf("  %-8s\n\r", lv_p_setting->unit);
        }
        lv_index++;
        if (lv_index >= lv_setting_end_addr)
        {
            break;
        }
    }

    if (NORMAL_SUCCESS != CheckRunSettingWithFlash(&setting_system))
    {
        DebugPrintf("========================================================WARNING!!!=================================================================\n\r");
        DebugPrintf("    Setting need to be saved!\n\r");
        DebugPrintf("===================================================================================================================================\n\r");
    }

    return NORMAL_SUCCESS;
}

//----------------------------------------------------------------------------------------------------
//   Function: CommandSave
//      Input: char const *args
//     Output: void
//     Return: int32 :����ִ�����
//Description: ��ֵ�鿴����
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
static int32 CommandSave(char const *args)
{
    if (NORMAL_SUCCESS != SettingWriteToFlash(&setting_system))
    {
        DebugPrintf("setting save failed!\n\r");
        return NORMAL_ERROR;
    }
    else
    {
        if (NORMAL_SUCCESS != CheckRunSettingWithFlash(&setting_system))
        {
            DebugPrintf("setting check failed!\n\r");
            return NORMAL_ERROR;
        }
        else
        {
            DebugPrintf("save setting success!\n\r");
            return NORMAL_SUCCESS;
        }
    }
}
//----------------------------------------------------------------------------------------------------
//   Function: CommandSdramTest
//      Input: char const *args
//     Output: void
//     Return: int32 :����ִ�����
//Description: ��������,��ʾ֧�ֵ�����
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
static int32 CommandDownload(char const *args)
{
    Uint32  i;
    Uint8   lv_xmodem_frame_counter;
    Uint16  lv_debug_rx_buffer_rd_ptr_temp;
    Uint32  lv_nak_counter;
    Uint32  lv_debug_rx_system_ms_count_last_value;
    Uint8   lv_buffer[SELF_BIN_HEADER_LENGTH];
    Uint16  lv_bin_file_type;
    Uint32  lv_bin_file_length;
    Uint32  lv_flash_file_length;
    Uint32  lv_max_file_length;
    Uint32  lv_spi_flash_start_addr;
    Uint32  lv_current_frame_valid_data_length;
    Uint32  lv_bin_file_downloading_data_count;
    Uint8   *lv_p_download_buffer;

    while (debug_rx_buffer_wr_ptr == debug_rx_buffer_rd_ptr)
    {
        DebugPrintf("Enter download mode! Hit any key exit!\r\n");

        debug_tx_buffer[UART_TX_BUF_ADDR(debug_tx_buffer_wr_ptr++)] = NAK;
        lv_nak_counter = 0;
        lv_debug_rx_system_ms_count_last_value = system_ms_count;
        while (debug_rx_buffer_wr_ptr == debug_rx_buffer_rd_ptr)
        {
            if ((system_ms_count - lv_debug_rx_system_ms_count_last_value) >= 1000u)
            {
                lv_debug_rx_system_ms_count_last_value += 1000u;
                debug_tx_buffer[UART_TX_BUF_ADDR(debug_tx_buffer_wr_ptr++)] = NAK;
                lv_nak_counter++;
                if (lv_nak_counter >= 300u)
                {
                    DebugPrintf("Uart receive first download data overtime!\r\n");
                    return NORMAL_ERROR;
                }
            }
        }

        if (SOH != debug_rx_buffer[UART_RX_BUF_ADDR(debug_rx_buffer_rd_ptr)])
        {
            return NORMAL_SUCCESS;
        }

        lv_debug_rx_system_ms_count_last_value = system_ms_count;
        lv_debug_rx_buffer_rd_ptr_temp = debug_rx_buffer_wr_ptr;
        while (UART_RX_BUF_ADDR(debug_rx_buffer_wr_ptr - debug_rx_buffer_rd_ptr) < (SELF_BIN_HEADER_LENGTH + 3u))
        {
            if (lv_debug_rx_buffer_rd_ptr_temp != debug_rx_buffer_wr_ptr)
            {
                lv_debug_rx_buffer_rd_ptr_temp = debug_rx_buffer_wr_ptr;
                lv_debug_rx_system_ms_count_last_value = system_ms_count;
            }
            else
            {
                if ((system_ms_count - lv_debug_rx_system_ms_count_last_value) >= 2000u)
                {
                    DebugPrintf("Uart receive download data header overtime!\r\n");
                    debug_rx_buffer_rd_ptr = debug_rx_buffer_wr_ptr;
                    return NORMAL_ERROR;
                }
            }
        }

        if (    (0x01u != debug_rx_buffer[UART_RX_BUF_ADDR(debug_rx_buffer_rd_ptr + 1)])
             || ((Uint8)(~0x01u) != debug_rx_buffer[UART_RX_BUF_ADDR(debug_rx_buffer_rd_ptr + 2)]))
        {
            DebugPrintf("First frame header error overtime!\r\n");
            debug_rx_buffer_rd_ptr = debug_rx_buffer_wr_ptr;
            return NORMAL_ERROR;
        }

        for (i = 0; i < SELF_BIN_HEADER_LENGTH; i++)
        {
            lv_buffer[i] = debug_rx_buffer[UART_RX_BUF_ADDR(debug_rx_buffer_rd_ptr + 3 + i)];
        }

        if (    ((SELF_BIN_HEADER_LENGTH >> 2u) != lv_buffer[4])
             || (SELF_BIN_VERSION != lv_buffer[5])
             || ((0x01u) != lv_buffer[SELF_BIN_HEADER_LENGTH - 2])
             || ((0xA0u) != lv_buffer[SELF_BIN_HEADER_LENGTH - 1])
             || (0u != DefaultCrcCal(lv_buffer, SELF_BIN_HEADER_LENGTH)))
        {
            DebugPrintf("bin file header check failed!\r\n");
            debug_rx_buffer_rd_ptr = debug_rx_buffer_wr_ptr;
            return NORMAL_ERROR;
        }

        lv_bin_file_length = (lv_buffer[0]) | (lv_buffer[1] << 8) | (lv_buffer[2] << 16) | (lv_buffer[3] << 24);
        lv_flash_file_length = lv_bin_file_length + SELF_BIN_HEADER_LENGTH;
        lv_bin_file_type = (lv_buffer[6]) | (lv_buffer[7] << 8);
        switch (lv_bin_file_type)
        {
            case BIN_FILE_TYPE_DSP_PROGRAM:
            {
                lv_max_file_length = FLASH_APP_LENGTH;
                lv_spi_flash_start_addr = FLASH_APP_START_ADDR;
                break;
            }
            case BIN_FILE_TYPE_FPGA_PROGRAM:
            {
                lv_max_file_length = FLASH_FPGA_LENGTH;
                lv_spi_flash_start_addr = FLASH_FPGA_START_ADDR;
                break;
            }
            case BIN_FILE_TYPE_DEV_CFG:
            {
                lv_max_file_length = FLASH_DEV_CFG_LENGTH;
                lv_spi_flash_start_addr = FLASH_DEV_CFG_START_ADDR;
                break;
            }
            case BIN_FILE_TYPE_PRJ_CFG:
            {
                lv_max_file_length = FLASH_PRJ_CFG_LENGTH;
                lv_spi_flash_start_addr = FLASH_PRJ_CFG_START_ADDR;
                break;
            }
            default:
            {
                DebugPrintf("Unknow file type %u!\r\n", lv_bin_file_type);
                debug_rx_buffer_rd_ptr = debug_rx_buffer_wr_ptr;
                return NORMAL_ERROR;
            }
        }

        if (lv_flash_file_length > lv_max_file_length)
        {
            DebugPrintf("File type %u (length=%lu) > flash max (lenth=%lu)!\r\n", lv_bin_file_type, lv_flash_file_length, lv_max_file_length);
            debug_rx_buffer_rd_ptr = debug_rx_buffer_wr_ptr;
            return NORMAL_ERROR;
        }

        lv_p_download_buffer = malloc(lv_flash_file_length);
        if (NULL == lv_p_download_buffer)
        {
            DebugPrintf("Download buffer malloc failed!\r\n");
            debug_rx_buffer_rd_ptr = debug_rx_buffer_wr_ptr;
            return NORMAL_ERROR;
        }

        user_app_passby_mode = 1;
        lv_xmodem_frame_counter = 1;
        lv_bin_file_downloading_data_count = 0;
        while (lv_bin_file_downloading_data_count < lv_flash_file_length)
        {
            lv_debug_rx_buffer_rd_ptr_temp = debug_rx_buffer_wr_ptr;
            lv_debug_rx_system_ms_count_last_value = system_ms_count;
            while (UART_RX_BUF_ADDR(debug_rx_buffer_wr_ptr - debug_rx_buffer_rd_ptr) < 132u)
            {
                if (lv_debug_rx_buffer_rd_ptr_temp != debug_rx_buffer_wr_ptr)
                {
                    lv_debug_rx_buffer_rd_ptr_temp = debug_rx_buffer_wr_ptr;
                    lv_debug_rx_system_ms_count_last_value = system_ms_count;
                }
                else
                {
                    if ((system_ms_count - lv_debug_rx_system_ms_count_last_value) >= 2000u)
                    {
                        DebugPrintf("File type %u uart receive download data overtime!\r\n", lv_bin_file_type);
                        free(lv_p_download_buffer);
                        debug_rx_buffer_rd_ptr = debug_rx_buffer_wr_ptr;
                        return NORMAL_ERROR;
                    }
                }
            }

            if (    (SOH != debug_rx_buffer[UART_RX_BUF_ADDR(debug_rx_buffer_rd_ptr)])
                 || (lv_xmodem_frame_counter != debug_rx_buffer[UART_RX_BUF_ADDR(debug_rx_buffer_rd_ptr + 1)])
                 || ((Uint8)(~lv_xmodem_frame_counter) != debug_rx_buffer[UART_RX_BUF_ADDR(debug_rx_buffer_rd_ptr + 2)]) )
            {
                DebugPrintf("File type %u frame[%u] header error!\r\n", lv_bin_file_type, lv_xmodem_frame_counter);
                free(lv_p_download_buffer);
                debug_rx_buffer_rd_ptr = debug_rx_buffer_wr_ptr;
                return NORMAL_ERROR;
            }
            lv_xmodem_frame_counter++;

            debug_rx_buffer_rd_ptr += 3;
            if ((lv_flash_file_length - lv_bin_file_downloading_data_count) < 128u)
            {
                lv_current_frame_valid_data_length = lv_flash_file_length - lv_bin_file_downloading_data_count;
            }
            else
            {
                lv_current_frame_valid_data_length = 128u;
            }
            for (i = 0; i < lv_current_frame_valid_data_length; i++)
            {
                lv_p_download_buffer[lv_bin_file_downloading_data_count++] = debug_rx_buffer[UART_RX_BUF_ADDR(debug_rx_buffer_rd_ptr + i)];
            }
            debug_rx_buffer_rd_ptr += 129u;
            debug_tx_buffer[UART_TX_BUF_ADDR(debug_tx_buffer_wr_ptr++)] = ACK;
        }

        lv_debug_rx_system_ms_count_last_value = system_ms_count;
        while (debug_rx_buffer_wr_ptr == debug_rx_buffer_rd_ptr)
        {
            if ((system_ms_count - lv_debug_rx_system_ms_count_last_value) >= 2000u)
            {
                DebugPrintf("File type %u confirm frame receive overtime!\r\n", lv_bin_file_type);
                free(lv_p_download_buffer);
                return NORMAL_ERROR;
            }
        }

        if (EOT != debug_rx_buffer[UART_RX_BUF_ADDR(debug_rx_buffer_rd_ptr++)])
        {
            DebugPrintf("File type %u confirm frame error!\r\n", lv_bin_file_type);
            free(lv_p_download_buffer);
            return NORMAL_ERROR;
        }

        debug_tx_buffer[UART_TX_BUF_ADDR(debug_tx_buffer_wr_ptr++)] = ACK;
        if (0 != DefaultCrcCal(&lv_p_download_buffer[SELF_BIN_HEADER_LENGTH], lv_bin_file_length))
        {
            DebugPrintf("File type %u crc check!\r\n", lv_bin_file_type);
            free(lv_p_download_buffer);
            debug_rx_buffer_rd_ptr = debug_rx_buffer_wr_ptr;
            return NORMAL_ERROR;
        }

        DebugPrintf("\r\n\r\nErasing and writing spi flash now, please don't poweroff!\r\n");
        if (1 == lv_bin_file_type)
        {
            WinbondW25BlockErase(lv_spi_flash_start_addr, ((lv_bin_file_length + WINBOND_W25_BLOCK_SIZE - 1) / WINBOND_W25_BLOCK_SIZE) * WINBOND_W25_BLOCK_SIZE);
            WinbondW25BlockErase((FLASH_APP_END_ADDR - FLASH_APP_END_ADDR % WINBOND_W25_BLOCK_SIZE), WINBOND_W25_BLOCK_SIZE);
            WinbondW25PageWrite(lv_spi_flash_start_addr,  lv_bin_file_length , &lv_p_download_buffer[SELF_BIN_HEADER_LENGTH]);
            WinbondW25PageWrite((FLASH_APP_END_ADDR + 1 - SELF_BIN_HEADER_LENGTH),  SELF_BIN_HEADER_LENGTH , lv_p_download_buffer);
        }
        else
        {
            WinbondW25BlockErase(lv_spi_flash_start_addr, ((lv_flash_file_length + WINBOND_W25_BLOCK_SIZE - 1) / WINBOND_W25_BLOCK_SIZE) * WINBOND_W25_BLOCK_SIZE);
            WinbondW25PageWrite(lv_spi_flash_start_addr,  lv_flash_file_length , lv_p_download_buffer);
        }

        free(lv_p_download_buffer);

        DebugPrintf("File type 0x%04X download success, please reboot the device!\r\n", lv_bin_file_type);
    }
    return NORMAL_SUCCESS;
}

//----------------------------------------------------------------------------------------------------
//   Function: CommandReboot
//      Input: char const *args
//     Output: void
//     Return: int32 :����ִ�����
//Description: ��������
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
static int32 CommandReboot(char const *args)
{
    DisableWatchDog();
    return NORMAL_SUCCESS;
}

//----------------------------------------------------------------------------------------------------
//   Function: CommandHelp
//      Input: char const *args
//     Output: void
//     Return: int32 :����ִ�����
//Description: ��������,��ʾ֧�ֵ�����
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
static int32 CommandHelp(char const *args)
{
    int32 i;

    DebugPrintf("Device support command is:\r\n");
    for (i = 0; i < command_function_define_num; i++)
    {
        DebugPrintf("    %-10s  %s\r\n", command_function_define[i].p_command_string, command_function_define[i].help);
    }

    return NORMAL_SUCCESS;
}


