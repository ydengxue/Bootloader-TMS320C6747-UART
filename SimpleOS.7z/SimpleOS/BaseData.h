/*****************************************************************************************************
* FileName:                    BaseData.h
*
* Description:                 �������ݽṹͷ�ļ�
*
* Author:                      YanDengxue, Fiberhome-Fuhua
*
* Rev History:
*       <Author>        <Data>        <Hardware>     <Version>        <Description>
*     YanDengxue   2011-03-29 15:30       --           1.00             Create
*****************************************************************************************************/
#ifndef _Base_Data_H
#define _Base_Data_H

#ifdef __cplusplus
extern "C" {
#endif

//====================================================================================================
// enum����
//====================================================================================================
typedef enum
{
    SIGNAL_DATA_TYPE_b   = 0,
    SIGNAL_DATA_TYPE_c   = 1,
    SIGNAL_DATA_TYPE_uc  = 2,
    SIGNAL_DATA_TYPE_i   = 3,
    SIGNAL_DATA_TYPE_ui  = 4,
    SIGNAL_DATA_TYPE_l   = 5,
    SIGNAL_DATA_TYPE_ul  = 6,
    SIGNAL_DATA_TYPE_ll  = 7,
    SIGNAL_DATA_TYPE_ull = 8,
    SIGNAL_DATA_TYPE_f   = 9,
    SIGNAL_DATA_TYPE_lf  = 10,
    SIGNAL_DATA_TYPE_n   = 11,
    SIGNAL_DATA_TYPE_s   = 12,
    SIGNAL_DATA_TYPE_v   = 13
} SIGNAL_DATA_TYPE;

typedef enum
{
    PROJECT_DATA_TYPE_BOOLEAN    = 0,
    PROJECT_DATA_TYPE_DBPOS      = 1,
    PROJECT_DATA_TYPE_INT32      = 2,
    PROJECT_DATA_TYPE_UINT32     = 3,
    PROJECT_DATA_TYPE_ENTRYTIME  = 4,
    PROJECT_DATA_TYPE_TIMESTAMP  = 5,
    PROJECT_DATA_TYPE_QUALITY    = 6,
    PROJECT_DATA_TYPE_FLOAT      = 7
} PROJECT_DATA_TYPE;

//====================================================================================================
// �ṹ����
//====================================================================================================
typedef struct
{
    char   const *name;
    void   *addr;// ��ַ
    SIGNAL_DATA_TYPE  type;
} SIGNAL_DEFINE;

typedef struct
{
    char   const *name;
    PROJECT_DATA_TYPE  type;
} PROJECT_TYPE_DEFINE;

typedef union
{
    Uint8  uc;
    int8   c;
    Uint16 ui;
    int16  i;
    Uint32 ul;
    int32  l;
    float  f;
    char const *str;
} SIGNAL_DATA;

typedef struct
{
    PROJECT_TYPE_DEFINE const *prj_type_define;
    SIGNAL_DEFINE const *define;
    SIGNAL_DATA last_value;
} SIGNAL_OUT;

#ifdef __cplusplus
}
#endif

#endif

