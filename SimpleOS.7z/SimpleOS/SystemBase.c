/*****************************************************************************************************
* FileName:                    SystemBase.c
*
* Description:                 ϵͳ���û�������
*
* Author:                      YanDengxue, Fiberhome-Fuhua
*
* Rev History:
*       <Author>        <Data>        <Hardware>     <Version>        <Description>
*     YanDengxue   2011-03-29 15:30       --           1.00             Create
*****************************************************************************************************/
//====================================================================================================
// ���ļ�ʹ�õ�ͷ�ļ�
//====================================================================================================
// ��ͷ�ļ�
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

// �Զ���ͷ�ļ�
#include "UserTypesDef.h"
#include "C6747Register.h"
#include "SystemBase.h"
#include "BaseData.h"
#include "Iconv.h"
#include "ParseConfig.h"
#include "SettingManage.h"
#include "SpiFlash.h"
#include "ProjectDataHandle.h"
#include "NormalServices.h"
#include "HmiCommunication.h"
#include "Debug.h"

//====================================================================================================
// ���س�������
//====================================================================================================
// PPS��ʱ��ض���
#define PPS_HOLD_WIDTH_BUFFER_NUM         8192u
#define PPS_HOLD_WIDTH_BUFFER_MASK        (PPS_HOLD_WIDTH_BUFFER_NUM - 1u)
#define PPS_HOLD_WIDTH_BUFFER_ADDR(addr)  ((Uint16)((addr) & (PPS_HOLD_WIDTH_BUFFER_MASK)))// DSP�����FPGA����֡��Ч��ַ

// ������ض���
#define DAYS_OF_400_YEAR      146097u
#define DAYS_OF_100_YEAR      36524u
#define DAYS_OF_100_LEAP_YEAR 36525u
#define DAYS_OF_4_YEAR        1460u
#define DAYS_OF_4_LEAP_YEAR   1461u
#define DAYS_OF_LEAP_YEAR     366u
#define DAYS_OF_YEAR          365u

// ��ʱ����ض���
#define TIMER0B12_PERIOD        0xFFFFFFFFu

#define TIMER0B34_PERDIV          1u
#define TIMER0B34_FREQ            20000u
#define TIMER0B34_PERIOD          (OSCIN / (TIMER0B34_PERDIV + 1u) / TIMER0B34_FREQ - 1u)

// ��ʱ���ж���ض���
#define PRIORITY_TIMER0B34_INTERRUPT     11u
#define ENABLE_INTERRUPT_TIMER0B34       (IER |= (1u << PRIORITY_TIMER0B34_INTERRUPT))
#define DISABLE_INTERRUPT_TIMER0B34      (IER &= (~(1u << PRIORITY_TIMER0B34_INTERRUPT)))
#define CLR_INTERRUPT_FLAG_TIMER0B34     (ICR = (1u << PRIORITY_TIMER0B34_INTERRUPT))

// Other
#define USER_FAST_BUFFER_LENGTH 0x8000

//====================================================================================================
// ���غ�������,�˴������ĺ��������ⲿ�ӿ�
//====================================================================================================
static int32 ParseGooseTx(int32 *p_addr, int32 end_addr, int32 *p_line_count);
static int32 ParseSvTx(int32 *p_addr, int32 end_addr, int32 *p_line_count);
static int32 Timer0Initial(void);
static void Timer0InterruptService(void);
static void DefaultInterruptService(void);

//====================================================================================================
// ���ļ���������ⲿ�Ľӿڱ���
//====================================================================================================
SYSTEM_CFG   sys_cfg;
Uint8 buffer_public[BUFFER_PUBLIC_LENGTH];

#pragma DATA_SECTION(fpga_rx_data, ".fardata.l2data")
Uint16 fpga_rx_data[FPGA_RX_FRAME_NUM][FPGA_RX_DATA_NUM];

#pragma DATA_SECTION(fpga_tx_data, ".fardata.l2data")
Uint16 fpga_tx_data[FPGA_TX_DATA_NUM];

Uint16 const const_default_crc_tab[256] =
{
    0x0000, 0xC0C1, 0xC181, 0x0140, 0xC301, 0x03C0, 0x0280, 0xC241,
    0xC601, 0x06C0, 0x0780, 0xC741, 0x0500, 0xC5C1, 0xC481, 0x0440,
    0xCC01, 0x0CC0, 0x0D80, 0xCD41, 0x0F00, 0xCFC1, 0xCE81, 0x0E40,
    0x0A00, 0xCAC1, 0xCB81, 0x0B40, 0xC901, 0x09C0, 0x0880, 0xC841,
    0xD801, 0x18C0, 0x1980, 0xD941, 0x1B00, 0xDBC1, 0xDA81, 0x1A40,
    0x1E00, 0xDEC1, 0xDF81, 0x1F40, 0xDD01, 0x1DC0, 0x1C80, 0xDC41,
    0x1400, 0xD4C1, 0xD581, 0x1540, 0xD701, 0x17C0, 0x1680, 0xD641,
    0xD201, 0x12C0, 0x1380, 0xD341, 0x1100, 0xD1C1, 0xD081, 0x1040,
    0xF001, 0x30C0, 0x3180, 0xF141, 0x3300, 0xF3C1, 0xF281, 0x3240,
    0x3600, 0xF6C1, 0xF781, 0x3740, 0xF501, 0x35C0, 0x3480, 0xF441,
    0x3C00, 0xFCC1, 0xFD81, 0x3D40, 0xFF01, 0x3FC0, 0x3E80, 0xFE41,
    0xFA01, 0x3AC0, 0x3B80, 0xFB41, 0x3900, 0xF9C1, 0xF881, 0x3840,
    0x2800, 0xE8C1, 0xE981, 0x2940, 0xEB01, 0x2BC0, 0x2A80, 0xEA41,
    0xEE01, 0x2EC0, 0x2F80, 0xEF41, 0x2D00, 0xEDC1, 0xEC81, 0x2C40,
    0xE401, 0x24C0, 0x2580, 0xE541, 0x2700, 0xE7C1, 0xE681, 0x2640,
    0x2200, 0xE2C1, 0xE381, 0x2340, 0xE101, 0x21C0, 0x2080, 0xE041,
    0xA001, 0x60C0, 0x6180, 0xA141, 0x6300, 0xA3C1, 0xA281, 0x6240,
    0x6600, 0xA6C1, 0xA781, 0x6740, 0xA501, 0x65C0, 0x6480, 0xA441,
    0x6C00, 0xACC1, 0xAD81, 0x6D40, 0xAF01, 0x6FC0, 0x6E80, 0xAE41,
    0xAA01, 0x6AC0, 0x6B80, 0xAB41, 0x6900, 0xA9C1, 0xA881, 0x6840,
    0x7800, 0xB8C1, 0xB981, 0x7940, 0xBB01, 0x7BC0, 0x7A80, 0xBA41,
    0xBE01, 0x7EC0, 0x7F80, 0xBF41, 0x7D00, 0xBDC1, 0xBC81, 0x7C40,
    0xB401, 0x74C0, 0x7580, 0xB541, 0x7700, 0xB7C1, 0xB681, 0x7640,
    0x7200, 0xB2C1, 0xB381, 0x7340, 0xB101, 0x71C0, 0x7080, 0xB041,
    0x5000, 0x90C1, 0x9181, 0x5140, 0x9301, 0x53C0, 0x5280, 0x9241,
    0x9601, 0x56C0, 0x5780, 0x9741, 0x5500, 0x95C1, 0x9481, 0x5440,
    0x9C01, 0x5CC0, 0x5D80, 0x9D41, 0x5F00, 0x9FC1, 0x9E81, 0x5E40,
    0x5A00, 0x9AC1, 0x9B81, 0x5B40, 0x9901, 0x59C0, 0x5880, 0x9841,
    0x8801, 0x48C0, 0x4980, 0x8941, 0x4B00, 0x8BC1, 0x8A81, 0x4A40,
    0x4E00, 0x8EC1, 0x8F81, 0x4F40, 0x8D01, 0x4DC0, 0x4C80, 0x8C41,
    0x4400, 0x84C1, 0x8581, 0x4540, 0x8701, 0x47C0, 0x4680, 0x8641,
    0x8201, 0x42C0, 0x4380, 0x8341, 0x4100, 0x81C1, 0x8081, 0x4040
};

//====================================================================================================
// ����ȫ�ֱ���
//====================================================================================================
// �ж�������
// create by YanDengxue 2011-04-20 10:00
#pragma DATA_ALIGN(intc_vector_table, 1024 )
#pragma DATA_SECTION(intc_vector_table, ".text:vecs")
static Uint32 intc_vector_table[] =
{
    0x003C30F6,  0x0000002A, 0x0000006A, 0x00000362, 0x003C36E6,  0x0C6E2C6E, 0x00000000, 0xE4000000,
    0x003C30F6,  0x0000002A, 0x0000006A, 0x00000362, 0x003C36E6,  0x0C6E2C6E, 0x00000000, 0xE4000000,
    0x003C30F6,  0x0000002A, 0x0000006A, 0x00000362, 0x003C36E6,  0x0C6E2C6E, 0x00000000, 0xE4000000,
    0x003C30F6,  0x0000002A, 0x0000006A, 0x00000362, 0x003C36E6,  0x0C6E2C6E, 0x00000000, 0xE4000000,
    0x003C30F6,  0x0000002A, 0x0000006A, 0x00000362, 0x003C36E6,  0x0C6E2C6E, 0x00000000, 0xE4000000,
    0x003C30F6,  0x0000002A, 0x0000006A, 0x00000362, 0x003C36E6,  0x0C6E2C6E, 0x00000000, 0xE4000000,
    0x003C30F6,  0x0000002A, 0x0000006A, 0x00000362, 0x003C36E6,  0x0C6E2C6E, 0x00000000, 0xE4000000,
    0x003C30F6,  0x0000002A, 0x0000006A, 0x00000362, 0x003C36E6,  0x0C6E2C6E, 0x00000000, 0xE4000000,
    0x003C30F6,  0x0000002A, 0x0000006A, 0x00000362, 0x003C36E6,  0x0C6E2C6E, 0x00000000, 0xE4000000,
    0x003C30F6,  0x0000002A, 0x0000006A, 0x00000362, 0x003C36E6,  0x0C6E2C6E, 0x00000000, 0xE4000000,
    0x003C30F6,  0x0000002A, 0x0000006A, 0x00000362, 0x003C36E6,  0x0C6E2C6E, 0x00000000, 0xE4000000,
    0x003C30F6,  0x0000002A, 0x0000006A, 0x00000362, 0x003C36E6,  0x0C6E2C6E, 0x00000000, 0xE4000000,
    0x003C30F6,  0x0000002A, 0x0000006A, 0x00000362, 0x003C36E6,  0x0C6E2C6E, 0x00000000, 0xE4000000,
    0x003C30F6,  0x0000002A, 0x0000006A, 0x00000362, 0x003C36E6,  0x0C6E2C6E, 0x00000000, 0xE4000000,
    0x003C30F6,  0x0000002A, 0x0000006A, 0x00000362, 0x003C36E6,  0x0C6E2C6E, 0x00000000, 0xE4000000,
    0x003C30F6,  0x0015502A, 0x0000006A, 0x00000362, 0x003C36E6,  0x0C6E2C6E, 0x00000000, 0xE4000000
};

static Uint32 const days_of_year_per_400[401] =
{
         0u,    366u,    731u,   1096u,   1461u,   1827u,   2192u,   2557u,
      2922u,   3288u,   3653u,   4018u,   4383u,   4749u,   5114u,   5479u,
      5844u,   6210u,   6575u,   6940u,   7305u,   7671u,   8036u,   8401u,
      8766u,   9132u,   9497u,   9862u,  10227u,  10593u,  10958u,  11323u,
     11688u,  12054u,  12419u,  12784u,  13149u,  13515u,  13880u,  14245u,
     14610u,  14976u,  15341u,  15706u,  16071u,  16437u,  16802u,  17167u,
     17532u,  17898u,  18263u,  18628u,  18993u,  19359u,  19724u,  20089u,
     20454u,  20820u,  21185u,  21550u,  21915u,  22281u,  22646u,  23011u,
     23376u,  23742u,  24107u,  24472u,  24837u,  25203u,  25568u,  25933u,
     26298u,  26664u,  27029u,  27394u,  27759u,  28125u,  28490u,  28855u,
     29220u,  29586u,  29951u,  30316u,  30681u,  31047u,  31412u,  31777u,
     32142u,  32508u,  32873u,  33238u,  33603u,  33969u,  34334u,  34699u,
     35064u,  35430u,  35795u,  36160u,  36525u,  36890u,  37255u,  37620u,
     37985u,  38351u,  38716u,  39081u,  39446u,  39812u,  40177u,  40542u,
     40907u,  41273u,  41638u,  42003u,  42368u,  42734u,  43099u,  43464u,
     43829u,  44195u,  44560u,  44925u,  45290u,  45656u,  46021u,  46386u,
     46751u,  47117u,  47482u,  47847u,  48212u,  48578u,  48943u,  49308u,
     49673u,  50039u,  50404u,  50769u,  51134u,  51500u,  51865u,  52230u,
     52595u,  52961u,  53326u,  53691u,  54056u,  54422u,  54787u,  55152u,
     55517u,  55883u,  56248u,  56613u,  56978u,  57344u,  57709u,  58074u,
     58439u,  58805u,  59170u,  59535u,  59900u,  60266u,  60631u,  60996u,
     61361u,  61727u,  62092u,  62457u,  62822u,  63188u,  63553u,  63918u,
     64283u,  64649u,  65014u,  65379u,  65744u,  66110u,  66475u,  66840u,
     67205u,  67571u,  67936u,  68301u,  68666u,  69032u,  69397u,  69762u,
     70127u,  70493u,  70858u,  71223u,  71588u,  71954u,  72319u,  72684u,
     73049u,  73414u,  73779u,  74144u,  74509u,  74875u,  75240u,  75605u,
     75970u,  76336u,  76701u,  77066u,  77431u,  77797u,  78162u,  78527u,
     78892u,  79258u,  79623u,  79988u,  80353u,  80719u,  81084u,  81449u,
     81814u,  82180u,  82545u,  82910u,  83275u,  83641u,  84006u,  84371u,
     84736u,  85102u,  85467u,  85832u,  86197u,  86563u,  86928u,  87293u,
     87658u,  88024u,  88389u,  88754u,  89119u,  89485u,  89850u,  90215u,
     90580u,  90946u,  91311u,  91676u,  92041u,  92407u,  92772u,  93137u,
     93502u,  93868u,  94233u,  94598u,  94963u,  95329u,  95694u,  96059u,
     96424u,  96790u,  97155u,  97520u,  97885u,  98251u,  98616u,  98981u,
     99346u,  99712u, 100077u, 100442u, 100807u, 101173u, 101538u, 101903u,
    102268u, 102634u, 102999u, 103364u, 103729u, 104095u, 104460u, 104825u,
    105190u, 105556u, 105921u, 106286u, 106651u, 107017u, 107382u, 107747u,
    108112u, 108478u, 108843u, 109208u, 109573u, 109938u, 110303u, 110668u,
    111033u, 111399u, 111764u, 112129u, 112494u, 112860u, 113225u, 113590u,
    113955u, 114321u, 114686u, 115051u, 115416u, 115782u, 116147u, 116512u,
    116877u, 117243u, 117608u, 117973u, 118338u, 118704u, 119069u, 119434u,
    119799u, 120165u, 120530u, 120895u, 121260u, 121626u, 121991u, 122356u,
    122721u, 123087u, 123452u, 123817u, 124182u, 124548u, 124913u, 125278u,
    125643u, 126009u, 126374u, 126739u, 127104u, 127470u, 127835u, 128200u,
    128565u, 128931u, 129296u, 129661u, 130026u, 130392u, 130757u, 131122u,
    131487u, 131853u, 132218u, 132583u, 132948u, 133314u, 133679u, 134044u,
    134409u, 134775u, 135140u, 135505u, 135870u, 136236u, 136601u, 136966u,
    137331u, 137697u, 138062u, 138427u, 138792u, 139158u, 139523u, 139888u,
    140253u, 140619u, 140984u, 141349u, 141714u, 142080u, 142445u, 142810u,
    143175u, 143541u, 143906u, 144271u, 144636u, 145002u, 145367u, 145732u,
    146097u,
};

static Uint16 const days_of_month_year[2][13] =
{
    {
        0u, 31u, 59u, 90u, 120u, 151u, 181u, 212u, 243u, 273u, 304u, 334u, 365u
    },
    {
        0u, 31u, 60u, 91u, 121u, 152u, 182u, 213u, 244u, 274u, 305u, 335u, 366u
    }
};

static Uint16 const leep_year_flag_of_400_year[25] =
{
    0x1111u, 0x1111u, 0x1111u, 0x1111u, 0x1111u,
    0x1111u, 0x1101u, 0x1111u, 0x1111u, 0x1111u,
    0x1111u, 0x1111u, 0x1011u, 0x1111u, 0x1111u,
    0x1111u, 0x1111u, 0x1111u, 0x0111u, 0x1111u,
    0x1111u, 0x1111u, 0x1111u, 0x1111u, 0x1111u,
};

static SIGNAL_DEFINE const default_setting_system_define[] =
{
    {"language",   &sys_cfg.language,  SIGNAL_DATA_TYPE_uc},
};
static int32 const default_setting_system_define_num = sizeof(default_setting_system_define) / sizeof(default_setting_system_define[0]);

static int8 const utf8_bom[]  = {0xEF, 0xBB, 0xBF};

#pragma DATA_SECTION(user_fast_buffer, ".fardata.l2data")
static char user_fast_buffer[USER_FAST_BUFFER_LENGTH];
static char const *user_fast_buffer_free_addr = user_fast_buffer;

static Uint32 pps_hold_width[PPS_HOLD_WIDTH_BUFFER_NUM];
static Uint16 pps_hold_width_buffer_num = 0;
static Uint16 pps_hold_width_buffer_addr = 0;
static Uint16 pps_lose_cnt = 0;
static int8   pps_hold_flag = 0;

//====================================================================================================
// ����ʵ��
//====================================================================================================
//----------------------------------------------------------------------------------------------------
// �ӿں���
//----------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------
//   Function: FpgaSlaveSerialOutput
//      Input: Uint8 const *fpga_grogram : FPGA�����׵�ַ
//             Uint32 fpga_program_lenth : FPGA���򳤶�
//             VUint32 *fpga_init_b_addr, Uint32 fpga_init_b_mask : FPGA INIT_B����
//             VUint32 *fpga_done_addr, Uint32 fpga_done_mask : FPGA DONE����
//             VUint32 *fpga_cclk_addr, Uint32 fpga_cclk_mask : FPGA CCLK����
//             VUint32 *fpga_din_addr, Uint32 fpga_din_mask : FPGA DIN����
//             VUint32 *fpga_prog_b_addr, Uint32 fpga_prog_b_mask: FPGA PROG_B����
//     Output: void
//     Return: int32: ����ִ�����
//Description: Fpga
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
int32 FpgaSlaveSerialOutput(   Uint8 const *fpga_grogram, Uint32 fpga_program_lenth
                             , VUint32 *fpga_init_b_addr, Uint32 fpga_init_b_mask
                             , VUint32 *fpga_done_addr,   Uint32 fpga_done_mask
                             , VUint32 *fpga_cclk_addr,   Uint32 fpga_cclk_mask
                             , VUint32 *fpga_din_addr,    Uint32 fpga_din_mask
                             , VUint32 *fpga_prog_b_addr, Uint32 fpga_prog_b_mask)
{
#define FPGA_INIT_B    (*fpga_init_b_addr &  (fpga_init_b_mask))
#define FPGA_DONE      (*fpga_done_addr   &  (fpga_done_mask))
#define FPGA_CCLK_H    (*fpga_cclk_addr   |= (fpga_cclk_mask))
#define FPGA_CCLK_L    (*fpga_cclk_addr   &= (~(fpga_cclk_mask)))
#define FPGA_DIN_H     (*fpga_din_addr    |= (fpga_din_mask))
#define FPGA_DIN_L     (*fpga_din_addr    &= (~(fpga_din_mask)))
#define FPGA_PROG_B_H  (*fpga_prog_b_addr |= (fpga_prog_b_mask))
#define FPGA_PROG_B_L  (*fpga_prog_b_addr &= (~(fpga_prog_b_mask)))

    Uint32 i;       
    Uint32 lv_delay_count;
    Uint32 lv_byte_index;
    Uint32 lv_bit_index;
    Uint32 lv_extra_cclk;
    Uint8  lv_uchar_temp;

    if (    (NULL == fpga_grogram)   || (NULL == fpga_prog_b_addr)
         || (NULL == fpga_done_addr) || (NULL == fpga_init_b_addr)
         || (NULL == fpga_cclk_addr) || (NULL == fpga_din_addr))
    {
        TRACE("function entries error");
        return NORMAL_ERROR;
    }

    if ((0 == fpga_program_lenth) || (fpga_program_lenth > 0x80000000u))
    {
        TRACE("fpga_program_lenth=%u exceed scope (0,0x80000000u]!", fpga_program_lenth);
        return NORMAL_ERROR;
    }

    FPGA_CCLK_H;

    FPGA_PROG_B_L;

    lv_delay_count = 1000000u;
    while ((0 != FPGA_INIT_B) || (0 != FPGA_DONE))// wait STATUS low
    {
        lv_delay_count--;
        if (0 == lv_delay_count)
        {
            TRACE("fpga INIT_B or DONE low detect overtime!");
            return NORMAL_ERROR;
        }
    }

    FPGA_PROG_B_H;

    DelayLoop(10000);

    lv_delay_count = 1000000u;
    while (0 == FPGA_INIT_B)// wait STATUS hight
    {
        lv_delay_count--;
        if (0 == lv_delay_count)
        {
            TRACE("INIT_B high detect overtime!");
            return NORMAL_ERROR;
        }
    }

    DelayLoop(10000);

    for (lv_byte_index = 0; lv_byte_index < fpga_program_lenth; lv_byte_index++)
    {
        lv_uchar_temp = fpga_grogram[lv_byte_index];
        for (lv_bit_index = 0; lv_bit_index < 8; lv_bit_index++)
        {
            DelayLoop(1);
            FPGA_CCLK_L;
            if (0 != ((lv_uchar_temp >> (7 - lv_bit_index)) & 0x01))
            {
                FPGA_DIN_H;
            }
            else
            {
                FPGA_DIN_L;
            }

            DelayLoop(1);
            FPGA_CCLK_H;

            if (0 != FPGA_DONE)
            {
                break;
            }

            if (0 == FPGA_INIT_B)
            {
                TRACE("Fpga byte[%u] bit[%u] download error, INIT_B goto low!", lv_byte_index, lv_bit_index);
                return NORMAL_ERROR;
            }
        }
    }

    FPGA_DIN_H;
    lv_delay_count = 1000000u;
    while (0 == FPGA_DONE)// wait CONFIG_DONE high
    {
        if (0 == FPGA_INIT_B)
        {
            TRACE("Fpga download error, INIT_B goto low!");
            return NORMAL_ERROR;
        }

        DelayLoop(1);
        FPGA_CCLK_L;

        DelayLoop(1);
        FPGA_CCLK_H;

        lv_delay_count--;
        if (0 == lv_delay_count)
        {
            TRACE("FPGA_DONE high detect overtime!");
            return NORMAL_ERROR;
        }
    }

    lv_extra_cclk = (fpga_program_lenth - lv_byte_index) << 3u;
    if (lv_extra_cclk < 16u)
    {
        lv_extra_cclk = 16u;
    }

    for (i = 0; i < lv_extra_cclk; i++)
    {
        DelayLoop(1);
        FPGA_CCLK_L;

        DelayLoop(1);
        FPGA_CCLK_H;
    }

    return NORMAL_SUCCESS;
}

//----------------------------------------------------------------------------------------------------
//   Function: InterruptVectorsInitial
//      Input: void
//     Output: void
//     Return: int32: ����ִ�����
//Description: �ж���������ʼ��
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
int32 InterruptVectorsInitial(void)
{
    int32 i;
    Uint32 lv_temp_ulong;

    lv_temp_ulong = (Uint32)DefaultInterruptService;
    for (i = 0; i < 16; i++)
    {
        intc_vector_table[(i << 3) + 1] |= (LSHW(lv_temp_ulong) << 7);
        intc_vector_table[(i << 3) + 2] |= (HSHW(lv_temp_ulong) << 7);
    }
    ISTP = (unsigned int)intc_vector_table;
    ICR  = 0xFFF0;// clear all interrupts, bits 4 thru 15
    IER  = 0x0002;// enable the bits for non maskable interrupt
    _enable_interrupts();// enable interrupts, set GIE bit

    InterruptRegister(Timer0InterruptService, PRIORITY_TIMER0B34_INTERRUPT, 64u, INTERRUPT_DISABLE);
    InterruptRegister(HmiCommunicationInterruptService, PRIORITY_COMMUNICATION_INTERRUPT, 38u, INTERRUPT_DISABLE);
    if (NORMAL_SUCCESS != Timer0Initial())
    {
        TRACE("Timer0 initial failed!");
        return NORMAL_ERROR;
    }

    CLR_INTERRUPT_FLAG_TIMER0B34;
    ENABLE_INTERRUPT_TIMER0B34;

    pTIMER0->TCR |= ((2 << 6) | (2 << 22));

    return NORMAL_SUCCESS;
}

//----------------------------------------------------------------------------------------------------
//   Function: InterruptRegister
//      Input: INTERRUPT_FUNCTION interrupt_function: �жϷ������
//             Uint8 priority: ���ȼ�
//             Uint8 interrupt_src_num: �ж�Դ
//             int8 interrupt_enable_flag: CPU�ж��Ƿ�ʹ�ܱ�ʶ
//     Output: void
//     Return: int32: ����ִ�����
//Description: �ж�����ע�ắ��
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
int32 InterruptRegister(void *interrupt_function, Uint8 priority, Uint8 interrupt_src_num, int8 interrupt_enable_flag)
{
    Uint32 lv_temp_ulong;
    Uint32 lv_index_function_hi;
    Uint32 lv_index_function_lo;

    if ((priority > 15) || (priority < 4))
    {
        TRACE("Interrupt register failed! Interrupt priority must greater than 3 and less than 16, but here is %d", priority);
        return NORMAL_ERROR;
    }

    if (interrupt_src_num > 127)
    {
        TRACE("Interrupt register failed! Interrupt source num must less 128, but here is %d", interrupt_src_num);
        return NORMAL_ERROR;
    }

    IER &= (~(1 << priority));// disenable the bits for non maskable interrupt

    lv_index_function_hi = (priority << 3) + 1;
    lv_index_function_lo = lv_index_function_hi + 1;
    intc_vector_table[lv_index_function_hi] &= (~(0xffff << 7));
    intc_vector_table[lv_index_function_lo] &= (~(0xffff << 7));

    if (NULL != interrupt_function)
    {
        lv_temp_ulong = (Uint32)interrupt_function;
    }
    else
    {
        lv_temp_ulong = (Uint32)DefaultInterruptService;
    }
    intc_vector_table[lv_index_function_hi] |= (LSHW(lv_temp_ulong) << 7);
    intc_vector_table[lv_index_function_lo] |= (HSHW(lv_temp_ulong) << 7);

    if (priority < 8)
    {
        pINTC->INTMUX1 &= (~(0x7F << ((priority - 4) << 3)));
        pINTC->INTMUX1 |= (interrupt_src_num << ((priority - 4) << 3));
    }
    else if (priority < 12)
    {
        pINTC->INTMUX2 &= (~(0x7F << ((priority - 8) << 3)));
        pINTC->INTMUX2 |= (interrupt_src_num << ((priority - 8) << 3));
    }
    else
    {
        pINTC->INTMUX3 &= (~(0x7F << ((priority - 12) << 3)));
        pINTC->INTMUX3 |= (interrupt_src_num << ((priority - 12) << 3));
    }

    ICR = (1 << priority);// clear the bits for non maskable interrupt
    if (0 != interrupt_enable_flag)
    {
        IER |= (1 << priority);// enable the bits for non maskable interrupt
    }

    return NORMAL_SUCCESS;
}

//----------------------------------------------------------------------------------------------------
//   Function: DefaultCrcCal
//      Input: Uint16 crc_in: CRC��ʼֵ
//             Uint8 const *ptr: ������CRC�ֽ����׵�ַ
//             Uint16 length: ������CRC�ֽ�������
//     Output: void
//     Return: Uint16: CRC������
//Description: ϵͳȱʡcrc����
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
Uint16 DefaultCrcCal(Uint8 const *src, int32 length)
{
    int32  lv_index;
    Uint16 lv_crc;
    Uint8  lv_crc_index;

    lv_crc = 0xffff;
    for (lv_index = 0; lv_index < length; lv_index++)
    {
        lv_crc_index = (lv_crc & 0xff) ^ src[lv_index];
        lv_crc = const_default_crc_tab[lv_crc_index] ^ ((lv_crc >> 8) & 0xff);
    }

    return lv_crc;
}

//----------------------------------------------------------------------------------------------------
//   Function: CheckLocalTimeValid
//      Input: LOCAL_TIME const *local_time
//     Output: void
//     Return: int32: ����ִ�����
//Description: ���local_time�Ƿ���ȷ
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
int32 CheckLocalTimeValid(LOCAL_TIME const *local_time)
{
    Uint16 lv_year_in_400;
    Uint8  lv_leap_year_flag;
    Uint8  lv_day_month_max;

    if (NULL == local_time)
    {
        TRACE("function entry error");
        return NORMAL_ERROR;
    }

    if (    (local_time->msecond > 999u) || (local_time->second > 59u)
         || (local_time->minute > 59u)   || (local_time->hour > 23u)
         || (local_time->month < 1u)     || (local_time->month > 12u)
         || (local_time->year < 2000u))
    {
        return NORMAL_ERROR;
    }

    lv_year_in_400 = (local_time->year - 2000u) % 400;
    lv_leap_year_flag = ((leep_year_flag_of_400_year[lv_year_in_400 >> 4] >> (lv_year_in_400 & 0xf)) & 1);

    lv_day_month_max = days_of_month_year[lv_leap_year_flag][local_time->month] - days_of_month_year[lv_leap_year_flag][local_time->month - 1];
    if ((local_time->day < 1u) || (local_time->day > lv_day_month_max))
    {
        return NORMAL_ERROR;
    }


    return NORMAL_SUCCESS;
}

//----------------------------------------------------------------------------------------------------
//   Function: Usecond2LocalTime
//      Input: LOCAL_TIME *local_time
//             Uint64 usecond
//     Output: void
//     Return: int32: ����ִ�����
//Description: ��ϵͳusװ���ɱ�������ʱ��
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
int32 Usecond2LocalTime(LOCAL_TIME *local_time, Uint64 usecond)
{
    Uint16 lv_year;
    Uint16 lv_year_in_400;
    Uint8  lv_month;
    Uint32 lv_day;
    Uint64 lv_ull_temp;
    Uint8  lv_leap_year_flag;

    if (NULL == local_time)
    {
        TRACE("function entry error");
        return NORMAL_ERROR;
    }

    lv_ull_temp = usecond / 1000;

    local_time->msecond = lv_ull_temp % 1000;
    lv_ull_temp = lv_ull_temp / 1000;

    local_time->second = lv_ull_temp % 60;
    lv_ull_temp = lv_ull_temp / 60;

    local_time->minute = lv_ull_temp % 60;
    lv_ull_temp = lv_ull_temp / 60;

    local_time->hour = lv_ull_temp % 24;
    lv_day = lv_ull_temp / 24;

    lv_year = (lv_day / DAYS_OF_400_YEAR) * 400u;
    lv_day = (lv_day % DAYS_OF_400_YEAR);

    lv_year_in_400 = lv_day / DAYS_OF_LEAP_YEAR;
    if (lv_day >= days_of_year_per_400[lv_year_in_400 + 1])
    {
        lv_year_in_400++;
    }
    lv_day -= days_of_year_per_400[lv_year_in_400];

    lv_leap_year_flag = ((leep_year_flag_of_400_year[lv_year_in_400 >> 4] >> (lv_year_in_400 & 0xf)) & 1);

    lv_month = lv_day / 31;
    if (lv_day >= days_of_month_year[lv_leap_year_flag][lv_month + 1])
    {
        lv_month++;
    }
    lv_day -= days_of_month_year[lv_leap_year_flag][lv_month];

    local_time->year = lv_year + lv_year_in_400 + 2000u;
    local_time->month = lv_month + 1;
    local_time->day = lv_day + 1;

    return NORMAL_SUCCESS;
}

//----------------------------------------------------------------------------------------------------
//   Function: LocalTime2Usecond
//      Input: LOCAL_TIME *local_time
//             Uint64 *p_usecond
//     Output: void
//     Return: int32: ����ִ�����
//Description: ��ϵͳusװ���ɱ�������ʱ��
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
Uint64 LocalTime2Usecond(LOCAL_TIME const *local_time)
{
    Uint16 lv_year;
    Uint16 lv_year_in_400;
    Uint8  lv_leap_year_flag;
    Uint64 lv_ull_temp;

    if (NULL == local_time)
    {
        TRACE("function entry error");
        return system_local_usecond;
    }

    lv_year = local_time->year - 2000u;
    lv_year_in_400 = (lv_year % 400u);
    lv_leap_year_flag = ((leep_year_flag_of_400_year[lv_year_in_400 >> 4] >> (lv_year_in_400 & 0xf)) & 1);

    lv_ull_temp =  (lv_year / 400u) * DAYS_OF_400_YEAR + days_of_year_per_400[lv_year_in_400]
            + days_of_month_year[lv_leap_year_flag][local_time->month - 1]
            + local_time->day - 1;
    lv_ull_temp = ((((((lv_ull_temp * 24 + local_time->hour) * 60 + local_time->minute) * 60) + local_time->second) * 1000) + local_time->msecond) * 1000;

    return lv_ull_temp;
}

//----------------------------------------------------------------------------------------------------
//   Function: LocalTime2Usecond
//      Input: LOCAL_TIME *local_time
//             Uint64 *p_usecond
//     Output: void
//     Return: int32: ����ִ�����
//Description: ��ϵͳusװ���ɱ�������ʱ��
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
Uint64 IrigbToUsecond(IRIGB const *p_irigb)
{
    Uint16 lv_year;
    Uint16 lv_year_in_400;
    Uint64 lv_ull_temp;

    if (NULL == p_irigb)
    {
        TRACE("function entry error");
        return system_local_usecond;
    }

    lv_year = p_irigb->year;
    lv_year_in_400 = (lv_year % 400u);

    lv_ull_temp = (lv_year / 400u) * DAYS_OF_400_YEAR + days_of_year_per_400[lv_year_in_400] + p_irigb->day - 1;
    lv_ull_temp = ((((((lv_ull_temp * 24u + p_irigb->hour) * 60u + p_irigb->minute) * 60u) + (p_irigb->second + 1u)) * 1000u) + p_irigb->msecond) * 1000u;

    return lv_ull_temp;
}

//----------------------------------------------------------------------------------------------------
//   Function: SpiContentCrcCal
//      Input: Uint16 crc_in: CRC��ʼֵ
//             Uint8 const *ptr: ������CRC�ֽ����׵�ַ
//             Uint16 length: ������CRC�ֽ�������
//     Output: void
//     Return: Uint16: CRC������
//Description: ����spiflash�е�����crc
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
Uint16 SpiContentCrcCal(Uint32 addr, int32 length)
{
    int32  lv_index;
    Uint16 lv_crc;
    Uint8  lv_crc_index;
    Uint32 lv_rd_addr;
    Uint8  lv_temp;

    lv_rd_addr = addr;
    lv_crc = 0xffff;
    for (lv_index = 0; lv_index < length; lv_index++)
    {
        WinbondW25Read(lv_rd_addr + lv_index, 1, &lv_temp);
        lv_crc_index = (lv_crc & 0xff) ^ lv_temp;
        lv_crc = const_default_crc_tab[lv_crc_index] ^ ((lv_crc >> 8) & 0xff);
    }

    return lv_crc;
}

//----------------------------------------------------------------------------------------------------
//   Function: PPSHoldControl
//      Input: int32 pps_hold_width_in : PPS��������
//             int8  gps_lose_flag : GPS��ʧ��ʶ
//     Output: void
//     Return: int32 : ��ʱ������
//Description: ��ʱ����
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
int32 PPSHoldControl(Uint32 *p_pps_hold_width, Uint32 pps_width_default, Uint32 pps_width_allowable_error, int8 gps_lose_flag, int8 reset_flag)
{
    Uint32  lv_pps_hold_width_in;
    Uint32  lv_pps_width_min_val;
    Uint32  lv_pps_width_max_val;
    Uint32  lv_pps_hold_width_cal;

    if (NULL == p_pps_hold_width)
    {
        TRACE("Function entries error!");
        return NORMAL_ERROR;
    }

    if (0 != reset_flag)
    {
        pps_hold_width_buffer_num  = 0;
        pps_hold_width_buffer_addr = 0;
        pps_lose_cnt  = 0;
        pps_hold_flag = 0;
    }

    if (0 == gps_lose_flag)
    {
        lv_pps_hold_width_in = *p_pps_hold_width;
        lv_pps_width_min_val = pps_width_default - pps_width_allowable_error;
        lv_pps_width_max_val = pps_width_default + pps_width_allowable_error;
        if ((lv_pps_hold_width_in >= lv_pps_width_min_val) && (lv_pps_hold_width_in <= lv_pps_width_max_val))
        {
            lv_pps_hold_width_cal = lv_pps_hold_width_in;
            pps_hold_width[PPS_HOLD_WIDTH_BUFFER_ADDR(pps_hold_width_buffer_addr++)] = lv_pps_hold_width_in;
            if (pps_hold_width_buffer_num < PPS_HOLD_WIDTH_BUFFER_NUM)
            {
                pps_hold_width_buffer_num++;
            }
        }
        else
        {
            lv_pps_hold_width_cal = pps_hold_width[PPS_HOLD_WIDTH_BUFFER_ADDR(pps_hold_width_buffer_addr - 1)];
        }
        pps_lose_cnt = 0;
        pps_hold_flag = 1;
    }
    else
    {
        if (0 == pps_hold_width_buffer_num)
        {
            pps_hold_flag = 0;
            lv_pps_hold_width_cal = pps_width_default;
        }
        else
        {
            lv_pps_hold_width_cal = pps_hold_width[PPS_HOLD_WIDTH_BUFFER_ADDR(pps_hold_width_buffer_addr - 1 - pps_lose_cnt)];
            if (pps_lose_cnt < pps_hold_width_buffer_num)
            {
                pps_lose_cnt++;
                if (pps_lose_cnt >= 600u)
                {
                    pps_hold_flag = 0;
                }
            }
            else
            {
                pps_hold_flag = 0;
                pps_lose_cnt = 0;
            }
        }
    }

    *p_pps_hold_width = lv_pps_hold_width_cal;

    return pps_hold_flag ;
}

//----------------------------------------------------------------------------------------------------
//   Function: DelayLoop
//      Input: Uint32 loopcnt: ѭ������
//     Output: void
//     Return: void
//Description: �ȴ�ѭ��
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
void DelayLoop(Uint32 loopcnt)
{
    Uint32 i;

    for (i = 0; i < loopcnt; i++)
    {
        asm("   NOP");
    }
}

//----------------------------------------------------------------------------------------------------
//   Function: MallocSpaceFromUserFastBuffer
//      Input: int32 length:�ļ�����
//     Output: void
//     Return: void *: ����Ĵ洢���׵�ַ,����ʧ�ܷ���NULL
//Description: ��User���ٴ洢�������ڴ�
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
void *MallocSpaceFromUserFastBuffer(int32 length)
{
    Uint32 lv_ulong_temp;
    char const *lv_user_fast_buffer_free_addr_old;

    lv_ulong_temp = (Uint32)user_fast_buffer_free_addr;
    lv_user_fast_buffer_free_addr_old = (char const *)(((lv_ulong_temp + 3) >> 2) << 2);
    if ((lv_user_fast_buffer_free_addr_old + length) > (user_fast_buffer + USER_FAST_BUFFER_LENGTH))
    {
        return NULL;
    }

    user_fast_buffer_free_addr = lv_user_fast_buffer_free_addr_old + length;

    return (void *)lv_user_fast_buffer_free_addr_old;
}

//----------------------------------------------------------------------------------------------------
//   Function: CallocSpaceFromUserFastBuffer
//      Input: int32 length:�ļ�����
//     Output: void
//     Return: void *: ����Ĵ洢���׵�ַ,����ʧ�ܷ���NULL
//Description: ��User���ٴ洢�������ڴ�,������
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
void *CallocSpaceFromUserFastBuffer(int32 length)
{
    void *lv_user_fast_buffer_free_addr;

    lv_user_fast_buffer_free_addr = MallocSpaceFromUserFastBuffer(length);
    if (NULL != lv_user_fast_buffer_free_addr)
    {
        memset(lv_user_fast_buffer_free_addr, 0, length);
    }

    return (void *)lv_user_fast_buffer_free_addr;
}


//----------------------------------------------------------------------------------------------------
//   Function: ParseDevConfig
//      Input: void
//     Output: void
//     Return: int32: ����ִ�����
//Description: �з����ý���,�����ź������Сֵ,��Ӣ������,Ĭ��ֵ��
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
int32 ParseDevConfig(void)
{
    int32 i;
    int32 lv_read_addr;
    int32 lv_dev_cfg_end_addr;
    int32 lv_dev_cfg_length;
    int32 lv_read_line_length;
    int32 lv_line_count;
    int32 lv_read_buffer_length;
    int8 const *lv_p_line_buffer;
    Uint8 lv_byte_temp;
    char  lv_buffer[256];
    int8  lv_section_flag;
    char *lv_p_desc;
    int32 lv_section_item_index;
    SETTING *lv_p_setting;
    SIGNAL_DATA lv_signal_data;

    lv_read_addr = FLASH_DEV_CFG_START_ADDR;
    WinbondW25Read(lv_read_addr, SELF_BIN_HEADER_LENGTH, buffer_public);
    if (    ((SELF_BIN_HEADER_LENGTH >> 2u) != buffer_public[4])
         || (SELF_BIN_VERSION != buffer_public[5])
         || (LLSB(BIN_FILE_TYPE_DEV_CFG) != buffer_public[6])
         || (LHSB(BIN_FILE_TYPE_DEV_CFG) != buffer_public[7])
         || ((0x01u) != buffer_public[SELF_BIN_HEADER_LENGTH - 2])
         || ((0xA0u) != buffer_public[SELF_BIN_HEADER_LENGTH - 1])
         || (0 != DefaultCrcCal(buffer_public, SELF_BIN_HEADER_LENGTH)))
    {
        TRACE("Dev cfg header crc is error!");
        return NORMAL_ERROR;
    }

    lv_dev_cfg_length =    buffer_public[0]
                        | (buffer_public[1] << 8)
                        | (buffer_public[2] << 16)
                        | (buffer_public[3] << 24);

    if (    (lv_dev_cfg_length < (SELF_BIN_HEADER_LENGTH + 3 + 9))
         || (lv_dev_cfg_length > (FLASH_DEV_CFG_LENGTH - SELF_BIN_HEADER_LENGTH)))
    {
        TRACE("Dev cfg length check error!");
        return NORMAL_ERROR;
    }

    lv_read_addr += SELF_BIN_HEADER_LENGTH;
    if (0 != SpiContentCrcCal(lv_read_addr, lv_dev_cfg_length))
    {
        TRACE("Dev cfg crc is error!");
        return NORMAL_ERROR;
    }

    WinbondW25Read(FLASH_ARG_SYS_START_ADDR, 1, &sys_cfg.language);
    if (sys_cfg.language >= LANGUAGE_TYPE_MAX)
    {
        TRACE("language is unknow, use default language!");
        sys_cfg.language = LANGUAGE_DEFAULT;
    }

    lv_dev_cfg_length -= 9;
    lv_dev_cfg_end_addr = lv_read_addr + lv_dev_cfg_length;

    lv_read_line_length = BUFFER_PUBLIC_LENGTH;
    lv_read_addr = WinbondW25ReadLine(lv_read_addr, &lv_read_line_length, buffer_public);
    if (lv_read_addr < 0)
    {
        TRACE("Dev cfg read line error!");
        return NORMAL_ERROR;
    }

    if (NORMAL_SUCCESS != Utf8ToSysEncodeInital((int8 const *)buffer_public, lv_read_line_length, sys_cfg.language))
    {
        TRACE("Utf8ToSysEncodeInital failed!");
        return NORMAL_ERROR;
    }

    lv_line_count = 1;
    lv_section_flag = 0;
    lv_section_item_index = 1;
    while (lv_dev_cfg_end_addr >  lv_read_addr)
    {
        lv_read_buffer_length = (lv_dev_cfg_end_addr - lv_read_addr + 1);
        if (lv_read_buffer_length > BUFFER_PUBLIC_LENGTH)
        {
            lv_read_buffer_length = BUFFER_PUBLIC_LENGTH;
        }

        lv_line_count++;
        lv_read_addr = WinbondW25ReadLine(lv_read_addr, &lv_read_buffer_length, buffer_public);
        if (lv_read_addr < 0)
        {
            TRACE("Dev cfg read line error! line:%d", lv_line_count);
            return NORMAL_ERROR;
        }

        lv_p_line_buffer = (char const *)buffer_public;
        while ((' ' == *lv_p_line_buffer) || ('\t' == *lv_p_line_buffer))
        {
            lv_p_line_buffer++;
        }

        if ('\0' == *lv_p_line_buffer)
        {
            continue;
        }
        else if (('/' == *lv_p_line_buffer) && ('/' == *(lv_p_line_buffer + 1)))
        {
            continue;
        }

        lv_p_line_buffer = GetContentToSplit(lv_p_line_buffer, lv_buffer, 256);
        if ((0 == lv_section_flag) && (0 == strcmp(lv_buffer, "<SystemParameter")))
        {
            if (NORMAL_SUCCESS != GetContentOfKeyword("Num", lv_p_line_buffer, lv_buffer, 256))
            {
                TRACE("DevCfg L%d:get keyword \"Num\" failed", lv_line_count);
                return NORMAL_ERROR;
            }
            else
            {
                lv_section_flag = 1;
                lv_section_item_index = 1;
                setting_system.num = strtol(lv_buffer, NULL, 0);
                if (setting_system.num != (setting_system_define_num + default_setting_system_define_num))
                {
                    TRACE("DevCfg L%d:setting_system_num must be %d get failed", lv_line_count, (setting_system_define_num + default_setting_system_define_num));
                    return NORMAL_ERROR;
                }

                setting_system.setting = (SETTING *)calloc(setting_system.num, sizeof(SETTING));
                if (NULL == setting_system.setting)
                {
                    TRACE("DevCfg L%d:setting_system calloc failed", lv_line_count);
                    return NORMAL_ERROR;
                }
            }
        }
        else
        {
            if (0 == strcmp(lv_buffer, "</SystemParameter"))
            {
                if (lv_section_item_index != setting_system.num)
                {
                    TRACE("DevCfg L%d:section item num error %d!=%d", lv_line_count, lv_section_item_index, setting_system.num);
                    return NORMAL_ERROR;
                }
                lv_section_flag = 2;
                break;
            }
            else
            {
                if (0 == strcmp(lv_buffer, "language"))
                {
                    lv_p_setting = &setting_system.setting[0];
                    lv_p_setting->define = &default_setting_system_define[0];
                }
                else
                {
                    if (lv_section_item_index >= setting_system.num)
                    {
                        TRACE("DevCfg L%d:section item num will greater than %d", lv_line_count, setting_system.num);
                        return NORMAL_ERROR;
                    }

                    for (i = 0; i < setting_system_define_num; i++)
                    {
                        if (0 == strcmp(lv_buffer, setting_system_define[i].name))
                        {
                            break;
                        }
                    }

                    if (i == setting_system_define_num)
                    {
                        TRACE("DevCfg L%d:setting_system_define \"%s\" find failed", lv_line_count, lv_buffer);
                        return NORMAL_ERROR;
                    }
                    lv_p_setting = &setting_system.setting[lv_section_item_index++];
                    lv_p_setting->define = &setting_system_define[i];
                }

                if (NORMAL_SUCCESS != GetContentOfKeyword(encode_type_str[sys_cfg.language], lv_p_line_buffer, lv_buffer, 256))
                {
                    TRACE("DevCfg L%d:get keyword \"%s\" content failed!", lv_line_count, encode_type_str[sys_cfg.language]);
                    return NORMAL_ERROR;
                }

                lv_p_desc = malloc(strlen(lv_buffer) + 1);
                if (NULL == lv_p_desc)
                {
                    TRACE("DevCfg L%d:p_setting->desc_utf8 malloc failed", lv_line_count);
                    return NORMAL_ERROR;
                }
                strncpy(lv_p_desc, lv_buffer, strlen(lv_buffer) + 1);
                lv_p_setting->desc_utf8 = lv_p_desc;

                lv_p_desc = malloc(strlen(lv_buffer) + 1);
                if (NULL == lv_p_desc)
                {
                    TRACE("DevCfg L%d:p_setting->desc malloc failed", lv_line_count);
                    return NORMAL_ERROR;
                }

                if (Utf8ToSysEncode(lv_buffer, strlen(lv_buffer), lv_p_desc, strlen(lv_buffer) + 1) < 0)
                {
                    TRACE("DevCfg L%d:p_setting->desc encoding failed", lv_line_count);
                    return NORMAL_ERROR;
                }
                lv_p_setting->desc = lv_p_desc;

                if (NORMAL_SUCCESS != GetContentOfKeyword("unit", lv_p_line_buffer, lv_p_setting->unit, UINT_LENGTH_MAX))
                {
                    TRACE("DevCfg L%d:get keyword \"%s\" content failed!", lv_line_count, encode_type_str[sys_cfg.language]);
                     return NORMAL_ERROR;
                }

                if (NORMAL_SUCCESS != GetValueOfKeyWord("visible", lv_p_line_buffer, SIGNAL_DATA_TYPE_ul, &lv_signal_data))
                {
                    lv_p_setting->visible = 0xffffffff;
                }
                else
                {
                    lv_p_setting->visible = lv_signal_data.ul;
                }

                if (NORMAL_SUCCESS != GetValueOfKeyWord("min", lv_p_line_buffer, lv_p_setting->define->type, &lv_p_setting->min_value))
                {
                    TRACE("DevCfg L%d:get min value type=%d failed!, str=\"%s\"", lv_line_count, lv_p_setting->define->type, lv_buffer);
                    return NORMAL_ERROR;
                }

                if (NORMAL_SUCCESS != GetValueOfKeyWord("max", lv_p_line_buffer, lv_p_setting->define->type, &lv_p_setting->max_value))
                {
                    TRACE("DevCfg L%d:get max value type=%d failed!, str=\"%s\"", lv_line_count, lv_p_setting->define->type, lv_buffer);
                    return NORMAL_ERROR;
                }

                if (NORMAL_SUCCESS != GetValueOfKeyWord("default", lv_p_line_buffer, lv_p_setting->define->type, &lv_p_setting->default_value))
                {
                    TRACE("DevCfg L%d:get default value type=%d failed!, str=\"%s\"", lv_line_count, lv_p_setting->define->type, lv_buffer);
                    return NORMAL_ERROR;
                }
            }
        }
    }

    if (lv_section_flag < 2)
    {
        TRACE("parse one section failed, section_parse_flag=%d", lv_section_flag);
        return NORMAL_ERROR;
    }
    else
    {
        if (NORMAL_SUCCESS != SettingManageInitial(&setting_system))
        {
            TRACE("system setting manage initial failed");
            return NORMAL_ERROR;
        }

        setting_system.flash_addr = FLASH_ARG_SYS_START_ADDR;
        if (NORMAL_SUCCESS != SettingReadFromFlash(&setting_system))
        {
            WinbondW25Read(setting_system.flash_addr, 1, &lv_byte_temp);
            if (0xffu == lv_byte_temp)
            {
                TRACE("Device power on first time, and save settings to default!");
                if (NORMAL_SUCCESS != SettingWriteToFlash(&setting_system))
                {
                    TRACE("setting save failed!");
                }
                else
                {
                    if (NORMAL_SUCCESS != CheckRunSettingWithFlash(&setting_system))
                    {
                        TRACE("setting check failed!");
                    }
                    else
                    {
                        DisableWatchDog();
                        TRACE("save default settings success!\r\nRebooting device...");
                        while (1);
                    }
                }
            }
            else
            {
                SettingRunBufferUpdateFromWriteBuffer(&setting_system);
                TRACE("setting read from flash failed, and set run_buffer/write_buffer to default value!\n\rPlease set the settings, than reboot device!");
            }
            return NORMAL_ERROR;
        }

        return NORMAL_SUCCESS;
    }
}

//----------------------------------------------------------------------------------------------------
//   Function: ParsePrjConfig
//      Input: void
//     Output: void
//     Return: int32: ����ִ�����
//Description: �������ý���
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
int32 ParsePrjConfig(void)
{
    int32 i;
    int32 lv_read_addr;
    int32 lv_prj_cfg_end_addr;
    int32 lv_prj_cfg_length;
    int32 lv_line_count;
    int32 lv_read_buffer_length;
    int8 const *lv_p_line_buffer;
    int8 const *lv_p_config_str;
    char  lv_buffer[256];

    lv_read_addr = FLASH_PRJ_CFG_START_ADDR;
    WinbondW25Read(lv_read_addr, SELF_BIN_HEADER_LENGTH + 3, buffer_public);
    if (    ((SELF_BIN_HEADER_LENGTH >> 2u) != buffer_public[4])
         || (SELF_BIN_VERSION != buffer_public[5])
         || (LLSB(BIN_FILE_TYPE_PRJ_CFG) != buffer_public[6])
         || (LHSB(BIN_FILE_TYPE_PRJ_CFG) != buffer_public[7])
         || ((0x01u) != buffer_public[SELF_BIN_HEADER_LENGTH - 2])
         || ((0xA0u) != buffer_public[SELF_BIN_HEADER_LENGTH - 1])
         || (0 != DefaultCrcCal(buffer_public, SELF_BIN_HEADER_LENGTH)))
    {
        TRACE("Prj cfg header crc is error!");
        return NORMAL_ERROR;
    }

    lv_p_config_str = (int8 const *)&buffer_public[SELF_BIN_HEADER_LENGTH];
    for (i = 0; i < 3; i++)
    {
        if (utf8_bom[i] != lv_p_config_str[i])
        {
            TRACE("PrjCfg.txt File encode is not UTF-8, Please check!");
            return NORMAL_ERROR;
        }
    }

    lv_prj_cfg_length =    buffer_public[0]
                        | (buffer_public[1] << 8)
                        | (buffer_public[2] << 16)
                        | (buffer_public[3] << 24);

    if (    (lv_prj_cfg_length < (SELF_BIN_HEADER_LENGTH + 3 + 9))
         || (lv_prj_cfg_length > (FLASH_PRJ_CFG_LENGTH - SELF_BIN_HEADER_LENGTH)))
    {
        TRACE("Prj cfg length check error!");
        return NORMAL_ERROR;
    }

    lv_read_addr += SELF_BIN_HEADER_LENGTH;
    if (0 != SpiContentCrcCal(lv_read_addr, lv_prj_cfg_length))
    {
        TRACE("Prj cfg crc is error!");
        return NORMAL_ERROR;
    }

    lv_prj_cfg_length -= 9;
    lv_prj_cfg_end_addr = lv_read_addr + lv_prj_cfg_length;

    lv_read_addr += 3;
    lv_line_count = 0;
    while (lv_prj_cfg_end_addr >  lv_read_addr)
    {
        lv_read_buffer_length = (lv_prj_cfg_end_addr - lv_read_addr + 1);
        if (lv_read_buffer_length > BUFFER_PUBLIC_LENGTH)
        {
            lv_read_buffer_length = BUFFER_PUBLIC_LENGTH;
        }

        lv_line_count++;
        lv_read_addr = WinbondW25ReadLine(lv_read_addr, &lv_read_buffer_length, buffer_public);
        if (lv_read_addr < 0)
        {
            TRACE("Prj cfg read line error! line:%d", lv_line_count);
            return NORMAL_ERROR;
        }

        lv_p_line_buffer = (char const *)buffer_public;
        while ((' ' == *lv_p_line_buffer) || ('\t' == *lv_p_line_buffer))
        {
            lv_p_line_buffer++;
        }

        if ('\0' == *lv_p_line_buffer)
        {
            continue;
        }
        else if (('/' == *lv_p_line_buffer) && ('/' == *(lv_p_line_buffer + 1)))
        {
            continue;
        }

        lv_p_line_buffer = GetContentToSplit(lv_p_line_buffer, lv_buffer, 256);
        if (0 == strcmp(lv_buffer, "<GooseTx"))
        {
            if (NORMAL_SUCCESS != GetContentOfKeyword("Num", lv_p_line_buffer, lv_buffer, 256))
            {
                TRACE("PrjCfg L%d:get keyword \"Num\" failed", lv_line_count);
                return NORMAL_ERROR;
            }
            else
            {
                prj_cfg.goose_tx.cb_num = strtol(lv_buffer, NULL, 0);
                if (prj_cfg.goose_tx.cb_num < 0)
                {
                    TRACE("PrjCfg L%d:prj_cfg.goose_tx.cb_num get failed", lv_line_count);
                    return NORMAL_ERROR;
                }
                else if (0 == prj_cfg.goose_tx.cb_num)
                {
                    continue;
                }

                prj_cfg.goose_tx.gocb = (GOCB *)calloc(prj_cfg.goose_tx.cb_num, sizeof(GOCB));
                if (NULL == prj_cfg.goose_tx.gocb)
                {
                    TRACE("PrjCfg L%d:gocb calloc failed", lv_line_count);
                    return NORMAL_ERROR;
                }

                for (i = 0; i < prj_cfg.goose_tx.cb_num; i++)
                {
                    pEMAC_CONTROL->DESCRIPTOR[i + 16].next = &pEMAC_CONTROL->DESCRIPTOR[i + 16 + 1];
                    prj_cfg.goose_tx.gocb[i].emac_desc = &pEMAC_CONTROL->DESCRIPTOR[i + 16];
                }
                pEMAC_CONTROL->DESCRIPTOR[i + 16 - 1].next = NULL;

                if (NORMAL_SUCCESS != ParseGooseTx(&lv_read_addr, lv_prj_cfg_end_addr, &lv_line_count))
                {
                    TRACE(" L%d: read line error!", lv_line_count);
                    return NORMAL_ERROR;
                }
            }
        }
        else if (0 == strcmp(lv_buffer, "<SvTx"))
        {
            if (NORMAL_SUCCESS != GetContentOfKeyword("Num", lv_p_line_buffer, lv_buffer, 256))
            {
                TRACE("PrjCfg L%d:get keyword \"Num\" failed", lv_line_count);
                return NORMAL_ERROR;
            }
            else
            {
                prj_cfg.sv_tx.cb_num = strtol(lv_buffer, NULL, 0);
                if ((prj_cfg.sv_tx.cb_num < 0) || (prj_cfg.sv_tx.cb_num > 16))
                {
                    TRACE("PrjCfg L%d:SVCB num=%d exceed scope [0,15]", lv_line_count, prj_cfg.sv_tx.cb_num);
                    return NORMAL_ERROR;
                }
                else if (0 == prj_cfg.sv_tx.cb_num)
                {
                    continue;
                }

                prj_cfg.sv_tx.svcb = (SVCB *)calloc(prj_cfg.sv_tx.cb_num, sizeof(SVCB));
                if (NULL == prj_cfg.sv_tx.svcb)
                {
                    TRACE("PrjCfg L%d:svcb calloc failed", lv_line_count);
                    return NORMAL_ERROR;
                }

                for (i = 0; i < prj_cfg.sv_tx.cb_num; i++)
                {
                    pEMAC_CONTROL->DESCRIPTOR[i].next = &pEMAC_CONTROL->DESCRIPTOR[i + 1];
                    prj_cfg.sv_tx.svcb[i].emac_desc = &pEMAC_CONTROL->DESCRIPTOR[i];
                }
                pEMAC_CONTROL->DESCRIPTOR[i - 1].next = NULL;

                if (NORMAL_SUCCESS != ParseSvTx(&lv_read_addr, lv_prj_cfg_end_addr, &lv_line_count))
                {
                    TRACE(" L%d: read line error!", lv_line_count);
                    return NORMAL_ERROR;
                }
            }
        }
    }

    return NORMAL_SUCCESS;
}

//----------------------------------------------------------------------------------------------------
// ���غ���
//----------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------
//   Function: ParseGooseTx
//      Input: int32 *p_addr:�ļ���ǰ��ַ
//             int32 end_addr:�ļ�������ַ
//             int32 *p_line_count:�к�
//     Output: int32 *p_addr:�ļ�������ĵ�ַ
//             *p_line_count:�к�
//     Return: int32: ����ִ�����
//Description: ���������ļ�SvTx����
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
static int32 ParseGooseTx(int32 *p_addr, int32 end_addr, int32 *p_line_count)
{
    int32 i;
    int32 lv_read_addr;
    int32 lv_line_count;
    int32 lv_cb_index;
    int32 lv_cb_item_index;
    int32 lv_read_buffer_length;
    int8 const *lv_p_line_buffer;
    int32 lv_goose_tx_flag;
    char  lv_buffer[256];
    char  *lv_p_desc;
    GOCB  *lv_p_gocb;
    SIGNAL_DATA lv_signal_data;
    SIGNAL_OUT  *lv_p_signal_out;
    SIGNAL_OUT  *lv_p_current_signal_out;

    lv_read_addr  = *p_addr;
    lv_line_count = *p_line_count;

    lv_goose_tx_flag = 0;
    lv_cb_index  = 0;
    while (end_addr >  lv_read_addr)
    {
        lv_read_buffer_length = (end_addr - lv_read_addr + 1);
        if (lv_read_buffer_length > BUFFER_PUBLIC_LENGTH)
        {
            lv_read_buffer_length = BUFFER_PUBLIC_LENGTH;
        }

        lv_line_count++;
        lv_read_addr = WinbondW25ReadLine(lv_read_addr, &lv_read_buffer_length, buffer_public);
        if (lv_read_addr < 0)
        {
            TRACE("Prj cfg read line error! line:%d", lv_line_count);
            goto error_handler;
        }

        lv_p_line_buffer = (char const *)buffer_public;
        while ((' ' == *lv_p_line_buffer) || ('\t' == *lv_p_line_buffer))
        {
            lv_p_line_buffer++;
        }

        if ('\0' == *lv_p_line_buffer)
        {
            continue;
        }
        else if (('/' == *lv_p_line_buffer) && ('/' == *(lv_p_line_buffer + 1)))
        {
            continue;
        }

        lv_p_line_buffer = GetContentToSplit(lv_p_line_buffer, lv_buffer, 256);
        if (0 == strcmp(lv_buffer, "</GooseTx"))
        {
            if (lv_cb_index != prj_cfg.goose_tx.cb_num)
            {
                TRACE("PrjCfg L%d:gocb item num error %d!=%d", lv_line_count, lv_cb_index, prj_cfg.goose_tx.cb_num);
                goto error_handler;
            }

            if (0 != lv_goose_tx_flag)
            {
                TRACE("PrjCfg L%d:gocb maybe incomplete", lv_line_count);
                goto error_handler;
            }
            lv_goose_tx_flag = 2;
            break;
        }
        else if (0 == lv_goose_tx_flag)
        {
            if (lv_cb_index >= prj_cfg.goose_tx.cb_num)
            {
                TRACE("PrjCfg L%d:cb num will greater than %d", lv_line_count, prj_cfg.goose_tx.cb_num);
                goto error_handler;
            }

            if (0 == strcmp(lv_buffer, "<CB"))
            {
                lv_p_gocb = &prj_cfg.goose_tx.gocb[lv_cb_index++];
                if (NORMAL_SUCCESS != GetValueOfKeyWord("DataNum", lv_p_line_buffer, SIGNAL_DATA_TYPE_ui, &lv_signal_data))
                {
                    TRACE("PrjCfg L%d:GoCb[%d] DataNum parse failed", lv_line_count, lv_cb_index - 1);
                    goto error_handler;
                }
                lv_p_gocb->item_num = lv_signal_data.ui;
                if ((0 == lv_p_gocb->item_num) || (lv_p_gocb->item_num > 32767u))
                {
                    TRACE("PrjCfg L%d:GoCb[%d] DataNum must not be 0 and must be less than 32768", lv_line_count, lv_cb_index - 1);
                    goto error_handler;
                }

                if (NORMAL_SUCCESS != GetValueOfKeyWord("Addr", lv_p_line_buffer, SIGNAL_DATA_TYPE_ui, &lv_signal_data))
                {
                    TRACE("PrjCfg L%d:GoCb[%d] Addr parse failed", lv_line_count, lv_cb_index - 1);
                    goto error_handler;
                }
                lv_p_gocb->mac_dst_addr = lv_signal_data.ui;

                if (NORMAL_SUCCESS != GetValueOfKeyWord("AppID", lv_p_line_buffer, SIGNAL_DATA_TYPE_ui, &lv_signal_data))
                {
                    TRACE("PrjCfg L%d:GoCb[%d] AppID parse failed", lv_line_count, lv_cb_index - 1);
                    goto error_handler;
                }
                lv_p_gocb->app_id = lv_signal_data.ui;
                if (lv_p_gocb->app_id > 0x3FFFu)
                {
                    TRACE("PrjCfg L%d:GoCb[%d] AppID=0x%04X exceed scope [0x4000,0x7FFF] ", lv_line_count, lv_cb_index - 1, lv_p_gocb->app_id);
                    goto error_handler;
                }

                if (NORMAL_SUCCESS != GetValueOfKeyWord("VlanID", lv_p_line_buffer, SIGNAL_DATA_TYPE_ui, &lv_signal_data))
                {
                    lv_p_gocb->vlan_id = 0;
                }
                else
                {
                    lv_p_gocb->vlan_id = lv_signal_data.ui;
                    if (lv_p_gocb->vlan_id > 0xFFFu)
                    {
                        TRACE("PrjCfg L%d:GoCb[%d] VlanID=0x%04X exceed scope [0,0xFFF] ", lv_line_count, lv_cb_index - 1, lv_p_gocb->vlan_id);
                        goto error_handler;
                    }
                }

                if (NORMAL_SUCCESS != GetValueOfKeyWord("Priority", lv_p_line_buffer, SIGNAL_DATA_TYPE_uc, &lv_signal_data))
                {
                    lv_p_gocb->priority = 4;
                }
                else
                {
                    lv_p_gocb->priority = lv_signal_data.uc;
                    if (lv_p_gocb->priority > 8u)
                    {
                        TRACE("PrjCfg L%d:GoCb[%d] Priority=0x%04X exceed scope [0,7] ", lv_line_count, lv_cb_index - 1, lv_p_gocb->priority);
                        goto error_handler;
                    }
                }

                if (NORMAL_SUCCESS != GetValueOfKeyWord("ConfRev", lv_p_line_buffer, SIGNAL_DATA_TYPE_ul, &lv_signal_data))
                {
                    TRACE("PrjCfg L%d:GoCb[%d] ConfRev parse failed", lv_line_count, lv_cb_index - 1);
                    goto error_handler;
                }
                lv_p_gocb->conf_rev= lv_signal_data.ul;

                if (NORMAL_SUCCESS != GetValueOfKeyWord("MinTime", lv_p_line_buffer, SIGNAL_DATA_TYPE_ul, &lv_signal_data))
                {
                    lv_p_gocb->first_frame_tal = 2;
                }
                else
                {
                    lv_p_gocb->first_frame_tal = lv_signal_data.ul;
                    if (lv_p_gocb->first_frame_tal < 1)
                    {
                        lv_p_gocb->first_frame_tal = 1;
                    }
                }

                if (NORMAL_SUCCESS != GetValueOfKeyWord("MaxTime", lv_p_line_buffer, SIGNAL_DATA_TYPE_ul, &lv_signal_data))
                {
                    lv_p_gocb->heartbeat_tal = 5000;
                }
                else
                {
                    lv_p_gocb->heartbeat_tal = lv_signal_data.ul;
                    if (lv_p_gocb->heartbeat_tal < lv_p_gocb->first_frame_tal)
                    {
                        lv_p_gocb->heartbeat_tal = lv_p_gocb->first_frame_tal;
                    }
                    else if (lv_p_gocb->heartbeat_tal > 864000000)
                    {
                        lv_p_gocb->heartbeat_tal = 864000000;
                    }
                }

                lv_p_gocb->second_frame_tal = lv_p_gocb->first_frame_tal;
                if (lv_p_gocb->second_frame_tal > lv_p_gocb->heartbeat_tal)
                {
                    lv_p_gocb->second_frame_tal = lv_p_gocb->heartbeat_tal;
                }

                lv_p_gocb->third_frame_tal = (lv_p_gocb->second_frame_tal << 1);
                if (lv_p_gocb->third_frame_tal > lv_p_gocb->heartbeat_tal)
                {
                    lv_p_gocb->third_frame_tal = lv_p_gocb->heartbeat_tal;
                }

                lv_p_gocb->fourth_frame_tal = (lv_p_gocb->third_frame_tal << 1);
                if (lv_p_gocb->fourth_frame_tal > lv_p_gocb->heartbeat_tal)
                {
                    lv_p_gocb->fourth_frame_tal = lv_p_gocb->heartbeat_tal;
                }

                if (NORMAL_SUCCESS != GetContentOfKeyword("ID", lv_p_line_buffer, lv_buffer, 256))
                {
                    TRACE("PrjCfg L%d:GoCb[%d] get keyword \"ID\" content failed!", lv_line_count, lv_cb_index - 1);
                    goto error_handler;
                }

                lv_p_desc = malloc(strlen(lv_buffer) + 1);
                if (NULL == lv_p_desc)
                {
                    TRACE("PrjCfg L%d:GoCb[%d] p_gocb->id malloc failed", lv_line_count);
                    goto error_handler;
                }
                strncpy(lv_p_desc, lv_buffer, strlen(lv_buffer) + 1);
                lv_p_gocb->id = lv_p_desc;

                if (NORMAL_SUCCESS != GetContentOfKeyword("Ref", lv_p_line_buffer, lv_buffer, 256))
                {
                    TRACE("PrjCfg L%d:GoCb[%d] get keyword \"Ref\" content failed!", lv_line_count, lv_cb_index - 1);
                    goto error_handler;
                }

                lv_p_desc = malloc(strlen(lv_buffer) + 1);
                if (NULL == lv_p_desc)
                {
                    TRACE("PrjCfg L%d:GoCb[%d] p_gocb->ref malloc failed", lv_line_count, lv_cb_index - 1);
                    goto error_handler;
                }
                strncpy(lv_p_desc, lv_buffer, strlen(lv_buffer) + 1);
                lv_p_gocb->ref = lv_p_desc;

                if (NORMAL_SUCCESS != GetContentOfKeyword("DataSet", lv_p_line_buffer, lv_buffer, 256))
                {
                    TRACE("PrjCfg L%d:GoCb[%d] get keyword \"DataSet\" content failed!", lv_line_count, lv_cb_index - 1);
                    goto error_handler;
                }

                lv_p_desc = malloc(strlen(lv_buffer) + 1);
                if (NULL == lv_p_desc)
                {
                    TRACE("PrjCfg L%d:GoCb[%d] p_gocb->data_set malloc failed", lv_line_count, lv_cb_index - 1);
                    goto error_handler;
                }
                strncpy(lv_p_desc, lv_buffer, strlen(lv_buffer) + 1);
                lv_p_gocb->data_set = lv_p_desc;

                lv_p_signal_out = malloc(lv_p_gocb->item_num * sizeof(SIGNAL_OUT));
                if (NULL == lv_p_signal_out)
                {
                    TRACE("PrjCfg L%d:GoCb[%d] p_gocb->signal_out malloc failed", lv_line_count, lv_cb_index - 1);
                    goto error_handler;
                }

                lv_goose_tx_flag = 1;
                lv_cb_item_index = 0;
            }
            else
            {
                TRACE("PrjCfg L%d:GoCb[%d] get keyword \"<CB\" failed", lv_line_count, lv_cb_index - 1);
                goto error_handler;
            }
        }
        else
        {
            if (0 == strcmp(lv_buffer, "</CB"))
            {
                if (lv_cb_item_index != lv_p_gocb->item_num)
                {
                    TRACE("PrjCfg L%d:GoCb[%d] gocb item num error %d!=%d", lv_line_count, lv_cb_index - 1, lv_cb_item_index, lv_p_gocb->item_num);
                    goto error_handler;
                }
                lv_p_gocb->singal_out = lv_p_signal_out;
                lv_goose_tx_flag = 0;
            }
            else
            {
                if (lv_cb_item_index >= lv_p_gocb->item_num)
                {
                    TRACE("PrjCfg L%d:GoCb[%d] svcb item num will greater than %d", lv_line_count, lv_cb_index - 1, lv_p_gocb->item_num);
                    goto error_handler;
                }

                for (i = 0; i < goose_signal_out_define_num; i++)
                {
                    if (0 == strcmp(lv_buffer, goose_signal_out_define[i].name))
                    {
                        break;
                    }
                }

                if (i == goose_signal_out_define_num)
                {
                    TRACE("PrjCfg L%d:GoCb[%d] signal_out_define \"%s\" find failed", lv_line_count, lv_cb_index - 1, lv_buffer);
                    goto error_handler;
                }

                lv_p_current_signal_out = &lv_p_signal_out[lv_cb_item_index++];
                lv_p_current_signal_out->define = &goose_signal_out_define[i];

                if (NORMAL_SUCCESS != GetContentOfKeyword("type", lv_p_line_buffer, lv_buffer, 256))
                {
                    TRACE("PrjCfg L%d:GoCb[%d] get keyword \"type\" failed", lv_line_count, lv_cb_index - 1);
                    goto error_handler;
                }

                for (i = 0; i < goose_prj_type_define_num; i++)
                {
                    if (0 == strcmp(lv_buffer, goose_prj_type_define[i].name))
                    {
                        break;
                    }
                }
                if (i == goose_prj_type_define_num)
                {
                    TRACE("PrjCfg L%d:GoCb[%d] signal_out  find failed", lv_line_count, lv_cb_index - 1);
                    goto error_handler;
                }
                lv_p_current_signal_out->prj_type_define = &goose_prj_type_define[i];
            }
        }
    }

    if (2 != lv_goose_tx_flag)
    {
        TRACE("PrjCfg L%d:GoCb[%d] maybe not finish", lv_line_count, lv_cb_index - 1);
        goto error_handler;
    }

    *p_addr = lv_read_addr;
    *p_line_count = lv_line_count;

    return NORMAL_SUCCESS;

//----------------------------------------------------------------------------------------------------
// ������
//----------------------------------------------------------------------------------------------------
error_handler:
    *p_line_count = lv_line_count;

    return NORMAL_ERROR;
}

//----------------------------------------------------------------------------------------------------
//   Function: ParseSvTx
//      Input: int32 *p_addr:�ļ���ǰ��ַ
//             int32 end_addr:�ļ�������ַ
//             int32 *p_line_count:�к�
//     Output: int32 *p_addr:�ļ�������ĵ�ַ
//             *p_line_count:�к�
//     Return: int32: ����ִ�����
//Description: ���������ļ�SvTx����
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
static int32 ParseSvTx(int32 *p_addr, int32 end_addr, int32 *p_line_count)
{
    int32 i;
    int32 lv_read_addr;
    int32 lv_line_count;
    int32 lv_cb_index;
    int32 lv_cb_item_index;
    int32 lv_read_buffer_length;
    int8 const *lv_p_line_buffer;
    int32 lv_sv_tx_flag;
    char  lv_buffer[256];
    char  *lv_p_desc;
    SVCB  *lv_p_svcb;
    SIGNAL_DATA lv_signal_data;
    SIGNAL_OUT  *lv_p_signal_out;
    SIGNAL_OUT  *lv_p_current_signal_out;

    lv_read_addr  = *p_addr;
    lv_line_count = *p_line_count;

    lv_sv_tx_flag = 0;
    lv_cb_index  = 0;
    while (end_addr >  lv_read_addr)
    {
        lv_read_buffer_length = (end_addr - lv_read_addr + 1);
        if (lv_read_buffer_length > BUFFER_PUBLIC_LENGTH)
        {
            lv_read_buffer_length = BUFFER_PUBLIC_LENGTH;
        }

        lv_line_count++;
        lv_read_addr = WinbondW25ReadLine(lv_read_addr, &lv_read_buffer_length, buffer_public);
        if (lv_read_addr < 0)
        {
            TRACE("Prj cfg read line error! line:%d", lv_line_count);
            goto error_handler;
        }

        lv_p_line_buffer = (char const *)buffer_public;
        while ((' ' == *lv_p_line_buffer) || ('\t' == *lv_p_line_buffer))
        {
            lv_p_line_buffer++;
        }

        if ('\0' == *lv_p_line_buffer)
        {
            continue;
        }
        else if (('/' == *lv_p_line_buffer) && ('/' == *(lv_p_line_buffer + 1)))
        {
            continue;
        }

        lv_p_line_buffer = GetContentToSplit(lv_p_line_buffer, lv_buffer, 256);
        if (0 == strcmp(lv_buffer, "</SvTx"))
        {
            if (lv_cb_index != prj_cfg.sv_tx.cb_num)
            {
                TRACE("PrjCfg L%d:svcb item num error %d!=%d", lv_line_count, lv_cb_index, prj_cfg.sv_tx.cb_num);
                goto error_handler;
            }

            if (0 != lv_sv_tx_flag)
            {
                TRACE("PrjCfg L%d:svcb maybe incomplete", lv_line_count);
                goto error_handler;
            }
            lv_sv_tx_flag = 2;
            break;
        }
        else if (0 == lv_sv_tx_flag)
        {
            if (lv_cb_index >= prj_cfg.sv_tx.cb_num)
            {
                TRACE("PrjCfg L%d:cb num will greater than %d", lv_line_count, prj_cfg.sv_tx.cb_num);
                goto error_handler;
            }

            if (0 == strcmp(lv_buffer, "<CB"))
            {
                lv_p_svcb = &prj_cfg.sv_tx.svcb[lv_cb_index++];
                if (NORMAL_SUCCESS != GetValueOfKeyWord("DataNum", lv_p_line_buffer, SIGNAL_DATA_TYPE_ui, &lv_signal_data))
                {
                    TRACE("PrjCfg L%d:SvCb[%d] DataNum parse failed", lv_line_count, lv_cb_index - 1);
                    goto error_handler;
                }
                lv_p_svcb->item_num = lv_signal_data.ui;
                if (0 == lv_p_svcb->item_num)
                {
                    TRACE("PrjCfg L%d:SvCb[%d] DataNum must not be 0", lv_line_count, lv_cb_index - 1);
                    goto error_handler;
                }

                if (NORMAL_SUCCESS != GetValueOfKeyWord("Addr", lv_p_line_buffer, SIGNAL_DATA_TYPE_ui, &lv_signal_data))
                {
                    TRACE("PrjCfg L%d:SvCb[%d] Addr parse failed", lv_line_count, lv_cb_index - 1);
                    goto error_handler;
                }
                lv_p_svcb->mac_dst_addr = lv_signal_data.ui;

                if (NORMAL_SUCCESS != GetValueOfKeyWord("AppID", lv_p_line_buffer, SIGNAL_DATA_TYPE_ui, &lv_signal_data))
                {
                    TRACE("PrjCfg L%d:SvCb[%d] AppID parse failed", lv_line_count, lv_cb_index - 1);
                    goto error_handler;
                }
                lv_p_svcb->app_id = lv_signal_data.ui;
                if ((lv_p_svcb->app_id < 0x4000u) || (lv_p_svcb->app_id > 0x7FFFu))
                {
                    TRACE("PrjCfg L%d:SvCb[%d] AppID=0x%04X exceed scope [0x4000,0x7FFF] ", lv_line_count, lv_cb_index - 1, lv_p_svcb->app_id);
                    goto error_handler;
                }

                if (NORMAL_SUCCESS != GetValueOfKeyWord("VlanID", lv_p_line_buffer, SIGNAL_DATA_TYPE_ui, &lv_signal_data))
                {
                    lv_p_svcb->vlan_id = 0;
                }
                else
                {
                    lv_p_svcb->vlan_id = lv_signal_data.ui;
                    if (lv_p_svcb->vlan_id > 0xFFFu)
                    {
                        TRACE("PrjCfg L%d:SvCb[%d] VlanID=0x%04X exceed scope [0,0xFFF] ", lv_line_count, lv_cb_index - 1, lv_p_svcb->vlan_id);
                        goto error_handler;
                    }
                }

                if (NORMAL_SUCCESS != GetValueOfKeyWord("Priority", lv_p_line_buffer, SIGNAL_DATA_TYPE_uc, &lv_signal_data))
                {
                    lv_p_svcb->priority = 4;
                }
                else
                {
                    lv_p_svcb->priority = lv_signal_data.uc;
                    if (lv_p_svcb->priority > 8u)
                    {
                        TRACE("PrjCfg L%d:SvCb[%d] Priority=0x%04X exceed scope [0,7] ", lv_line_count, lv_cb_index - 1, lv_p_svcb->priority);
                        goto error_handler;
                    }
                }

                if (NORMAL_SUCCESS != GetValueOfKeyWord("ConfRev", lv_p_line_buffer, SIGNAL_DATA_TYPE_ul, &lv_signal_data))
                {
                    TRACE("PrjCfg L%d:SvCb[%d] ConfRev parse failed", lv_line_count, lv_cb_index - 1);
                    goto error_handler;
                }
                lv_p_svcb->conf_rev= lv_signal_data.ul;

                if (NORMAL_SUCCESS != GetContentOfKeyword("ID", lv_p_line_buffer, lv_buffer, 256))
                {
                    TRACE("PrjCfg L%d:SvCb[%d] get keyword \"ID\" content failed!", lv_line_count, lv_cb_index - 1);
                    goto error_handler;
                }

                lv_p_desc = malloc(strlen(lv_buffer) + 1);
                if (NULL == lv_p_desc)
                {
                    TRACE("PrjCfg L%d:SvCb[%d] p_svcb->id malloc failed", lv_line_count);
                    goto error_handler;
                }
                strncpy(lv_p_desc, lv_buffer, strlen(lv_buffer) + 1);
                lv_p_svcb->id = lv_p_desc;

                if (NORMAL_SUCCESS != GetContentOfKeyword("Ref", lv_p_line_buffer, lv_buffer, 256))
                {
                    TRACE("PrjCfg L%d:SvCb[%d] get keyword \"Ref\" content failed!", lv_line_count, lv_cb_index - 1);
                    goto error_handler;
                }

                lv_p_desc = malloc(strlen(lv_buffer) + 1);
                if (NULL == lv_p_desc)
                {
                    TRACE("PrjCfg L%d:SvCb[%d] p_svcb->ref malloc failed", lv_line_count, lv_cb_index - 1);
                    goto error_handler;
                }
                strncpy(lv_p_desc, lv_buffer, strlen(lv_buffer) + 1);
                lv_p_svcb->ref = lv_p_desc;

                if (NORMAL_SUCCESS != GetContentOfKeyword("DataSet", lv_p_line_buffer, lv_buffer, 256))
                {
                    TRACE("PrjCfg L%d:SvCb[%d] get keyword \"DataSet\" content failed!", lv_line_count, lv_cb_index - 1);
                    goto error_handler;
                }

                lv_p_desc = malloc(strlen(lv_buffer) + 1);
                if (NULL == lv_p_desc)
                {
                    TRACE("PrjCfg L%d:SvCb[%d] p_svcb->data_set malloc failed", lv_line_count, lv_cb_index - 1);
                    goto error_handler;
                }
                strncpy(lv_p_desc, lv_buffer, strlen(lv_buffer) + 1);
                lv_p_svcb->data_set = lv_p_desc;

                lv_p_signal_out = malloc(lv_p_svcb->item_num * sizeof(SIGNAL_OUT));
                if (NULL == lv_p_signal_out)
                {
                    TRACE("PrjCfg L%d:SvCb[%d] p_svcb->signal_out malloc failed", lv_line_count, lv_cb_index - 1);
                    goto error_handler;
                }

                lv_sv_tx_flag = 1;
                lv_cb_item_index = 0;
            }
            else
            {
                TRACE("PrjCfg L%d:SvCb[%d] get keyword \"<CB\" failed", lv_line_count, lv_cb_index - 1);
                goto error_handler;
            }
        }
        else
        {
            if (0 == strcmp(lv_buffer, "</CB"))
            {
                if (lv_cb_item_index != lv_p_svcb->item_num)
                {
                    TRACE("PrjCfg L%d:SvCb[%d] svcb item num error %d!=%d", lv_line_count, lv_cb_index - 1, lv_cb_item_index, lv_p_svcb->item_num);
                    goto error_handler;
                }
                lv_p_svcb->singal_out = lv_p_signal_out;
                lv_sv_tx_flag = 0;
            }
            else
            {
                if (lv_cb_item_index >= lv_p_svcb->item_num)
                {
                    TRACE("PrjCfg L%d:SvCb[%d] svcb item num will greater than %d", lv_line_count, lv_cb_index - 1, lv_p_svcb->item_num);
                    goto error_handler;
                }

                for (i = 0; i < sv_signal_out_define_num; i++)
                {
                    if (0 == strcmp(lv_buffer, sv_signal_out_define[i].name))
                    {
                        break;
                    }
                }

                if (i == sv_signal_out_define_num)
                {
                    TRACE("PrjCfg L%d:SvCb[%d] signal_out_define \"%s\" find failed", lv_line_count, lv_cb_index - 1, lv_buffer);
                    goto error_handler;
                }

                lv_p_current_signal_out = &lv_p_signal_out[lv_cb_item_index++];
                lv_p_current_signal_out->define = &sv_signal_out_define[i];

                if (NORMAL_SUCCESS != GetContentOfKeyword("type", lv_p_line_buffer, lv_buffer, 256))
                {
                    TRACE("PrjCfg L%d:SvCb[%d] get keyword \"type\" failed", lv_line_count, lv_cb_index - 1);
                    goto error_handler;
                }

                for (i = 0; i < sv_prj_type_define_num; i++)
                {
                    if (0 == strcmp(lv_buffer, sv_prj_type_define[i].name))
                    {
                        break;
                    }
                }
                if (i == sv_prj_type_define_num)
                {
                    TRACE("PrjCfg L%d:SvCb[%d] signal_out  find failed", lv_line_count, lv_cb_index - 1);
                    goto error_handler;
                }
                lv_p_current_signal_out->prj_type_define = &sv_prj_type_define[i];
            }
        }
    }

    if (2 != lv_sv_tx_flag)
    {
        TRACE("PrjCfg L%d:GoCb[%d] maybe not finish", lv_line_count, lv_cb_index - 1);
        goto error_handler;
    }

    *p_addr = lv_read_addr;
    *p_line_count = lv_line_count;

    return NORMAL_SUCCESS;

//----------------------------------------------------------------------------------------------------
// ������
//----------------------------------------------------------------------------------------------------
error_handler:
    *p_line_count = lv_line_count;
    return NORMAL_ERROR;
}

//----------------------------------------------------------------------------------------------------
//   Function: Timer0Initial
//      Input: void
//     Output: void
//     Return: int32: ����ִ�����
//Description: Timer0��ʼ������
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
static int32 Timer0Initial(void)
{
    pTIMER0->TCR  =   (0 << 1)
                    | (0 << 2)
                    | (1 << 3)
                    | (0 << 4)
                    | (0 << 6)
                    | (0 << 8)
                    | (0 << 9)
                    | (0 << 10)
                    | (0 << 11)
                    | (0 << 12)
                    | (0 << 17)
                    | (0 << 18)
                    | (1 << 19)
                    | (0 << 20)
                    | (0 << 22)
                    | (0 << 24)
                    | (0 << 25)
                    | (0 << 26)
                    | (0 << 27)
                    | (0 << 28);
    pTIMER0->TGCR =   (0 << 0)
                    | (0 << 1)
                    | (1 << 2)
                    | (0 << 4)
                    | (TIMER0B34_PERDIV << 8)
                    | (0 << 12);

    pTIMER0->PRD12 =  TIMER0B12_PERIOD;
    pTIMER0->TIM12 =  0;

    pTIMER0->PRD34 =  TIMER0B34_PERIOD;
    pTIMER0->TIM34 =  0;

    pTIMER0->TGCR =   (1 << 0)
                    | (1 << 1)
                    | (1 << 2)
                    | (0 << 4)
                    | (TIMER0B34_PERDIV << 8)
                    | (0 << 12);
    pTIMER0->INTCTLSTAT =   (0 << 0)
                          | (1 << 1)
                          | (0 << 2)
                          | (1 << 3)
                          | (1 << 16)
                          | (1 << 17)
                          | (0 << 18)
                          | (1 << 19);

    return NORMAL_SUCCESS;
}

//----------------------------------------------------------------------------------------------------
//   Function: Timer0InterruptService
//      Input: void
//     Output: void
//     Return: void
//Description: Timer0�жϴ�������
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
#pragma INTERRUPT(Timer0InterruptService)
static void Timer0InterruptService(void)
{
    Uint32 lv_time_cal;

    lv_time_cal = pTIMER0->TIM12;
    AppBeginNormalServices(NULL, lv_time_cal);
    AppEndNormalServices();
}

//----------------------------------------------------------------------------------------------------
//   Function: DefaultInterruptService
//      Input: void
//     Output: void
//     Return: void
//Description:Ĭ���жϴ�������
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
#pragma INTERRUPT(DefaultInterruptService)
static void DefaultInterruptService(void)
{
    return;
}

