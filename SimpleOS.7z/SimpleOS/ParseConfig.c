/*****************************************************************************************************
* FileName:                    ParseConfig.c
*
* Description:                 ���ý�����غ���
*
* Author:                      YanDengxue, Fiberhome-Fuhua
*
* Rev History:
*       <Author>        <Data>        <Hardware>     <Version>        <Description>
*     YanDengxue   2011-03-29 15:30       --           1.00             Create
*****************************************************************************************************/
//====================================================================================================
// ���ļ�ʹ�õ�ͷ�ļ�
//====================================================================================================
// ��ͷ�ļ�
#include <string.h>
#include <stdio.h>

// �Զ���ͷ�ļ�
#include "UserTypesDef.h"
#include "Debug.h"

//====================================================================================================
// ����ʵ��
//====================================================================================================
//----------------------------------------------------------------------------------------------------
// �ӿں���
//----------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------
//   Function: GetSignalName
//      Input: Uint8 const *src:
//             Uint8 *buffer:
//             int32 buffer_length:
//     Output: void
//     Return: int8 const *:
//Description: ��ȡ�ź�����
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
int8 const *GetContentToSplit(int8 const *src, int8 *buffer, int32 buffer_length)
{
    Uint8 lv_escape_flag;
    Uint8 lv_quote_flag;
    Uint8 lv_byte_temp;
    int32 lv_index;
    int32 lv_content_flag;

    if ((NULL == src) || (NULL == buffer))
    {
        TRACE("Function entry error!");
        return NULL;
    }

    buffer[0] = '\0';
    while ((' ' == *src) || ('\t' == *src))
    {
        src++;
    }

    if ('"' == *src)
    {
        lv_quote_flag = 1;
        src++;
    }
    else
    {
        lv_quote_flag = 0;
    }

    lv_escape_flag = 0;
    lv_index = 0;
    lv_content_flag = 0;
    while (lv_index < (buffer_length - 1))
    {
        lv_byte_temp = *src;
        if ('\0' == lv_byte_temp)
        {
            break;
        }

        if (0 != lv_escape_flag)
        {
            lv_escape_flag = 0;
        }
        else
        {
            if ('\\' == lv_byte_temp)
            {
                lv_escape_flag = 1;
                src++;
                continue;
            }
            else if ('"' == lv_byte_temp)
            {
                if (0 != lv_quote_flag)
                {
                    lv_quote_flag = 0;
                }
                else
                {
                    lv_quote_flag = 1;
                }
            }
            else if (0 == lv_quote_flag)
            {
                if ((' ' == lv_byte_temp) || ('\t' == lv_byte_temp) || ('=' == lv_byte_temp))
                {
                    break;
                }
                else if ((('/' == lv_byte_temp) && ('/' == *(src + 1))) || ('>' == lv_byte_temp))
                {
                    lv_content_flag = 1;
                    break;
                }
            }
        }
        buffer[lv_index++] = lv_byte_temp;
        src++;
    }

    if ((lv_index > 0) && ('"' == buffer[lv_index - 1]))
    {
        lv_index--;
    }
    buffer[lv_index] = '\0';

    if (0 == lv_content_flag)
    {
        while ((' ' == *src) || ('\t' == *src))
        {
            src++;
        }

        if ('\0' == *src)
        {
            return NULL;
        }
        else
        {
            return src;
        }
    }
    else
    {
        return NULL;
    }
}

//----------------------------------------------------------------------------------------------------
//   Function: GetContentOfKeyword
//      Input: char const *buffer : ����ѯ���ַ��׵�ַ
//             char const *key_word : ����ѯ�Ĺؼ���
//     Output: unsigned long *result : �ؼ��ֵ�ֵ
//     Return: int : ����ִ�����
//Description: ��ȡ�ؼ���֮���ֵ
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2009-10-22 09:00           Create
//----------------------------------------------------------------------------------------------------
int32 GetContentOfKeyword(int8 const *key_word, int8 const *src, int8 *buffer, int32 buffer_length)
{
    char const *lv_p_str;

    if ((NULL == buffer) || (NULL == key_word) || (NULL == src))
    {
        TRACE("entry parameter is null");
        return NORMAL_ERROR;
    }

    lv_p_str = src;

    do
    {
        if ('=' == *lv_p_str)
        {
            lv_p_str++;
            continue;
        }
        lv_p_str = GetContentToSplit(lv_p_str, buffer, buffer_length);
        if (NULL == lv_p_str)
        {
            return NORMAL_ERROR;
        }
        else if ('=' != *lv_p_str)
        {
            continue;
        }
    } while (0 != strcmp(key_word, buffer));


    lv_p_str++;
    lv_p_str = GetContentToSplit(lv_p_str, buffer, buffer_length);
    if (NULL != lv_p_str)
    {
        // �����ո���Ʊ���
        while ((' ' == *lv_p_str) || ('\t' == *lv_p_str))
        {
            lv_p_str++;
        }

        if ('=' == *lv_p_str)
        {
            buffer[0] = '\0';
        }
    }

    return NORMAL_SUCCESS;
}



