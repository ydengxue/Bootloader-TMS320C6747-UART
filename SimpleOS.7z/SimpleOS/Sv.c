/*****************************************************************************************************
* FileName:                    UserApp.c
*
* Description:                 �û�����������
*
* Author:                      YanDengxue, Fiberhome-Fuhua
*
* Rev History:
*       <Author>        <Data>        <Hardware>     <Version>        <Description>
*     YanDengxue   2011-03-29 15:30       --           1.00             Create
*****************************************************************************************************/
//====================================================================================================
// ���ļ�ʹ�õ�ͷ�ļ�
//====================================================================================================
// ��ͷ�ļ�
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

// �Զ���ͷ�ļ�
#include "UserTypesDef.h"
#include "C6747Register.h"
#include "SystemBase.h"
#include "BaseData.h"
#include "Sv.h"
#include "ProjectDataHandle.h"
#include "Debug.h"
#include "UserApp.h"

//====================================================================================================
// ���غ�������,�˴������ĺ��������ⲿ�ӿ�
//====================================================================================================
static void SvSendDataHandle(SVCB *p_svcb);

//====================================================================================================
// ���ļ���������ⲿ�Ľӿڱ���
//====================================================================================================
PROJECT_TYPE_DEFINE const sv_prj_type_define[] =
{
    {"INT32",         PROJECT_DATA_TYPE_INT32},
    {"Quality",       PROJECT_DATA_TYPE_QUALITY},
};

int32 const sv_prj_type_define_num = sizeof(sv_prj_type_define) / sizeof(sv_prj_type_define[0]);

//====================================================================================================
// ����ʵ��
//====================================================================================================
//----------------------------------------------------------------------------------------------------
//   Function: GetSvDataLength
//      Input: PROJECT_DATA_TYPE data_type
//     Output: void
//     Return: int32: ���ݳ���,-1��ʾ�Ҳ�����Ӧ������
//Description: ��ȡ���ݳ���
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
int32 GetSvDataLength(PROJECT_DATA_TYPE data_type)
{
    switch (data_type)
    {
        case PROJECT_DATA_TYPE_INT32:
        case PROJECT_DATA_TYPE_QUALITY:
        {
            return 4;
        }
        default :
        {
            TRACE("unknow project data type \"%d\"", data_type);
            return NORMAL_ERROR;
        }
    }
}

//----------------------------------------------------------------------------------------------------
// �ӿں���
//----------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------
//   Function: SvPacketSend
//      Input: void
//     Output: void
//     Return: void
//Description: Ӧ�ó���
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
void SvPacketSend(void)
{
    int16 lv_cb_index;
    Uint16 lv_smp_count;
    SV_TX *lv_p_sv_tx;
    SVCB  *lv_p_svcb;
    Uint8 lv_smp_synch;

    // �����������ﵽ������pps����0����������
    lv_smp_count = mu.smp_count;

    // ��̫������
    lv_smp_synch = mu.pps_sync_flag;
    lv_p_sv_tx = &prj_cfg.sv_tx;
    if (0 != lv_p_sv_tx->cb_num)
    {
        for (lv_cb_index = 0; lv_cb_index < lv_p_sv_tx->cb_num; lv_cb_index++)
        {
            lv_p_svcb = &lv_p_sv_tx->svcb[lv_cb_index];
            lv_p_svcb->addr_smp_cnt[0] = (lv_smp_count >> 8);
            lv_p_svcb->addr_smp_cnt[1] = lv_smp_count;
            lv_p_svcb->addr_smp_synch[0] = lv_smp_synch;
            SvSendDataHandle(lv_p_svcb);
        }
        if (0 != (system_running_status & CPU_RUNNING_FLAG))
        {
            pEMAC->TX0HDP = lv_p_sv_tx->svcb[0].emac_desc;
        }
    }
}

//----------------------------------------------------------------------------------------------------
// ���غ���
//----------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------
//   Function: SvSendDataHandle
//      Input: SVCB *p_svcb
//     Output: void
//     Return: void
//Description: Sv�������ݴ���
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
static void SvSendDataHandle(SVCB *p_svcb)
{
    SIGNAL_DATA lv_signal_data_temp;
    int32 lv_cb_data_index;
    Uint8 *lv_p_data;
    SIGNAL_OUT const *lv_p_signal_out;
    PROJECT_TYPE_DEFINE const *lv_p_prj_type;
    SIGNAL_DEFINE const *lv_p_signal_define;

    lv_p_data = p_svcb->addr_data_set;
    for (lv_cb_data_index = 0; lv_cb_data_index < p_svcb->item_num; lv_cb_data_index++)
    {
        lv_p_signal_out = &p_svcb->singal_out[lv_cb_data_index];
        lv_p_prj_type = lv_p_signal_out->prj_type_define;
        lv_p_signal_define = lv_p_signal_out->define;
        switch (lv_p_prj_type->type)
        {
            case PROJECT_DATA_TYPE_INT32 :
            {
                lv_signal_data_temp.l = *((int32 *)(lv_p_signal_define->addr));
                *lv_p_data++ = lv_signal_data_temp.l >> 24;
                *lv_p_data++ = lv_signal_data_temp.l >> 16;
                *lv_p_data++ = lv_signal_data_temp.l >> 8;
                *lv_p_data++ = lv_signal_data_temp.l;
                break;
            }
            case PROJECT_DATA_TYPE_QUALITY :
            {
                lv_signal_data_temp.ul = *((Uint32 *)(lv_p_signal_define->addr));
                *lv_p_data++ = lv_signal_data_temp.l >> 24;
                *lv_p_data++ = lv_signal_data_temp.l >> 16;
                *lv_p_data++ = lv_signal_data_temp.l >> 8;
                *lv_p_data++ = lv_signal_data_temp.l;
                break;
            }
            default :
            {
                break;
            }
        }
    }

    p_svcb->emac_desc->flags_and_packet_length =  (EMAC_DESC_FLAG_OWNER | EMAC_DESC_FLAG_SOP | EMAC_DESC_FLAG_EOP)
                                                   | p_svcb->frame_length;

}

