/*****************************************************************************************************
* FileName:                    LaserPowerControl.c
*
* Description:                 �⹦�ܿ���
*
* Author:                      YanDengxue, Fiberhome-Fuhua
*
* Rev History:
*       <Author>        <Data>        <Hardware>     <Version>        <Description>
*     YanDengxue   2011-08-22 11:00       --           1.00             Create
*****************************************************************************************************/
//====================================================================================================
// ���ļ�ʹ�õ�ͷ�ļ�
//====================================================================================================
// ��ͷ�ļ�
#include <string.h>
#include <stdio.h>
#include <math.h>

// �Զ���ͷ�ļ�
#include "UserTypesDef.h"
#include "C6747Register.h"
#include "SystemBase.h"
#include "LaserPowerControl.h"
#include "NormalServices.h"
#include "UserApp.h"

//====================================================================================================
// ���ļ���������ⲿ�Ľӿڱ���
//====================================================================================================
LASER_POWER laser_power;
Uint8  uart1_tx_buffer[4] = {0, 0, 0, 0};
Uint8  uart1_rx_buffer[16];
Uint8  laser_power_online;
Uint32 laser_power_on_effective_current;
Uint32 laser_power_off_effective_current;
Uint32 laser_power_communication_interval;
Uint32 laser_power_on_min_time;

//====================================================================================================
// ���ر�������,�˴������ı��������ⲿ�ӿ�
//====================================================================================================
static Uint8 uart1_send_status = 0;
static Uint8 uart1_receive_status = 0;
static Uint8 laser_power_control_status = 0;
static Uint32 laser_power_open_system_ms_count_last_value = 0;
static Uint32 uart1_tx_system_ms_count_last_value = 0;
static Uint8  uart1_rx_buffer_ptr = 0;
static Uint64 measure_current_sum_a = 0ULL;
static Uint64 measure_current_sum_b = 0ULL;
static Uint64 measure_current_sum_c = 0ULL;
static Uint64 current_dot_value_a[LASER_POWER_CURRENT_DOT_NUM];
static Uint64 current_dot_value_b[LASER_POWER_CURRENT_DOT_NUM];
static Uint64 current_dot_value_c[LASER_POWER_CURRENT_DOT_NUM];
static Uint16 effective_current_cal_addr = 0;

//====================================================================================================
// ����ʵ��
//====================================================================================================
//----------------------------------------------------------------------------------------------------
// �ӿں���
//----------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------
//   Function: LaserPowerControl
//      Input: void
//     Output: void
//     Return: void
//Description: �⹦�ܿ��ƺ���
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-08-22 16:30           Create
//----------------------------------------------------------------------------------------------------
void LaserPowerControl(void)
{
    int32 i;
    int64 lv_channel_data;
    Uint8 lv_laser_power_change_status;
    Uint8 lv_laser_power_control;
    Uint8 lv_rx_laser_header;
    Uint8 lv_rx_laser_status_change;
    Uint8 lv_rx_laser_status;
    Uint8 lv_rx_laser_sum;
    Uint8 lv_rx_laser_sum_cal;
    Uint8 lv_uart1_rx_buffer_read_ptr;
    Uint16 lv_substract_dot_addr;

    if (0 != laser_power_online)
    {
        if (0 != laser_power_control_status)
        {
            switch (uart1_send_status)
            {
                case 1 :
                {
                    if (0 != (pUART1->LSR & UART_LSR_THRE))
                    {
                        for (i = 0; i < 4; i++)
                        {
                            pUART1->THR = uart1_tx_buffer[i];
                        }
                        uart1_send_status = 2;
                    }
                    break;
                }
                case 2 :
                {
                    if (0 != (pUART1->LSR & UART_LSR_TEMT))
                    {
                        uart1_rx_buffer_ptr = 0;
                        uart1_send_status = 0;
                        uart1_receive_status = 1;
                    }
                    break;
                }
                default :
                {
                    if (0 != uart1_receive_status)
                    {
                        while (uart1_rx_buffer_ptr < 0x10u)
                        {
                            if (0 == (pUART1->LSR & UART_LSR_DR))
                            {
                                break;
                            }
                            uart1_rx_buffer[uart1_rx_buffer_ptr++] = pUART1->RBR;
                        }
                    }
                    break;
                }
            }
        
            lv_substract_dot_addr = LASER_POWER_CURRENT_DOT_ADDR(effective_current_cal_addr - 80u);
        
            lv_channel_data = mu.channel[8].data;
            current_dot_value_a[effective_current_cal_addr] = lv_channel_data * lv_channel_data / 80;
            measure_current_sum_a = measure_current_sum_a - current_dot_value_a[lv_substract_dot_addr] +  current_dot_value_a[effective_current_cal_addr];
            laser_power.current_effective_a = sqrt(measure_current_sum_a);
        
            lv_channel_data = mu.channel[9].data;
            current_dot_value_b[effective_current_cal_addr] = lv_channel_data * lv_channel_data / 80;
            measure_current_sum_b = measure_current_sum_b - current_dot_value_b[lv_substract_dot_addr] + current_dot_value_b[effective_current_cal_addr];
            laser_power.current_effective_b = sqrt(measure_current_sum_b);
        
            lv_channel_data = mu.channel[10].data;
            current_dot_value_c[effective_current_cal_addr] = lv_channel_data * lv_channel_data / 80;
            measure_current_sum_c = measure_current_sum_c - current_dot_value_c[lv_substract_dot_addr] + current_dot_value_c[effective_current_cal_addr];
            laser_power.current_effective_c = sqrt(measure_current_sum_c);
        
            effective_current_cal_addr = LASER_POWER_CURRENT_DOT_ADDR(effective_current_cal_addr + 1);
            if ((system_ms_count - uart1_tx_system_ms_count_last_value) >= laser_power_communication_interval)
            {
                uart1_tx_system_ms_count_last_value += laser_power.communication_interval;
                if (0 != uart1_receive_status)
                {
                    laser_power.uart_rx_overtime_flag = 1;
                }
                switch (laser_power_control_status)
                {
                    case 1u:
                    {
                        if (    (laser_power.current_effective_a <= laser_power_on_effective_current)
                             && (laser_power.current_effective_b <= laser_power_on_effective_current)
                             && (laser_power.current_effective_c <= laser_power_on_effective_current))
                        {
                            laser_power.on = 1;
                            lv_laser_power_change_status  = 0x00u;
                            lv_laser_power_control = 0x55u;
                            laser_power_open_system_ms_count_last_value = system_ms_count;
                            laser_power_control_status = 2u;
                        }
                        else
                        {
                            lv_laser_power_change_status  = 0x01u;
                            lv_laser_power_control = 0xAAu;
                        }
                        break;
                    }
                    case 2u:
                    {
                        lv_laser_power_change_status  = 0x01u;
                        lv_laser_power_control = 0x55u;
                        if ((system_ms_count - laser_power_open_system_ms_count_last_value) >= laser_power_on_min_time)
                        {
                            laser_power_control_status = 3u;
                        }
                        break;
                    }
                    case 3u:
                    {
                        if (    (laser_power.current_effective_a >= laser_power_off_effective_current)
                             || (laser_power.current_effective_b >= laser_power_off_effective_current)
                             || (laser_power.current_effective_c >= laser_power_off_effective_current))
                        {
                            laser_power.on = 0;
                            lv_laser_power_change_status  = 0x00u;
                            lv_laser_power_control = 0xAAu;
                            laser_power_control_status = 1u;
                        }
                        else
                        {
                            lv_laser_power_change_status  = 0x01u;
                            lv_laser_power_control = 0x55u;
                        }
                        break;
                    }
                    default:
                    {
                        lv_laser_power_change_status  = 0x00u;
                        lv_laser_power_control = 0x55u;
                        laser_power_open_system_ms_count_last_value = system_ms_count;
                        laser_power_control_status = 2;
                        break;
                    }
                }
                uart1_tx_buffer[0] = 0xF6u;
                uart1_tx_buffer[1] = lv_laser_power_change_status;
                uart1_tx_buffer[2] = lv_laser_power_control;
                uart1_tx_buffer[3] = uart1_tx_buffer[0] + uart1_tx_buffer[1] + uart1_tx_buffer[2];
                uart1_send_status = 1;
            }
            else
            {
                if (uart1_rx_buffer_ptr >= 4u)
                {
                    lv_uart1_rx_buffer_read_ptr = 0;
                    while ((uart1_rx_buffer_ptr - lv_uart1_rx_buffer_read_ptr) >= 4u)
                    {
                        lv_rx_laser_header = uart1_rx_buffer[lv_uart1_rx_buffer_read_ptr++];
                        if (0xF6 != lv_rx_laser_header)
                        {
                            continue;
                        }
                        lv_rx_laser_status_change = uart1_rx_buffer[lv_uart1_rx_buffer_read_ptr];
                        lv_rx_laser_status = uart1_rx_buffer[lv_uart1_rx_buffer_read_ptr + 1];
                        lv_rx_laser_sum = uart1_rx_buffer[lv_uart1_rx_buffer_read_ptr + 2];
                        lv_rx_laser_sum_cal = lv_rx_laser_header + lv_rx_laser_status_change + lv_rx_laser_status;
                        if (lv_rx_laser_sum != lv_rx_laser_sum_cal)
                        {
                            continue;
                        }
                        else
                        {
                            uart1_receive_status = 0;
                            laser_power.uart_rx_overtime_flag = 0;
                            uart1_rx_buffer_ptr = 0;
                            for (i = 0; i < 8; i++)
                            {
                                laser_power.status_bit[i] = (lv_rx_laser_status >> i) & 1;
                            }
                            break;
                        }
                    }
        
                    if (0 != uart1_rx_buffer_ptr)
                    {
                        i = 0;
                        while (lv_uart1_rx_buffer_read_ptr < uart1_rx_buffer_ptr)
                        {
                            uart1_rx_buffer[i++] = uart1_rx_buffer[lv_uart1_rx_buffer_read_ptr++];
                        }
                        uart1_rx_buffer_ptr = i;
                    }
                }
            }
        }
        else
        {
            for (i = 0; i < LASER_POWER_CURRENT_DOT_NUM; i++)
            {
                current_dot_value_a[i] = 0ULL;
                current_dot_value_b[i] = 0ULL;
                current_dot_value_c[i] = 0ULL;
            }
            uart1_tx_buffer[0] = 0xF6u;
            uart1_tx_buffer[1] = 0x00u;
            uart1_tx_buffer[2] = 0x55u;
            uart1_tx_buffer[3] = uart1_tx_buffer[0] + uart1_tx_buffer[1] + uart1_tx_buffer[2];
            uart1_send_status = 1;
            laser_power.on = 1;
            laser_power_open_system_ms_count_last_value = system_ms_count;
            uart1_tx_system_ms_count_last_value = system_ms_count;
            laser_power_control_status = 2;
        }
    }
    else
    {
        laser_power.uart_rx_overtime_flag = 0;
        laser_power.on = 0;
        laser_power_control_status = 0;
        for (i = 0; i < 8; i++)
        {
            laser_power.status_bit[i] = 0;
        }
    }
}


