/*****************************************************************************************************
* FileName:                    SettingManage.h
*
* Description:                 ��ֵ����ͷ�ļ�
*
* Author:                      YanDengxue, Fiberhome-Fuhua
*
* Rev History:
*       <Author>        <Data>        <Hardware>     <Version>        <Description>
*     YanDengxue   2011-03-29 15:30       --           1.00             Create
*****************************************************************************************************/
#ifndef _Setting_Manage_H
#define _Setting_Manage_H

#ifdef __cplusplus
extern "C" {
#endif

//====================================================================================================
// �궨��
//====================================================================================================
#define UINT_LENGTH_MAX     8

//====================================================================================================
// �ṹ����
//====================================================================================================
typedef struct
{
    SIGNAL_DEFINE const *define;
    Uint16  position;
    Uint32  visible;
    SIGNAL_DATA default_value;
    SIGNAL_DATA min_value;
    SIGNAL_DATA max_value;
    char   unit[UINT_LENGTH_MAX];
    char   const *desc;
    char   const *desc_utf8;
} SETTING;

typedef struct
{
    SETTING *setting;
    int8  need_save_flag;
    Uint8 run_section_no;
    int32 num;
    int32 flash_addr;
    int32 flash_length;
    Uint8 *run_buffer;
    Uint8 *write_buffer;
    Uint8 *history_buffer;
} SETTING_GROUP;

//====================================================================================================
// �ⲿ��������
//====================================================================================================
extern SIGNAL_DEFINE const setting_system_define[];
extern int32 const setting_system_define_num;
extern SETTING_GROUP setting_system;

//====================================================================================================
// �ⲿ��������
//====================================================================================================
extern int32 SettingReadFromFlash(SETTING_GROUP const *p_setting_group);
extern int32 SettingWriteToFlash(SETTING_GROUP const *p_setting_group);
extern int32 RunSettingUpdateFromRunBuffer(SETTING_GROUP const *p_setting_group);
extern int32 RunSettingUpdateFromWriteBuffer(SETTING_GROUP const *p_setting_group);
extern int32 SettingWriteBufferUpdateFromRunBuffer(SETTING_GROUP const *p_setting_group);
extern int32 SettingRunBufferUpdateFromWriteBuffer(SETTING_GROUP const *p_setting_group);
extern int32 RunSettingAndWriteBufferUpdateFromRunBuffer(SETTING_GROUP const *p_setting_group);
extern int32 RunSettingAndRunBufferUpdateFromWriteBuffer(SETTING_GROUP const *p_setting_group);
extern int32 SettingToDefault(SETTING_GROUP const *p_setting_group);
extern int32 GetValueOfKeyWord(char const *keyword, char const *src, int32 type, SIGNAL_DATA *p_data);
extern int32 SettingManageInitial(SETTING_GROUP *setting_group);
extern int32 SetOneWriteSettingStringValue(SETTING_GROUP const *p_setting_group, char const *p_str, int32 index);
extern int32 CheckRunSettingWithFlash(SETTING_GROUP *p_setting_group);

#ifdef __cplusplus
}
#endif

#endif


