/*****************************************************************************************************
* FileName:                    NormalService.c
*
* Description:                 Ӧ�ó���ͨ�÷�����
*
* Author:                      YanDengxue, Fiberhome-Fuhua
*
* Rev History:
*       <Author>        <Data>        <Hardware>     <Version>        <Description>
*     YanDengxue   2011-03-29 15:30       --           1.00             Create
*****************************************************************************************************/
// �Զ���ͷ�ļ�
#include "UserTypesDef.h"
#include "C6747Register.h"
#include "SystemBase.h"
#include "BaseData.h"
#include "NormalServices.h"

//====================================================================================================
// ���ļ���������ⲿ�Ľӿڱ���
//====================================================================================================
VUint32 system_ms_count = 0;
VUint64 system_local_usecond = 0;

//====================================================================================================
// ���ر�������,�˴������ı��������ⲿ�ӿ�
//====================================================================================================
static Uint32 system_ms_timer0b12_last_value = 0;
static Uint32 system_local_usecond_timer0b12_last_value = 0;
static Uint64 irigb_to_usecond_last = 0;

//----------------------------------------------------------------------------------------------------
//   Function: AppBeginNormalServices
//      Input: void
//     Output: void
//     Return: void
//Description: Ӧ�ó���ʼ��ͨ�÷�����
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
void AppBeginNormalServices(IRIGB const *p_irig_b, Uint32 timer0b12_current_value)
{
    Uint32 lv_ulong_temp;
    Uint64 lv_irigb_to_usecond;

    if (NULL != p_irig_b)
    {
        lv_irigb_to_usecond = IrigbToUsecond(p_irig_b);
        system_local_usecond_timer0b12_last_value = pTIMER0->TIM12;
        if ((lv_irigb_to_usecond - irigb_to_usecond_last) <= 1005000u)
        {
            system_local_usecond = lv_irigb_to_usecond;
        }
        irigb_to_usecond_last = lv_irigb_to_usecond;
    }
    else
    {
        lv_ulong_temp = timer0b12_current_value - system_local_usecond_timer0b12_last_value;
        system_local_usecond_timer0b12_last_value = timer0b12_current_value;
        system_local_usecond += (lv_ulong_temp / SYSTRM_US_TICKS);
    }

    if ((timer0b12_current_value - system_ms_timer0b12_last_value) >=  SYSTRM_MS_TICKS)
    {
        system_ms_count++;
        system_ms_timer0b12_last_value += SYSTRM_MS_TICKS;
    }
}

//----------------------------------------------------------------------------------------------------
//   Function: AppEndNormalServices
//      Input: void
//     Output: void
//     Return: void
//Description: Ӧ�ó��������ͨ�÷�����
//    <AUTHOR>        <MODIFYTIME>            <REASON>
//   YanDengxue     2011-03-21 16:30           Create
//----------------------------------------------------------------------------------------------------
void AppEndNormalServices(void)
{
    FeedWatchDog();
    HmiCommunicationDataTransport();
}
